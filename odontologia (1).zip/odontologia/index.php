<?php

require_once __DIR__ . '/config/config.php';

use App\Core\Auth;

if (Auth::check()) {
    header('Location: ' . BASE_URL . 'views/dashboard/index.php');
} else {
    header('Location: ' . BASE_URL . 'login.php');
}
exit;

