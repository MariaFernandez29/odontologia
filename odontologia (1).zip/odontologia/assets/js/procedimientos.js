$(document).ready(function() {
    let tableProc = $('#tablaProcedimientos').DataTable({
        language: dtSpanish,
        responsive: true,
        ajax: {
            url: BASE_URL + 'ajax/procedimientos.php?action=list',
            dataSrc: 'data'
        },
        columns: [
            {
                data: 'codigo',
                render: function(data) {
                    return `<code>${data || '---'}</code>`;
                }
            },
            {
                data: 'nombre',
                render: function(data) {
                    return `<strong>${data}</strong>`;
                }
            },
            {
                data: 'categoria',
                render: function(data) {
                    return `<span class="badge bg-primary-subtle text-primary">${data || 'General'}</span>`;
                }
            },
            {
                data: 'descripcion',
                render: function(data) {
                    return data ? `<small class="text-muted">${data}</small>` : '<small class="text-muted">Sin descripción</small>';
                }
            },
            {
                data: 'total_realizados',
                className: 'text-center',
                render: function(data) {
                    return `<span class="badge bg-light text-dark border">${data} realizados</span>`;
                }
            },
            {
                data: 'estado',
                render: function(data) {
                    return data === 'activo' 
                        ? '<span class="badge bg-success">Activo</span>' 
                        : '<span class="badge bg-secondary">Inactivo</span>';
                }
            },
            {
                data: null,
                orderable: false,
                className: 'text-end',
                render: function(data) {
                    const toggleIcon = data.estado === 'activo' ? 'bi-toggle2-on text-success' : 'bi-toggle2-off text-muted';
                    return `
                        <div class="btn-group btn-group-sm">
                            <button class="btn btn-outline-primary btn-edit" data-id="${data.id}" title="Editar">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <button class="btn btn-outline-secondary btn-toggle" data-id="${data.id}" title="Cambiar estado">
                                <i class="bi ${toggleIcon} fs-6"></i>
                            </button>
                        </div>
                    `;
                }
            }
        ],
        order: [[1, 'asc']]
    });

    // Abrir modal nuevo
    $('#btnNuevoProcedimiento').on('click', function() {
        $('#formProcedimiento')[0].reset();
        $('#procedimiento_id').val('');
        $('#modalProcedimientoTitle').text('Registrar Procedimiento Odontológico');
        $('#modalProcedimiento').modal('show');
    });

    // Abrir modal editar
    $('#tablaProcedimientos').on('click', '.btn-edit', function() {
        const id = $(this).data('id');
        $.getJSON(BASE_URL + 'ajax/procedimientos.php?action=get&id=' + id, function(res) {
            if (res.status === 'success') {
                const p = res.data;
                $('#procedimiento_id').val(p.id);
                $('#proc_codigo').val(p.codigo);
                $('#proc_nombre').val(p.nombre);
                $('#proc_categoria').val(p.categoria);
                $('#proc_descripcion').val(p.descripcion);
                $('#proc_estado').val(p.estado);
                $('#modalProcedimientoTitle').text('Editar Procedimiento: ' + p.nombre);
                $('#modalProcedimiento').modal('show');
            }
        });
    });

    // Guardar procedimiento
    $('#formProcedimiento').on('submit', function(e) {
        e.preventDefault();
        const id = $('#procedimiento_id').val();
        const action = id ? 'update' : 'create';

        const btn = $('#btnSaveProc');
        btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span>Guardando...');

        $.ajax({
            url: BASE_URL + 'ajax/procedimientos.php?action=' + action,
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(res) {
                if (res.status === 'success') {
                    $('#modalProcedimiento').modal('hide');
                    tableProc.ajax.reload(null, false);
                    Swal.fire({
                        icon: 'success',
                        title: 'Éxito',
                        text: res.message,
                        timer: 1300,
                        showConfirmButton: false
                    });
                } else {
                    Swal.fire({ icon: 'error', title: 'Error', text: res.message });
                }
                btn.prop('disabled', false).html('<i class="bi bi-save me-1"></i>Guardar');
            },
            error: function(xhr) {
                let msg = 'Error en el servidor.';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    msg = xhr.responseJSON.message;
                }
                Swal.fire({ icon: 'error', title: 'Error', text: msg });
                btn.prop('disabled', false).html('<i class="bi bi-save me-1"></i>Guardar');
            }
        });
    });

    // Alternar estado activo/inactivo
    $('#tablaProcedimientos').on('click', '.btn-toggle', function() {
        const id = $(this).data('id');
        $.post(BASE_URL + 'ajax/procedimientos.php?action=toggle', { id: id, csrf_token: CSRF_TOKEN }, function(res) {
            if (res.status === 'success') {
                tableProc.ajax.reload(null, false);
            } else {
                Swal.fire({ icon: 'error', title: 'Error', text: res.message });
            }
        }, 'json');
    });
});

