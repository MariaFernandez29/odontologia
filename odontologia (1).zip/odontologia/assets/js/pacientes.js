$(document).ready(function() {
    let tablePacientes = $('#tablaPacientes').DataTable({
        language: dtSpanish,
        responsive: true,
        ajax: {
            url: BASE_URL + 'ajax/pacientes.php?action=list',
            dataSrc: 'data'
        },
        columns: [
            {
                data: 'codigo',
                render: function(data) {
                    return `<span class="badge bg-light text-primary border fw-bold">${data}</span>`;
                }
            },
            {
                data: null,
                render: function(data) {
                    let alertHtml = '';
                    if (data.alergias) {
                        alertHtml = `<span class="badge bg-warning text-dark ms-1" title="Alergias: ${data.alergias}"><i class="bi bi-exclamation-triangle-fill"></i> Alergia</span>`;
                    }
                    return `<strong>${data.nombres} ${data.apellidos}</strong> ${alertHtml}<br><small class="text-muted">C.I.: ${data.cedula}</small>`;
                }
            },
            {
                data: null,
                render: function(data) {
                    const sexoLabel = data.sexo === 'M' ? 'Masc.' : (data.sexo === 'F' ? 'Fem.' : 'Otro');
                    return `${data.edad || '0'} años <small class="text-muted">(${sexoLabel})</small>`;
                }
            },
            {
                data: null,
                render: function(data) {
                    return `<div><i class="bi bi-telephone text-muted me-1"></i>${data.telefono || 'Sin tel.'}</div>
                            <small class="text-muted"><i class="bi bi-envelope text-muted me-1"></i>${data.email || 'Sin correo'}</small>`;
                }
            },
            {
                data: 'total_consultas',
                className: 'text-center',
                render: function(data) {
                    return `<span class="badge bg-primary-subtle text-primary">${data} consultas</span>`;
                }
            },
            {
                data: 'estado',
                render: function(data) {
                    return data === 'activo'
                        ? '<span class="badge bg-success">Activo</span>'
                        : '<span class="badge bg-secondary">Inactivo</span>';
                }
            },
            {
                data: null,
                orderable: false,
                className: 'text-end',
                render: function(data) {
                    return `
                        <div class="dropdown">
                            <button class="btn btn-sm btn-light border dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                Opciones
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                                <li>
                                    <a class="dropdown-item btn-view-ficha" href="#" data-id="${data.id}">
                                        <i class="bi bi-eye text-primary me-2"></i>Ver Ficha
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="${BASE_URL}views/historia/index.php?paciente_id=${data.id}">
                                        <i class="bi bi-file-earmark-medical text-info me-2"></i>Historia Clínica
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="${BASE_URL}reports/historia_pdf.php?id=${data.id}" target="_blank">
                                        <i class="bi bi-file-pdf text-danger me-2"></i>Descargar PDF
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="${BASE_URL}views/citas/index.php?action=new&paciente_id=${data.id}">
                                        <i class="bi bi-calendar-plus text-success me-2"></i>Agendar Cita
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item btn-edit-paciente" href="#" data-id="${data.id}">
                                        <i class="bi bi-pencil text-secondary me-2"></i>Editar Datos
                                    </a>
                                </li>
                            </ul>
                        </div>
                    `;
                }
            }
        ],
        order: [[0, 'desc']]
    });

    // Control de visibilidad campo embarazo
    $('#sexo').on('change', function() {
        if ($(this).val() === 'F') {
            $('#seccionEmbarazo').slideDown(200);
        } else {
            $('#seccionEmbarazo').slideUp(200);
            $('#embarazo').prop('checked', false);
            $('#meses_embarazo').val(0);
        }
    });

    $('#embarazo').on('change', function() {
        if ($(this).is(':checked')) {
            $('#campoMesesEmbarazo').slideDown(150);
        } else {
            $('#campoMesesEmbarazo').slideUp(150);
            $('#meses_embarazo').val(0);
        }
    });

    // Abrir modal nuevo paciente
    $('#btnNuevoPaciente').on('click', function() {
        $('#formPaciente')[0].reset();
        $('#paciente_id').val('');
        $('#modalPacienteTitle').text('Registrar Nuevo Paciente');
        $('#seccionEmbarazo, #campoMesesEmbarazo').hide();
        // Activar primera pestaña
        $('#pills-datos-tab').tab('show');
        $('#modalPaciente').modal('show');
    });

    // Si viene con ?action=new por URL
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('action') === 'new') {
        $('#btnNuevoPaciente').trigger('click');
    }

    // Abrir modal editar paciente
    $('#tablaPacientes').on('click', '.btn-edit-paciente', function(e) {
        e.preventDefault();
        const id = $(this).data('id');
        $.getJSON(BASE_URL + 'ajax/pacientes.php?action=get&id=' + id, function(res) {
            if (res.status === 'success') {
                const p = res.data;
                $('#paciente_id').val(p.id);
                $('#cedula').val(p.cedula);
                $('#nombres').val(p.nombres);
                $('#apellidos').val(p.apellidos);
                $('#fecha_nacimiento').val(p.fecha_nacimiento);
                $('#sexo').val(p.sexo);
                $('#grupo_sanguineo').val(p.grupo_sanguineo);
                $('#telefono').val(p.telefono);
                $('#email').val(p.email);
                $('#ocupacion').val(p.ocupacion);
                $('#direccion').val(p.direccion);
                $('#contacto_emergencia').val(p.contacto_emergencia);
                $('#telefono_emergencia').val(p.telefono_emergencia);
                $('#estado').val(p.estado);

                // Antecedentes
                $('#alergias').val(p.alergias);
                $('#enfermedades_sistemicas').val(p.enfermedades_sistemicas);
                $('#medicamentos_actuales').val(p.medicamentos_actuales);
                $('#cirugias_previas').val(p.cirugias_previas);
                $('#antecedentes_familiares').val(p.antecedentes_familiares);
                $('#habitos').val(p.habitos);
                $('#antecedentes_observaciones').val(p.antecedentes_observaciones);

                if (p.sexo === 'F') {
                    $('#seccionEmbarazo').show();
                    if (p.embarazo == 1) {
                        $('#embarazo').prop('checked', true);
                        $('#campoMesesEmbarazo').show();
                        $('#meses_embarazo').val(p.meses_embarazo);
                    } else {
                        $('#embarazo').prop('checked', false);
                        $('#campoMesesEmbarazo').hide();
                    }
                } else {
                    $('#seccionEmbarazo, #campoMesesEmbarazo').hide();
                }

                $('#modalPacienteTitle').text(`Editar Paciente: ${p.codigo} - ${p.nombres} ${p.apellidos}`);
                $('#pills-datos-tab').tab('show');
                $('#modalPaciente').modal('show');
            }
        });
    });

    // Guardar paciente (Crear / Actualizar)
    $('#formPaciente').on('submit', function(e) {
        e.preventDefault();

        const cedula = $('#cedula').val().trim();
        const nombres = $('#nombres').val().trim();
        const apellidos = $('#apellidos').val().trim();
        const fechaNacimiento = $('#fecha_nacimiento').val().trim();
        const sexo = $('#sexo').val();

        if (!cedula || !nombres || !apellidos || !fechaNacimiento || !sexo) {
            $('#pills-datos-tab').tab('show');
            Swal.fire({
                icon: 'warning',
                title: 'Campos Requeridos',
                text: 'Por favor complete cédula, nombres, apellidos, fecha de nacimiento y sexo.',
                confirmButtonColor: '#0d6efd'
            });
            if (!cedula) setTimeout(() => $('#cedula').focus(), 300);
            else if (!nombres) setTimeout(() => $('#nombres').focus(), 300);
            else if (!apellidos) setTimeout(() => $('#apellidos').focus(), 300);
            else if (!fechaNacimiento) setTimeout(() => $('#fecha_nacimiento').focus(), 300);
            return;
        }

        const id = $('#paciente_id').val();
        const action = id ? 'update' : 'create';

        const btn = $('#btnSavePaciente');
        btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span>Guardando...');

        $.ajax({
            url: BASE_URL + 'ajax/pacientes.php?action=' + action,
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(res) {
                if (res.status === 'success') {
                    $('#modalPaciente').modal('hide');
                    tablePacientes.ajax.reload(null, false);
                    Swal.fire({
                        icon: 'success',
                        title: 'Éxito',
                        text: res.message,
                        timer: 1500,
                        showConfirmButton: false
                    });
                } else {
                    Swal.fire({ icon: 'error', title: 'Error', text: res.message });
                }
                btn.prop('disabled', false).html('<i class="bi bi-save me-1"></i>Guardar');
            },
            error: function(xhr) {
                let msg = 'Error en el servidor al guardar paciente.';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    msg = xhr.responseJSON.message;
                }
                Swal.fire({ icon: 'error', title: 'Error', text: msg });
                btn.prop('disabled', false).html('<i class="bi bi-save me-1"></i>Guardar');
            }
        });
    });

    // Ver Ficha Rápida del Paciente
    $('#tablaPacientes').on('click', '.btn-view-ficha', function(e) {
        e.preventDefault();
        const id = $(this).data('id');
        $.getJSON(BASE_URL + 'ajax/pacientes.php?action=get&id=' + id, function(res) {
            if (res.status === 'success') {
                const p = res.data;
                $('#fichaCodigo').text(p.codigo);
                $('#fichaNombre').text(`${p.nombres} ${p.apellidos}`);
                $('#fichaCedula').text(p.cedula);
                $('#fichaEdad').text(`${p.edad} años (${p.fecha_nacimiento})`);
                $('#fichaSexo').text(p.sexo === 'M' ? 'Masculino' : (p.sexo === 'F' ? 'Femenino' : 'Otro'));
                $('#fichaSangre').text(p.grupo_sanguineo || 'No registrado');
                $('#fichaTelefono').text(p.telefono || 'Sin teléfono');
                $('#fichaEmail').text(p.email || 'Sin correo');
                $('#fichaDireccion').text(p.direccion || 'No registrada');
                $('#fichaEmergencia').text(`${p.contacto_emergencia || 'No registrado'} ${p.telefono_emergencia ? '(' + p.telefono_emergencia + ')' : ''}`);

                // Alergias
                if (p.alergias) {
                    $('#fichaAlergias').html(`<div class="alert alert-warning py-1 px-2 mb-0"><i class="bi bi-exclamation-triangle-fill me-1"></i><strong>${p.alergias}</strong></div>`);
                } else {
                    $('#fichaAlergias').html('<span class="text-muted">Ninguna registrada</span>');
                }

                $('#fichaEnfermedades').text(p.enfermedades_sistemicas || 'Ninguna');
                $('#fichaMedicamentos').text(p.medicamentos_actuales || 'Ninguno');
                $('#fichaHabitos').text(p.habitos || 'Ninguno');

                $('#btnFichaHistoria').attr('href', `${BASE_URL}views/historia/index.php?paciente_id=${p.id}`);
                $('#btnFichaPdf').attr('href', `${BASE_URL}reports/historia_pdf.php?id=${p.id}`);

                $('#modalFichaPaciente').modal('show');
            }
        });
    });
});

