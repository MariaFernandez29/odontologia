$(document).ready(function() {
    // Inicializar Select2 si está disponible
    if ($.fn.select2) {
        $('#selectPaciente').select2({
            theme: 'bootstrap-5',
            dropdownParent: $('#modalCita'),
            placeholder: 'Buscar paciente por cédula o nombre...',
            minimumInputLength: 2,
            ajax: {
                url: BASE_URL + 'ajax/pacientes.php?action=search',
                dataType: 'json',
                delay: 250,
                data: function(params) {
                    return { q: params.term };
                },
                processResults: function(data) {
                    return {
                        results: data.data.map(p => ({
                            id: p.id,
                            text: `${p.codigo} - ${p.nombres} ${p.apellidos} (${p.cedula})`
                        }))
                    };
                },
                cache: true
            }
        });
    }

    let tableCitas = $('#tablaCitas').DataTable({
        language: dtSpanish,
        responsive: true,
        ajax: {
            url: BASE_URL + 'ajax/citas.php?action=list',
            dataSrc: 'data'
        },
        columns: [
            {
                data: null,
                render: function(data) {
                    const f = data.fecha.split('-');
                    return `<strong>${f[2]}/${f[1]}/${f[0]}</strong><br><span class="badge bg-light text-dark border"><i class="bi bi-clock me-1"></i>${data.hora.substring(0, 5)}</span>`;
                }
            },
            {
                data: null,
                render: function(data) {
                    return `
                        <div>
                            <a href="${BASE_URL}views/historia/index.php?paciente_id=${data.paciente_id}" class="fw-bold text-decoration-none">
                                ${data.paciente_nombre}
                            </a>
                            <span class="badge bg-light text-primary border ms-1">${data.paciente_codigo}</span>
                        </div>
                        <small class="text-muted"><i class="bi bi-telephone me-1"></i>${data.paciente_telefono || 'Sin tel.'}</small>
                    `;
                }
            },
            {
                data: null,
                render: function(data) {
                    return `<strong>Dr(a). ${data.doctor_nombre}</strong><br><small class="text-muted">${data.doctor_especialidad || 'Odontología'}</small>`;
                }
            },
            {
                data: 'motivo',
                render: function(data) {
                    return `<span class="small">${data}</span>`;
                }
            },
            {
                data: 'estado',
                render: function(data) {
                    let badge = 'bg-warning text-dark';
                    let label = 'Pendiente';
                    if (data === 'en_atencion') { badge = 'bg-primary'; label = 'En Atención'; }
                    if (data === 'atendida') { badge = 'bg-success'; label = 'Atendida'; }
                    if (data === 'cancelada') { badge = 'bg-danger'; label = 'Cancelada'; }
                    if (data === 'no_asistio') { badge = 'bg-secondary'; label = 'No Asistió'; }
                    return `<span class="badge ${badge}">${label}</span>`;
                }
            },
            {
                data: null,
                orderable: false,
                className: 'text-end',
                render: function(data) {
                    let btnAtender = '';
                    if (data.estado === 'pendiente' || data.estado === 'en_atencion') {
                        btnAtender = `
                            <a href="${BASE_URL}views/consultas/atender.php?cita_id=${data.id}&paciente_id=${data.paciente_id}" class="btn btn-sm btn-primary" title="Atender Consulta">
                                <i class="bi bi-clipboard2-pulse me-1"></i>Atender
                            </a>
                        `;
                    } else if (data.estado === 'atendida') {
                        btnAtender = `
                            <a href="${BASE_URL}reports/historia_pdf.php?id=${data.paciente_id}" target="_blank" class="btn btn-sm btn-outline-danger" title="Historia PDF">
                                <i class="bi bi-file-pdf"></i>
                            </a>
                        `;
                    }

                    return `
                        <div class="d-inline-flex gap-1 align-items-center">
                            ${btnAtender}
                            <div class="dropdown">
                                <button class="btn btn-sm btn-light border" type="button" data-bs-toggle="dropdown">
                                    <i class="bi bi-three-dots-vertical"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                                    <li>
                                        <a class="dropdown-item btn-status" href="#" data-id="${data.id}" data-status="en_atencion">
                                            <i class="bi bi-play-circle text-primary me-2"></i>Marcar En Atención
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item btn-status" href="#" data-id="${data.id}" data-status="cancelada">
                                            <i class="bi bi-x-circle text-danger me-2"></i>Cancelar Cita
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item btn-status" href="#" data-id="${data.id}" data-status="no_asistio">
                                            <i class="bi bi-person-x text-secondary me-2"></i>Marcar No Asistió
                                        </a>
                                    </li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <a class="dropdown-item btn-edit-cita" href="#" data-id="${data.id}">
                                            <i class="bi bi-pencil text-muted me-2"></i>Editar Cita
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    `;
                }
            }
        ],
        order: [[0, 'desc']]
    });

    // Abrir modal nueva cita
    $('#btnNuevaCita').on('click', function() {
        $('#formCita')[0].reset();
        $('#cita_id').val('');
        $('#modalCitaTitle').text('Programar Nueva Cita');
        if ($.fn.select2) {
            $('#selectPaciente').val(null).trigger('change');
        }
        // Fecha por defecto mañana u hoy
        const hoy = new Date().toISOString().split('T')[0];
        $('#cita_fecha').val(hoy);
        $('#modalCita').modal('show');
    });

    // URL parameters handler (e.g. from patient table shortcut)
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('action') === 'new') {
        $('#btnNuevaCita').trigger('click');
        const pacId = urlParams.get('paciente_id');
        if (pacId) {
            $.getJSON(BASE_URL + 'ajax/pacientes.php?action=get&id=' + pacId, function(res) {
                if (res.status === 'success') {
                    const p = res.data;
                    const option = new Option(`${p.codigo} - ${p.nombres} ${p.apellidos} (${p.cedula})`, p.id, true, true);
                    $('#selectPaciente').append(option).trigger('change');
                }
            });
        }
    }

    // Abrir modal editar cita
    $('#tablaCitas').on('click', '.btn-edit-cita', function(e) {
        e.preventDefault();
        const id = $(this).data('id');
        $.getJSON(BASE_URL + 'ajax/citas.php?action=get&id=' + id, function(res) {
            if (res.status === 'success') {
                const c = res.data;
                $('#cita_id').val(c.id);
                $('#cita_doctor_id').val(c.doctor_id);
                $('#cita_fecha').val(c.fecha);
                $('#cita_hora').val(c.hora.substring(0, 5));
                $('#cita_motivo').val(c.motivo);
                $('#cita_observaciones').val(c.observaciones);
                $('#cita_estado').val(c.estado);

                if ($.fn.select2) {
                    const option = new Option(`${c.paciente_codigo} - ${c.paciente_nombre} (${c.paciente_cedula})`, c.paciente_id, true, true);
                    $('#selectPaciente').append(option).trigger('change');
                } else {
                    $('#selectPaciente').val(c.paciente_id);
                }

                $('#modalCitaTitle').text('Editar Cita #' + c.id);
                $('#modalCita').modal('show');
            }
        });
    });

    // Guardar cita
    $('#formCita').on('submit', function(e) {
        e.preventDefault();
        const id = $('#cita_id').val();
        const action = id ? 'update' : 'create';

        const btn = $('#btnSaveCita');
        btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span>Guardando...');

        $.ajax({
            url: BASE_URL + 'ajax/citas.php?action=' + action,
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(res) {
                if (res.status === 'success') {
                    $('#modalCita').modal('hide');
                    tableCitas.ajax.reload(null, false);
                    Swal.fire({
                        icon: 'success',
                        title: 'Éxito',
                        text: res.message,
                        timer: 1500,
                        showConfirmButton: false
                    });
                } else {
                    Swal.fire({ icon: 'warning', title: 'Atención', text: res.message });
                }
                btn.prop('disabled', false).html('<i class="bi bi-calendar-check me-1"></i>Guardar Cita');
            },
            error: function(xhr) {
                let msg = 'Error en el servidor al agendar la cita.';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    msg = xhr.responseJSON.message;
                }
                Swal.fire({ icon: 'error', title: 'Error', text: msg });
                btn.prop('disabled', false).html('<i class="bi bi-calendar-check me-1"></i>Guardar Cita');
            }
        });
    });

    // Cambiar estado rápido de cita
    $('#tablaCitas').on('click', '.btn-status', function(e) {
        e.preventDefault();
        const id = $(this).data('id');
        const status = $(this).data('status');

        $.post(BASE_URL + 'ajax/citas.php?action=update_status', {
            id: id,
            status: status,
            csrf_token: CSRF_TOKEN
        }, function(res) {
            if (res.status === 'success') {
                tableCitas.ajax.reload(null, false);
                Swal.fire({
                    icon: 'success',
                    title: 'Estado actualizado',
                    text: res.message,
                    timer: 1200,
                    showConfirmButton: false
                });
            } else {
                Swal.fire({ icon: 'error', title: 'Error', text: res.message });
            }
        }, 'json');
    });

    // Filtros de fecha y doctor
    $('#filtroDoctor, #filtroEstado, #filtroFecha').on('change', function() {
        const doc = $('#filtroDoctor').val();
        const est = $('#filtroEstado').val();
        const fec = $('#filtroFecha').val();

        let newUrl = `${BASE_URL}ajax/citas.php?action=list&doctor_id=${doc}&estado=${est}&fecha=${fec}`;
        tableCitas.ajax.url(newUrl).load();
    });

    $('#btnResetFiltros').on('click', function() {
        $('#filtroDoctor').val('');
        $('#filtroEstado').val('');
        $('#filtroFecha').val('');
        tableCitas.ajax.url(`${BASE_URL}ajax/citas.php?action=list`).load();
    });
});

