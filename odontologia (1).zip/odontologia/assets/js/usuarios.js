$(document).ready(function() {
    let tableUsuarios = $('#tablaUsuarios').DataTable({
        language: dtSpanish,
        responsive: true,
        ajax: {
            url: BASE_URL + 'ajax/usuarios.php?action=list',
            dataSrc: 'data'
        },
        columns: [
            {
                data: null,
                render: function(data) {
                    return `<strong>${data.nombres} ${data.apellidos}</strong><br><small class="text-muted">${data.cedula}</small>`;
                }
            },
            {
                data: 'rol_nombre',
                render: function(data) {
                    let badge = 'bg-secondary';
                    if (data === 'Administrador') badge = 'bg-primary';
                    if (data === 'Doctor') badge = 'bg-info text-dark';
                    if (data === 'Asistente') badge = 'bg-warning text-dark';
                    return `<span class="badge ${badge}">${data}</span>`;
                }
            },
            {
                data: 'usuario',
                render: function(data) {
                    return `<code>@${data}</code>`;
                }
            },
            {
                data: null,
                render: function(data) {
                    return `${data.email}<br><small class="text-muted">${data.telefono || 'Sin teléfono'}</small>`;
                }
            },
            {
                data: 'especialidad',
                render: function(data) {
                    return data ? `<span class="small">${data}</span>` : '<span class="text-muted small">N/A</span>';
                }
            },
            {
                data: 'estado',
                render: function(data) {
                    return data === 'activo' 
                        ? '<span class="badge bg-success">Activo</span>' 
                        : '<span class="badge bg-danger">Inactivo</span>';
                }
            },
            {
                data: null,
                orderable: false,
                className: 'text-end',
                render: function(data) {
                    const toggleIcon = data.estado === 'activo' ? 'bi-toggle2-on text-success' : 'bi-toggle2-off text-muted';
                    const toggleTitle = data.estado === 'activo' ? 'Desactivar usuario' : 'Activar usuario';
                    return `
                        <div class="btn-group btn-group-sm">
                            <button class="btn btn-outline-primary btn-edit" data-id="${data.id}" title="Editar">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <button class="btn btn-outline-secondary btn-toggle" data-id="${data.id}" title="${toggleTitle}">
                                <i class="bi ${toggleIcon} fs-6"></i>
                            </button>
                        </div>
                    `;
                }
            }
        ],
        order: [[0, 'asc']]
    });

    // Mostrar campos de Doctor según rol seleccionado
    $('#rol_id').on('change', function() {
        const val = $(this).val();
        if (val === '2') { // Doctor
            $('#camposDoctor').slideDown(200);
        } else {
            $('#camposDoctor').slideUp(200);
            $('#especialidad, #colegiatura').val('');
        }
    });

    // Abrir modal para crear usuario
    $('#btnNuevoUsuario').on('click', function() {
        $('#formUsuario')[0].reset();
        $('#usuario_id').val('');
        $('#modalUsuarioTitle').text('Registrar Nuevo Usuario');
        $('#passwordHelp').text('Mínimo 6 caracteres.');
        $('#password').prop('required', true);
        $('#camposDoctor').hide();
        $('#modalUsuario').modal('show');
    });

    // Abrir modal para editar usuario
    $('#tablaUsuarios').on('click', '.btn-edit', function() {
        const id = $(this).data('id');
        $.getJSON(BASE_URL + 'ajax/usuarios.php?action=get&id=' + id, function(res) {
            if (res.status === 'success') {
                const u = res.data;
                $('#usuario_id').val(u.id);
                $('#rol_id').val(u.rol_id);
                $('#nombres').val(u.nombres);
                $('#apellidos').val(u.apellidos);
                $('#cedula').val(u.cedula);
                $('#email').val(u.email);
                $('#telefono').val(u.telefono);
                $('#usuario').val(u.usuario);
                $('#estado').val(u.estado);
                $('#especialidad').val(u.especialidad);
                $('#colegiatura').val(u.colegiatura);

                if (u.rol_id == 2) {
                    $('#camposDoctor').show();
                } else {
                    $('#camposDoctor').hide();
                }

                $('#password').prop('required', false).val('');
                $('#passwordHelp').text('Deje en blanco si no desea cambiar la contraseña actual.');
                $('#modalUsuarioTitle').text('Editar Usuario: ' + u.usuario);
                $('#modalUsuario').modal('show');
            }
        });
    });

    // Guardar usuario (Crear / Actualizar)
    $('#formUsuario').on('submit', function(e) {
        e.preventDefault();
        const id = $('#usuario_id').val();
        const action = id ? 'update' : 'create';

        const btn = $('#btnSaveUsuario');
        btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span>Guardando...');

        $.ajax({
            url: BASE_URL + 'ajax/usuarios.php?action=' + action,
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(res) {
                if (res.status === 'success') {
                    $('#modalUsuario').modal('hide');
                    tableUsuarios.ajax.reload(null, false);
                    Swal.fire({
                        icon: 'success',
                        title: 'Éxito',
                        text: res.message,
                        timer: 1500,
                        showConfirmButton: false
                    });
                } else {
                    Swal.fire({ icon: 'error', title: 'Error', text: res.message });
                }
                btn.prop('disabled', false).html('<i class="bi bi-save me-1"></i>Guardar');
            },
            error: function(xhr) {
                let msg = 'Error en el servidor.';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    msg = xhr.responseJSON.message;
                }
                Swal.fire({ icon: 'error', title: 'Error', text: msg });
                btn.prop('disabled', false).html('<i class="bi bi-save me-1"></i>Guardar');
            }
        });
    });

    // Alternar estado activo/inactivo
    $('#tablaUsuarios').on('click', '.btn-toggle', function() {
        const id = $(this).data('id');
        Swal.fire({
            title: '¿Cambiar estado del usuario?',
            text: 'Se activará o desactivará el acceso al sistema.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#0d6efd',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Sí, cambiar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                $.post(BASE_URL + 'ajax/usuarios.php?action=toggle', { id: id, csrf_token: CSRF_TOKEN }, function(res) {
                    if (res.status === 'success') {
                        tableUsuarios.ajax.reload(null, false);
                        Swal.fire({ icon: 'success', title: 'Listo', text: res.message, timer: 1200, showConfirmButton: false });
                    } else {
                        Swal.fire({ icon: 'error', title: 'Error', text: res.message });
                    }
                }, 'json').fail(function() {
                    Swal.fire({ icon: 'error', title: 'Error', text: 'No se pudo cambiar el estado del usuario.' });
                });
            }
        });
    });
});

