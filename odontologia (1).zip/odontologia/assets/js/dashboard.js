$(document).ready(function() {
    loadDashboardStats();
    loadDashboardCharts();
    loadTodayAppointments();

    function loadDashboardStats() {
        $.getJSON(BASE_URL + 'ajax/dashboard.php?action=stats', function(res) {
            if (res.status === 'success') {
                const d = res.data;
                $('#statPacientes').text(d.total_pacientes);
                $('#statCitasHoy').text(d.citas_hoy);
                $('#statConsultasMes').text(d.consultas_mes);
                $('#statProcedimientosMes').text(d.procedimientos_mes);
            }
        });
    }

    function loadDashboardCharts() {
        $.getJSON(BASE_URL + 'ajax/dashboard.php?action=charts', function(res) {
            if (res.status === 'success') {
                const chartData = res.data;

                // Gráfico de Procedimientos más frecuentes
                const procLabels = chartData.top_procedures.map(p => p.nombre.length > 25 ? p.nombre.substring(0, 25) + '...' : p.nombre);
                const procCounts = chartData.top_procedures.map(p => p.total);

                const ctxProc = document.getElementById('chartProcedimientos');
                if (ctxProc) {
                    new Chart(ctxProc, {
                        type: 'doughnut',
                        data: {
                            labels: procLabels.length ? procLabels : ['Sin registros'],
                            datasets: [{
                                data: procCounts.length ? procCounts : [1],
                                backgroundColor: [
                                    '#0d6efd', '#20c997', '#ffc107', '#0dcaf0', '#6610f2', '#fd7e14'
                                ],
                                borderWidth: 2,
                                borderColor: '#ffffff'
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: {
                                    position: 'bottom',
                                    labels: { boxWidth: 12, font: { size: 11 } }
                                }
                            }
                        }
                    });
                }

                // Gráfico de Consultas Mensuales
                const ctxMonthly = document.getElementById('chartConsultasMensuales');
                if (ctxMonthly) {
                    const monthLabels = chartData.monthly_consultations.map(m => m.etiqueta);
                    const monthCounts = chartData.monthly_consultations.map(m => m.total);

                    new Chart(ctxMonthly, {
                        type: 'bar',
                        data: {
                            labels: monthLabels.length ? monthLabels : ['Mes actual'],
                            datasets: [{
                                label: 'Consultas Realizadas',
                                data: monthCounts.length ? monthCounts : [0],
                                backgroundColor: '#0d6efd',
                                borderRadius: 6
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    ticks: { stepSize: 1 }
                                }
                            },
                            plugins: {
                                legend: { display: false }
                            }
                        }
                    });
                }
            }
        });
    }

    function loadTodayAppointments() {
        $.getJSON(BASE_URL + 'ajax/dashboard.php?action=today_appointments', function(res) {
            const tbody = $('#tableCitasHoy tbody');
            tbody.empty();

            if (res.status === 'success' && res.data.length > 0) {
                res.data.forEach(cita => {
                    let badgeClass = 'bg-warning text-dark';
                    if (cita.estado === 'atendida') badgeClass = 'bg-success';
                    if (cita.estado === 'en_atencion') badgeClass = 'bg-primary';
                    if (cita.estado === 'cancelada') badgeClass = 'bg-danger';
                    if (cita.estado === 'no_asistio') badgeClass = 'bg-secondary';

                    const estadoLabel = cita.estado.replace('_', ' ').toUpperCase();

                    let actionsHtml = '';
                    if (cita.estado === 'pendiente' || cita.estado === 'en_atencion') {
                        actionsHtml = `
                            <a href="${BASE_URL}views/consultas/atender.php?cita_id=${cita.id}&paciente_id=${cita.paciente_id}" class="btn btn-sm btn-primary">
                                <i class="bi bi-clipboard2-pulse me-1"></i>Atender
                            </a>
                        `;
                    } else if (cita.estado === 'atendida' && cita.consulta_id) {
                        actionsHtml = `
                            <a href="${BASE_URL}reports/historia_pdf.php?id=${cita.paciente_id}" target="_blank" class="btn btn-sm btn-outline-danger">
                                <i class="bi bi-file-pdf me-1"></i>PDF
                            </a>
                        `;
                    }

                    tbody.append(`
                        <tr>
                            <td><strong>${cita.hora.substring(0, 5)}</strong></td>
                            <td>
                                <div class="fw-semibold">${cita.paciente_nombre}</div>
                                <small class="text-muted">${cita.paciente_cedula}</small>
                            </td>
                            <td>Dr(a). ${cita.doctor_nombre}</td>
                            <td>${cita.motivo}</td>
                            <td><span class="badge ${badgeClass}">${estadoLabel}</span></td>
                            <td class="text-end">${actionsHtml}</td>
                        </tr>
                    `);
                });
            } else {
                tbody.append(`
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            <i class="bi bi-calendar-check fs-2 d-block mb-1"></i>
                            No hay citas programadas para el día de hoy.
                        </td>
                    </tr>
                `);
            }
        });
    }
});

