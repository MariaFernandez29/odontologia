$(document).ready(function() {
    let procedimientosCatalogo = [];

    // Cargar catálogo de procedimientos para los selectores dinámicos
    $.getJSON(BASE_URL + 'ajax/procedimientos.php?action=list&active=1', function(res) {
        if (res.status === 'success') {
            procedimientosCatalogo = res.data;
        }
    });

    // Inicializar selector de pacientes
    if ($.fn.select2) {
        $('#selectPacienteConsulta').select2({
            theme: 'bootstrap-5',
            placeholder: 'Buscar paciente por nombre o cédula...',
            minimumInputLength: 2,
            ajax: {
                url: BASE_URL + 'ajax/pacientes.php?action=search',
                dataType: 'json',
                delay: 250,
                data: function(params) {
                    return { q: params.term };
                },
                processResults: function(data) {
                    return {
                        results: data.data.map(p => ({
                            id: p.id,
                            text: `${p.codigo} - ${p.nombres} ${p.apellidos} (${p.cedula})`
                        }))
                    };
                },
                cache: true
            }
        });
    }

    // Al seleccionar paciente, cargar su resumen y alertas
    $('#selectPacienteConsulta').on('change', function() {
        const id = $(this).val();
        if (id) {
            cargarFichaPaciente(id);
        } else {
            $('#panelInfoPaciente').slideUp(200);
        }
    });

    function cargarFichaPaciente(id) {
        $.getJSON(BASE_URL + 'ajax/pacientes.php?action=get&id=' + id, function(res) {
            if (res.status === 'success') {
                const p = res.data;
                $('#infoPacienteNombre').text(`${p.nombres} ${p.apellidos}`);
                $('#infoPacienteCodigo').text(p.codigo);
                $('#infoPacienteCedula').text(p.cedula);
                $('#infoPacienteEdad').text(`${p.edad} años`);
                $('#infoPacienteSexo').text(p.sexo === 'M' ? 'Masculino' : (p.sexo === 'F' ? 'Femenino' : 'Otro'));
                $('#infoPacienteSangre').text(p.grupo_sanguineo || 'N/R');

                if (p.alergias) {
                    $('#infoPacienteAlergias').html(`
                        <div class="alert alert-warning py-1 px-2 mb-0 d-inline-block small">
                            <i class="bi bi-exclamation-triangle-fill me-1"></i><strong>Alerta:</strong> ${p.alergias}
                        </div>
                    `);
                } else {
                    $('#infoPacienteAlergias').html('<span class="text-muted small">Sin alergias registradas</span>');
                }

                $('#btnVerHistorialPrevio').attr('href', `${BASE_URL}views/historia/index.php?paciente_id=${p.id}`);
                $('#panelInfoPaciente').slideDown(200);
            }
        });
    }

    // Si viene paciente_id por URL (desde citas o pacientes)
    const urlParams = new URLSearchParams(window.location.search);
    const pacIdUrl = urlParams.get('paciente_id');
    const citaIdUrl = urlParams.get('cita_id');

    if (citaIdUrl) {
        $('#cita_id_hidden').val(citaIdUrl);
        // Cargar motivo de la cita
        $.getJSON(BASE_URL + 'ajax/citas.php?action=get&id=' + citaIdUrl, function(res) {
            if (res.status === 'success') {
                const c = res.data;
                if (!$('#motivo_consulta').val()) {
                    $('#motivo_consulta').val(c.motivo);
                }
            }
        });
    }

    if (pacIdUrl) {
        $.getJSON(BASE_URL + 'ajax/pacientes.php?action=get&id=' + pacIdUrl, function(res) {
            if (res.status === 'success') {
                const p = res.data;
                const option = new Option(`${p.codigo} - ${p.nombres} ${p.apellidos} (${p.cedula})`, p.id, true, true);
                $('#selectPacienteConsulta').append(option).trigger('change');
            }
        });
    }

    // ==========================================
    // AGREGAR / ELIMINAR DIAGNÓSTICOS DINÁMICOS
    // ==========================================
    let diagIndex = 0;
    function agregarFilaDiagnostico(pieza = '', tipo = 'definitivo', descripcion = '') {
        diagIndex++;
        const rowHtml = `
            <tr id="diagRow_${diagIndex}">
                <td style="width: 20%;">
                    <input type="text" class="form-control form-control-sm diag-pieza" placeholder="Ej: 18, 36, Toda" value="${pieza}">
                </td>
                <td style="width: 25%;">
                    <select class="form-select form-select-sm diag-tipo">
                        <option value="definitivo" ${tipo === 'definitivo' ? 'selected' : ''}>Definitivo</option>
                        <option value="presuntivo" ${tipo === 'presuntivo' ? 'selected' : ''}>Presuntivo</option>
                    </select>
                </td>
                <td style="width: 45%;">
                    <input type="text" class="form-control form-control-sm diag-desc" placeholder="Descripción del diagnóstico" value="${descripcion}" required>
                </td>
                <td style="width: 10%;" class="text-end">
                    <button type="button" class="btn btn-sm btn-outline-danger btn-del-diag" data-target="#diagRow_${diagIndex}">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
        $('#tablaDiagnosticos tbody').append(rowHtml);
    }

    $('#btnAddDiagnostico').on('click', function() {
        agregarFilaDiagnostico();
    });

    $('#tablaDiagnosticos').on('click', '.btn-del-diag', function() {
        const target = $(this).data('target');
        $(target).remove();
    });

    // Agregar una fila inicial por defecto
    agregarFilaDiagnostico();

    // ==========================================
    // AGREGAR / ELIMINAR PROCEDIMIENTOS REALIZADOS
    // ==========================================
    let procIndex = 0;
    function agregarFilaProcedimiento(procId = '', pieza = '', obs = '') {
        procIndex++;
        let optionsProc = '<option value="">Seleccione procedimiento...</option>';
        procedimientosCatalogo.forEach(p => {
            const selected = (p.id == procId) ? 'selected' : '';
            optionsProc += `<option value="${p.id}" ${selected}>${p.nombre} (${p.categoria || 'General'})</option>`;
        });

        const rowHtml = `
            <tr id="procRow_${procIndex}">
                <td style="width: 45%;">
                    <select class="form-select form-select-sm proc-id" required>
                        ${optionsProc}
                    </select>
                </td>
                <td style="width: 18%;">
                    <input type="text" class="form-control form-control-sm proc-pieza" placeholder="Ej: 38, Cuadrante 2" value="${pieza}">
                </td>
                <td style="width: 27%;">
                    <input type="text" class="form-control form-control-sm proc-obs" placeholder="Observaciones / técnica" value="${obs}">
                </td>
                <td style="width: 10%;" class="text-end">
                    <button type="button" class="btn btn-sm btn-outline-danger btn-del-proc" data-target="#procRow_${procIndex}">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
        $('#tablaConsultaProcedimientos tbody').append(rowHtml);
    }

    $('#btnAddProcedimiento').on('click', function() {
        agregarFilaProcedimiento();
    });

    $('#tablaConsultaProcedimientos').on('click', '.btn-del-proc', function() {
        const target = $(this).data('target');
        $(target).remove();
    });

    // Agregar una fila inicial de procedimiento
    setTimeout(function() {
        agregarFilaProcedimiento();
    }, 400);

    // ==========================================
    // ENVÍO DE LA ATENCIÓN CLÍNICA (AJAX)
    // ==========================================
    $('#formAtenderConsulta').on('submit', function(e) {
        e.preventDefault();

        const pacienteId = $('#selectPacienteConsulta').val();
        if (!pacienteId) {
            Swal.fire({ icon: 'warning', title: 'Atención', text: 'Debe seleccionar al paciente para atender la consulta.' });
            return;
        }

        const motivo = $('#motivo_consulta').val().trim();
        if (!motivo) {
            Swal.fire({ icon: 'warning', title: 'Atención', text: 'El motivo de consulta es obligatorio.' });
            return;
        }

        // Recolectar diagnósticos
        const diagnosticos = [];
        $('#tablaDiagnosticos tbody tr').each(function() {
            const pieza = $(this).find('.diag-pieza').val().trim();
            const tipo = $(this).find('.diag-tipo').val();
            const desc = $(this).find('.diag-desc').val().trim();
            if (desc) {
                diagnosticos.push({ pieza_dental: pieza, tipo: tipo, descripcion: desc });
            }
        });

        // Recolectar procedimientos
        const procedimientos = [];
        $('#tablaConsultaProcedimientos tbody tr').each(function() {
            const procId = $(this).find('.proc-id').val();
            const pieza = $(this).find('.proc-pieza').val().trim();
            const obs = $(this).find('.proc-obs').val().trim();
            if (procId) {
                procedimientos.push({ procedimiento_id: procId, pieza_dental: pieza, observaciones: obs });
            }
        });

        // Preparar FormData
        const formData = new FormData(this);
        formData.append('paciente_id', pacienteId);
        formData.append('diagnosticos', JSON.stringify(diagnosticos));
        formData.append('procedimientos', JSON.stringify(procedimientos));

        const btn = $('#btnGuardarConsulta');
        btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span>Registrando atención...');

        $.ajax({
            url: BASE_URL + 'ajax/consultas.php?action=create',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(res) {
                if (res.status === 'success') {
                    const data = res.data;
                    Swal.fire({
                        icon: 'success',
                        title: '¡Consulta Registrada!',
                        text: 'La historia clínica y los procedimientos fueron guardados exitosamente.',
                        showDenyButton: true,
                        showCancelButton: true,
                        confirmButtonColor: '#0d6efd',
                        denyButtonColor: '#dc3545',
                        cancelButtonColor: '#6c757d',
                        confirmButtonText: '<i class="bi bi-file-earmark-medical me-1"></i>Ver Historia',
                        denyButtonText: '<i class="bi bi-file-pdf me-1"></i>Descargar PDF',
                        cancelButtonText: 'Ir a Agenda'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = `${BASE_URL}views/historia/index.php?paciente_id=${data.paciente_id}`;
                        } else if (result.isDenied) {
                            window.open(`${BASE_URL}reports/historia_pdf.php?id=${data.paciente_id}`, '_blank');
                            window.location.href = `${BASE_URL}views/citas/index.php`;
                        } else {
                            window.location.href = `${BASE_URL}views/citas/index.php`;
                        }
                    });
                } else {
                    Swal.fire({ icon: 'error', title: 'Error', text: res.message });
                    btn.prop('disabled', false).html('<i class="bi bi-check2-circle me-1"></i>Finalizar y Guardar Atención');
                }
            },
            error: function(xhr) {
                let msg = 'Error en el servidor al guardar la consulta.';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    msg = xhr.responseJSON.message;
                }
                Swal.fire({ icon: 'error', title: 'Error', text: msg });
                btn.prop('disabled', false).html('<i class="bi bi-check2-circle me-1"></i>Finalizar y Guardar Atención');
            }
        });
    });
});

