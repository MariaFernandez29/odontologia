<?php

if (!defined('APP_INIT')) {
    define('APP_INIT', true);
}

// Zona horaria y codificación
date_default_timezone_set('America/Caracas');
ini_set('default_charset', 'UTF-8');
if (function_exists('mb_internal_encoding')) {
    mb_internal_encoding('UTF-8');
}

// Configuración de la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'odontologia_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Rutas del sistema
define('ROOT_PATH', dirname(__DIR__) . DIRECTORY_SEPARATOR);
define('APP_PATH', ROOT_PATH . 'app' . DIRECTORY_SEPARATOR);
define('CONFIG_PATH', ROOT_PATH . 'config' . DIRECTORY_SEPARATOR);
define('VIEWS_PATH', ROOT_PATH . 'views' . DIRECTORY_SEPARATOR);
define('UPLOADS_PATH', ROOT_PATH . 'uploads' . DIRECTORY_SEPARATOR);
define('LOGO_PATH', UPLOADS_PATH . 'logo' . DIRECTORY_SEPARATOR);

// Detección dinámica de BASE_URL
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
$baseDir = preg_replace('#/(ajax|views|reports|app|config)(/.*)?$#i', '', $scriptDir);
$baseDir = rtrim($baseDir, '/');

define('BASE_URL', $protocol . $host . $baseDir . '/');
define('ASSETS_URL', BASE_URL . 'assets/');
define('UPLOADS_URL', BASE_URL . 'uploads/');

// Autoload de Composer
if (file_exists(ROOT_PATH . 'vendor/autoload.php')) {
    require_once ROOT_PATH . 'vendor/autoload.php';
}

require_once CONFIG_PATH . 'Database.php';

// Alias globales para uso directo en vistas
if (!class_exists('Auth', false)) {
    class_alias(\App\Core\Auth::class, 'Auth');
}
if (!class_exists('Csrf', false)) {
    class_alias(\App\Core\Csrf::class, 'Csrf');
}
if (!class_exists('Session', false)) {
    class_alias(\App\Core\Session::class, 'Session');
}
if (!class_exists('Settings', false)) {
    class_alias(\App\Core\Settings::class, 'Settings');
}
if (!class_exists('Response', false)) {
    class_alias(\App\Core\Response::class, 'Response');
}

// Configuración de sesiones seguras
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_only_cookies', 1);
    ini_set('session.use_strict_mode', 1);
    session_start();
}
