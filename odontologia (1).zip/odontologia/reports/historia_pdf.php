<?php

require_once __DIR__ . '/../config/config.php';

use App\Core\Auth;
use App\Core\Settings;
use App\Models\Paciente;
use App\Models\Consulta;
use Dompdf\Dompdf;
use Dompdf\Options;

Auth::requireLogin();

// Solo Administrador y Doctor pueden emitir la historia clínica
if (!Auth::isAdmin() && !Auth::isDoctor()) {
    die("Acceso no autorizado para generar historias clínicas.");
}

$pacienteId = (int)($_GET['id'] ?? 0);
if (!$pacienteId) {
    die("ID de paciente no válido.");
}

$paciente = Paciente::find($pacienteId);
if (!$paciente) {
    die("Paciente no encontrado en el sistema.");
}

$consultas = Consulta::getByPaciente($pacienteId);
$settings = Settings::get();

// Procesar logo a base64 para Dompdf
$logoBase64 = null;
if (!empty($settings['logo']) && file_exists(LOGO_PATH . $settings['logo'])) {
    $logoData = file_get_contents(LOGO_PATH . $settings['logo']);
    $logoMime = mime_content_type(LOGO_PATH . $settings['logo']);
    $logoBase64 = 'data:' . $logoMime . ';base64,' . base64_encode($logoData);
}

// Iniciar buffer HTML
ob_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Historia Clínica - <?= htmlspecialchars($paciente['codigo']) ?></title>
    <style>
        @page {
            margin: 20mm 15mm 20mm 15mm;
            size: letter portrait;
        }
        body {
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            font-size: 11px;
            color: #2c3e50;
            line-height: 1.4;
        }
        .header-table {
            width: 100%;
            border-bottom: 2px solid #0d6efd;
            padding-bottom: 12px;
            margin-bottom: 15px;
        }
        .clinic-name {
            font-size: 18px;
            font-weight: bold;
            color: #0d6efd;
            text-transform: uppercase;
        }
        .clinic-info {
            font-size: 9px;
            color: #6c757d;
        }
        .doc-title-box {
            text-align: right;
        }
        .doc-title {
            font-size: 15px;
            font-weight: bold;
            color: #212529;
            margin: 0;
        }
        .doc-code {
            font-size: 12px;
            font-weight: bold;
            color: #0d6efd;
        }
        .section-title {
            background-color: #f1f4f9;
            color: #0d6efd;
            font-size: 11px;
            font-weight: bold;
            padding: 5px 8px;
            text-transform: uppercase;
            border-left: 4px solid #0d6efd;
            margin-top: 14px;
            margin-bottom: 8px;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }
        .data-table td {
            padding: 4px 6px;
            vertical-align: top;
        }
        .data-label {
            font-weight: bold;
            color: #495057;
            width: 25%;
        }
        .data-value {
            color: #212529;
            width: 25%;
        }
        .alert-box {
            background-color: #fff3cd;
            border: 1px solid #ffe69c;
            color: #664d03;
            padding: 6px 10px;
            border-radius: 4px;
            font-size: 10px;
            margin-bottom: 10px;
        }
        .consult-card {
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 10px;
            margin-bottom: 15px;
            page-break-inside: avoid;
        }
        .consult-header {
            border-bottom: 1px dashed #adb5bd;
            padding-bottom: 5px;
            margin-bottom: 8px;
        }
        .vitals-table {
            width: 100%;
            border-collapse: collapse;
            margin: 6px 0;
            font-size: 9.5px;
        }
        .vitals-table th {
            background-color: #e9ecef;
            border: 1px solid #ced4da;
            padding: 4px;
            text-align: center;
        }
        .vitals-table td {
            border: 1px solid #ced4da;
            padding: 4px;
            text-align: center;
        }
        .subtable {
            width: 100%;
            border-collapse: collapse;
            margin-top: 6px;
            margin-bottom: 8px;
            font-size: 10px;
        }
        .subtable th {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            padding: 4px 6px;
            text-align: left;
        }
        .subtable td {
            border: 1px solid #dee2e6;
            padding: 4px 6px;
        }
        .badge {
            display: inline-block;
            padding: 2px 5px;
            font-size: 8.5px;
            font-weight: bold;
            border-radius: 3px;
        }
        .badge-primary { background: #cfe2ff; color: #084298; }
        .badge-success { background: #d1e7dd; color: #0f5132; }
        .footer-note {
            text-align: center;
            font-size: 8.5px;
            color: #868e96;
            border-top: 1px solid #dee2e6;
            padding-top: 8px;
            margin-top: 25px;
        }
        .signatures {
            margin-top: 40px;
            width: 100%;
            page-break-inside: avoid;
        }
        .sig-line {
            border-top: 1px solid #495057;
            width: 80%;
            margin: 0 auto;
            text-align: center;
            padding-top: 4px;
            font-size: 10px;
        }
    </style>
</head>
<body>

    <!-- Encabezado Clínico -->
    <table class="header-table">
        <tr>
            <td style="width: 15%; vertical-align: middle;">
                <?php if ($logoBase64): ?>
                    <img src="<?= $logoBase64 ?>" style="max-height: 55px; max-width: 110px;">
                <?php else: ?>
                    <div style="font-size: 26px; color: #0d6efd; font-weight: bold;">✚</div>
                <?php endif; ?>
            </td>
            <td style="width: 50%; vertical-align: middle;">
                <div class="clinic-name"><?= htmlspecialchars($settings['nombre_clinica']) ?></div>
                <div class="clinic-info">
                    <?php if (!empty($settings['ruc_nit'])): ?>RIF/NIT: <?= htmlspecialchars($settings['ruc_nit']) ?> | <?php endif; ?>
                    Tel: <?= htmlspecialchars($settings['telefono']) ?><br>
                    <?= htmlspecialchars($settings['direccion']) ?><br>
                    <?= htmlspecialchars($settings['email']) ?>
                </div>
            </td>
            <td style="width: 35%; vertical-align: middle;" class="doc-title-box">
                <div class="doc-title">HISTORIA CLÍNICA</div>
                <div class="doc-code"><?= htmlspecialchars($paciente['codigo']) ?></div>
                <div style="font-size: 9px; color: #6c757d; margin-top: 3px;">
                    Fecha de emisión: <?= date('d/m/Y H:i') ?>
                </div>
            </td>
        </tr>
    </table>

    <!-- Datos de Filiación del Paciente -->
    <div class="section-title">1. Datos Personales del Paciente</div>
    <table class="data-table">
        <tr>
            <td class="data-label">Nombre Completo:</td>
            <td class="data-value" colspan="3"><strong><?= htmlspecialchars($paciente['nombres'] . ' ' . $paciente['apellidos']) ?></strong></td>
        </tr>
        <tr>
            <td class="data-label">Cédula / Documento:</td>
            <td class="data-value"><?= htmlspecialchars($paciente['cedula']) ?></td>
            <td class="data-label">Fecha Nacimiento (Edad):</td>
            <td class="data-value"><?= date('d/m/Y', strtotime($paciente['fecha_nacimiento'])) ?> (<?= $paciente['edad'] ?> años)</td>
        </tr>
        <tr>
            <td class="data-label">Sexo:</td>
            <td class="data-value"><?= $paciente['sexo'] === 'M' ? 'Masculino' : ($paciente['sexo'] === 'F' ? 'Femenino' : 'Otro') ?></td>
            <td class="data-label">Grupo Sanguíneo:</td>
            <td class="data-value"><?= htmlspecialchars($paciente['grupo_sanguineo'] ?: 'No registrado') ?></td>
        </tr>
        <tr>
            <td class="data-label">Teléfono:</td>
            <td class="data-value"><?= htmlspecialchars($paciente['telefono'] ?: 'No registrado') ?></td>
            <td class="data-label">Correo Electrónico:</td>
            <td class="data-value"><?= htmlspecialchars($paciente['email'] ?: 'No registrado') ?></td>
        </tr>
        <tr>
            <td class="data-label">Ocupación:</td>
            <td class="data-value"><?= htmlspecialchars($paciente['ocupacion'] ?: 'No registrada') ?></td>
            <td class="data-label">Contacto Emergencia:</td>
            <td class="data-value"><?= htmlspecialchars($paciente['contacto_emergencia'] ?: 'No registrado') ?> <?= $paciente['telefono_emergencia'] ? '(' . htmlspecialchars($paciente['telefono_emergencia']) . ')' : '' ?></td>
        </tr>
        <tr>
            <td class="data-label">Dirección:</td>
            <td class="data-value" colspan="3"><?= htmlspecialchars($paciente['direccion'] ?: 'No registrada') ?></td>
        </tr>
    </table>

    <!-- Antecedentes Médicos -->
    <div class="section-title">2. Antecedentes Médicos y Factores de Riesgo</div>
    <?php if (!empty($paciente['alergias'])): ?>
        <div class="alert-box">
            <strong>⚠️ ALERTA MÉDICA / ALERGIAS:</strong> <?= htmlspecialchars($paciente['alergias']) ?>
        </div>
    <?php endif; ?>

    <table class="data-table">
        <tr>
            <td class="data-label">Alergias:</td>
            <td class="data-value"><?= htmlspecialchars($paciente['alergias'] ?: 'Ninguna conocida') ?></td>
            <td class="data-label">Enfermedades Sistémicas:</td>
            <td class="data-value"><?= htmlspecialchars($paciente['enfermedades_sistemicas'] ?: 'Ninguna') ?></td>
        </tr>
        <tr>
            <td class="data-label">Medicamentos Actuales:</td>
            <td class="data-value"><?= htmlspecialchars($paciente['medicamentos_actuales'] ?: 'Ninguno') ?></td>
            <td class="data-label">Cirugías Previas:</td>
            <td class="data-value"><?= htmlspecialchars($paciente['cirugias_previas'] ?: 'Ninguna') ?></td>
        </tr>
        <tr>
            <td class="data-label">Antecedentes Familiares:</td>
            <td class="data-value"><?= htmlspecialchars($paciente['antecedentes_familiares'] ?: 'Sin relevancia') ?></td>
            <td class="data-label">Hábitos (Tabaco/Bruxismo):</td>
            <td class="data-value"><?= htmlspecialchars($paciente['habitos'] ?: 'Ninguno') ?></td>
        </tr>
        <?php if ($paciente['sexo'] === 'F'): ?>
        <tr>
            <td class="data-label">Estado de Embarazo:</td>
            <td class="data-value" colspan="3">
                <?= $paciente['embarazo'] ? 'Sí (' . $paciente['meses_embarazo'] . ' meses)' : 'No' ?>
            </td>
        </tr>
        <?php endif; ?>
        <?php if (!empty($paciente['antecedentes_observaciones'])): ?>
        <tr>
            <td class="data-label">Observaciones Médicas:</td>
            <td class="data-value" colspan="3"><?= htmlspecialchars($paciente['antecedentes_observaciones']) ?></td>
        </tr>
        <?php endif; ?>
    </table>

    <!-- Evolución de Consultas y Procedimientos -->
    <div class="section-title">3. Registro de Atenciones Clínicas y Procedimientos</div>

    <?php if (empty($consultas)): ?>
        <p style="font-style: italic; color: #6c757d; margin: 10px 0;">No se han registrado consultas ni procedimientos para este paciente.</p>
    <?php else: ?>
        <?php foreach ($consultas as $idx => $con): ?>
            <div class="consult-card">
                <div class="consult-header">
                    <table style="width: 100%;">
                        <tr>
                            <td style="font-weight: bold; color: #0d6efd; font-size: 11px;">
                                Consulta #<?= count($consultas) - $idx ?> &bull; Fecha: <?= date('d/m/Y H:i', strtotime($con['fecha_registro'])) ?>
                            </td>
                            <td style="text-align: right; font-size: 10px; color: #495057;">
                                Odontólogo: <strong>Dr(a). <?= htmlspecialchars($con['doctor_nombre']) ?></strong>
                                <?php if (!empty($con['doctor_especialidad'])): ?> (<?= htmlspecialchars($con['doctor_especialidad']) ?>)<?php endif; ?>
                            </td>
                        </tr>
                    </table>
                </div>

                <div style="margin-bottom: 6px;">
                    <strong>Motivo de Consulta:</strong> <?= htmlspecialchars($con['motivo_consulta']) ?><br>
                    <?php if (!empty($con['enfermedad_actual'])): ?>
                        <strong>Enfermedad Actual:</strong> <?= htmlspecialchars($con['enfermedad_actual']) ?><br>
                    <?php endif; ?>
                    <?php if (!empty($con['examen_estomatologico'])): ?>
                        <strong>Examen Estomatológico:</strong> <?= htmlspecialchars($con['examen_estomatologico']) ?><br>
                    <?php endif; ?>
                </div>

                <!-- Signos Vitales -->
                <?php if (!empty($con['presion_sistolica']) || !empty($con['frecuencia_cardiaca']) || !empty($con['temperatura'])): ?>
                    <div style="font-weight: bold; margin-top: 6px; font-size: 9.5px; color: #495057;">Signos Vitales:</div>
                    <table class="vitals-table">
                        <tr>
                            <th>Presión Arterial</th>
                            <th>Frec. Cardíaca</th>
                            <th>Frec. Respiratoria</th>
                            <th>Temperatura</th>
                            <th>Sat. O2</th>
                            <th>Peso</th>
                            <th>Talla</th>
                        </tr>
                        <tr>
                            <td><?= $con['presion_sistolica'] && $con['presion_diastolica'] ? htmlspecialchars($con['presion_sistolica'] . '/' . $con['presion_diastolica'] . ' mmHg') : '---' ?></td>
                            <td><?= $con['frecuencia_cardiaca'] ? htmlspecialchars($con['frecuencia_cardiaca'] . ' bpm') : '---' ?></td>
                            <td><?= !empty($con['frecuencia_respiratoria']) ? htmlspecialchars($con['frecuencia_respiratoria'] . ' rpm') : '---' ?></td>
                            <td><?= $con['temperatura'] ? htmlspecialchars($con['temperatura'] . ' °C') : '---' ?></td>
                            <td><?= $con['saturacion_oxigeno'] ? htmlspecialchars($con['saturacion_oxigeno'] . ' %') : '---' ?></td>
                            <td><?= !empty($con['peso']) ? htmlspecialchars($con['peso'] . ' kg') : '---' ?></td>
                            <td><?= !empty($con['talla']) ? htmlspecialchars($con['talla'] . ' m') : '---' ?></td>
                        </tr>
                    </table>
                <?php endif; ?>

                <!-- Diagnósticos -->
                <?php if (!empty($con['diagnosticos'])): ?>
                    <div style="font-weight: bold; margin-top: 6px; font-size: 9.5px; color: #495057;">Diagnóstico(s):</div>
                    <table class="subtable">
                        <thead>
                            <tr>
                                <th style="width: 20%;">Pieza / Zona</th>
                                <th style="width: 20%;">Tipo</th>
                                <th style="width: 60%;">Diagnóstico</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($con['diagnosticos'] as $diag): ?>
                                <tr>
                                    <td><strong><?= htmlspecialchars($diag['pieza_dental'] ?: 'General') ?></strong></td>
                                    <td><span class="badge badge-primary"><?= ucfirst(htmlspecialchars($diag['tipo'])) ?></span></td>
                                    <td><?= htmlspecialchars($diag['descripcion']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>

                <!-- Procedimientos Odontológicos Realizados -->
                <?php if (!empty($con['procedimientos'])): ?>
                    <div style="font-weight: bold; margin-top: 6px; font-size: 9.5px; color: #495057;">Procedimiento(s) Odontológico(s) Realizado(s):</div>
                    <table class="subtable">
                        <thead>
                            <tr>
                                <th style="width: 45%;">Procedimiento</th>
                                <th style="width: 20%;">Categoría</th>
                                <th style="width: 15%;">Pieza Dental</th>
                                <th style="width: 20%;">Observaciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($con['procedimientos'] as $proc): ?>
                                <tr>
                                    <td><strong><?= htmlspecialchars($proc['procedimiento_nombre']) ?></strong></td>
                                    <td><?= htmlspecialchars($proc['categoria'] ?: 'General') ?></td>
                                    <td><?= htmlspecialchars($proc['pieza_dental'] ?: 'N/A') ?></td>
                                    <td><?= htmlspecialchars($proc['observaciones'] ?: 'Sin observaciones') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>

                <?php if (!empty($con['indicaciones_tratamiento'])): ?>
                    <div style="margin-top: 6px; font-size: 9.5px; background: #fafafa; padding: 5px; border-left: 2px solid #198754;">
                        <strong>Indicaciones / Receta:</strong> <?= nl2br(htmlspecialchars($con['indicaciones_tratamiento'])) ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($con['proxima_cita_sugerida'])): ?>
                    <div style="margin-top: 4px; font-size: 9.5px; color: #6c757d;">
                        <strong>Próxima Cita Sugerida:</strong> <?= date('d/m/Y', strtotime($con['proxima_cita_sugerida'])) ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- Firmas -->
    <table class="signatures">
        <tr>
            <td style="width: 50%;">
                <div class="sig-line">
                    <strong>Firma del Odontólogo Tratante</strong><br>
                    Sello y Colegiatura
                </div>
            </td>
            <td style="width: 50%;">
                <div class="sig-line">
                    <strong>Firma del Paciente / Representante</strong><br>
                    C.I.: <?= htmlspecialchars($paciente['cedula']) ?>
                </div>
            </td>
        </tr>
    </table>

    <div class="footer-note">
        <?= htmlspecialchars($settings['pie_reporte']) ?><br>
        Generado el <?= date('d/m/Y') ?> a las <?= date('H:i:s') ?> &bull; Sistema de Historias Clínicas Odontológicas
    </div>

</body>
</html>
<?php
$html = ob_get_clean();

$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true);
$options->set('defaultFont', 'Helvetica');

$dompdf = new Dompdf($options);
$dompdf->loadHtml($html, 'UTF-8');
$dompdf->setPaper('letter', 'portrait');
$dompdf->render();

$filename = 'Historia_Clinica_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $paciente['codigo']) . '.pdf';
$dompdf->stream($filename, ['Attachment' => false]);
exit;

