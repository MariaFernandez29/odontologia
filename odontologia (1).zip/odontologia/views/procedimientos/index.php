<?php

$pageTitle = 'Catálogo de Procedimientos';
require_once __DIR__ . '/../layouts/header.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Models\Procedimiento;

$canEdit = Auth::isAdmin() || Auth::isDoctor();
$categories = Procedimiento::categories();
?>

<div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center mb-4 gap-2">
    <div>
        <h3 class="fw-bold mb-1"><i class="bi bi-journal-medical text-primary me-2"></i>Procedimientos Odontológicos</h3>
        <p class="text-muted mb-0">Catálogo de tratamientos clínicos (limpiezas, calzas, extracciones, conductos, blanqueamientos, etc.)</p>
    </div>
    <?php if ($canEdit): ?>
    <button class="btn btn-primary" id="btnNuevoProcedimiento">
        <i class="bi bi-plus-circle me-1"></i>Nuevo Procedimiento
    </button>
    <?php endif; ?>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle w-100" id="tablaProcedimientos">
                <thead class="table-light">
                    <tr>
                        <th style="width: 12%;">Código</th>
                        <th style="width: 28%;">Nombre del Procedimiento</th>
                        <th style="width: 15%;">Categoría</th>
                        <th style="width: 25%;">Descripción</th>
                        <th style="width: 10%;" class="text-center">Frecuencia</th>
                        <th style="width: 5%;">Estado</th>
                        <th style="width: 5%;" class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</div>

<?php if ($canEdit): ?>
<!-- Modal Crear / Editar Procedimiento -->
<div class="modal fade" id="modalProcedimiento" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-light">
                <h5 class="modal-title fw-bold" id="modalProcedimientoTitle">Registrar Procedimiento</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="formProcedimiento" novalidate>
                <div class="modal-body p-4">
                    <?= Csrf::field() ?>
                    <input type="hidden" id="procedimiento_id" name="id">

                    <div class="row g-3">
                        <div class="col-12 col-md-4">
                            <label for="proc_codigo" class="form-label fw-semibold">Código</label>
                            <input type="text" class="form-control" id="proc_codigo" name="codigo" placeholder="Ej: PROC-015">
                            <div class="form-text small">Automático si se deja vacío.</div>
                        </div>

                        <div class="col-12 col-md-8">
                            <label for="proc_categoria" class="form-label fw-semibold">Categoría <span class="text-danger">*</span></label>
                            <select class="form-select" id="proc_categoria" name="categoria" required>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= $cat ?>"><?= $cat ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-12">
                            <label for="proc_nombre" class="form-label fw-semibold">Nombre del Tratamiento / Procedimiento <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="proc_nombre" name="nombre" placeholder="Ej: Calzas de muelas (Resina compuesta)" required>
                        </div>

                        <div class="col-12">
                            <label for="proc_descripcion" class="form-label fw-semibold">Descripción / Protocolo Clínico</label>
                            <textarea class="form-control" id="proc_descripcion" name="descripcion" rows="3" placeholder="Detalles de la técnica o procedimiento"></textarea>
                        </div>

                        <div class="col-12">
                            <label for="proc_estado" class="form-label fw-semibold">Estado</label>
                            <select class="form-select" id="proc_estado" name="estado">
                                <option value="activo">Activo</option>
                                <option value="inactivo">Inactivo</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary" id="btnSaveProc">
                        <i class="bi bi-save me-1"></i>Guardar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
$extraScripts = '<script src="' . ASSETS_URL . 'js/procedimientos.js?v=1.0.1"></script>';
require_once __DIR__ . '/../layouts/footer.php';
?>

