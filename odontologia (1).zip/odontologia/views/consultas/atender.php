<?php

$pageTitle = 'Atención Odontológica';
require_once __DIR__ . '/../layouts/header.php';

use App\Core\Auth;
use App\Core\Csrf;

if (!Auth::isDoctor() && !Auth::isAdmin()) {
    header('Location: ' . BASE_URL . 'views/dashboard/index.php');
    exit;
}
?>

<div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center mb-4 gap-2">
    <div>
        <h3 class="fw-bold mb-1"><i class="bi bi-clipboard2-pulse-fill text-primary me-2"></i>Atención Clínica Odontológica</h3>
        <p class="text-muted mb-0">Registro de signos vitales, diagnóstico patológico y procedimientos realizados</p>
    </div>
    <a href="<?= BASE_URL ?>views/citas/index.php" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i>Volver a Citas
    </a>
</div>

<form id="formAtenderConsulta" novalidate>
    <?= Csrf::field() ?>
    <input type="hidden" id="cita_id_hidden" name="cita_id">

    <!-- 1. Selección y Ficha del Paciente -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-white py-3">
            <h5 class="card-title fw-bold mb-0 text-primary">
                <i class="bi bi-person-fill me-1"></i>1. Paciente a Atender
            </h5>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-12 col-md-8">
                    <label for="selectPacienteConsulta" class="form-label fw-semibold">Seleccionar Paciente <span class="text-danger">*</span></label>
                    <select class="form-select" id="selectPacienteConsulta" required>
                        <option value="">Buscar por nombre, código o cédula...</option>
                    </select>
                </div>
                <div class="col-12 col-md-4 d-flex align-items-end">
                    <a href="#" id="btnVerHistorialPrevio" target="_blank" class="btn btn-outline-primary w-100">
                        <i class="bi bi-clock-history me-1"></i>Ver Historial Previo
                    </a>
                </div>

                <!-- Banner Informativo del Paciente -->
                <div class="col-12" id="panelInfoPaciente" style="display: none;">
                    <div class="p-3 bg-light rounded border">
                        <div class="row g-2 align-items-center">
                            <div class="col-12 col-md-4">
                                <div><strong id="infoPacienteNombre" class="fs-6"></strong></div>
                                <div class="text-muted small">C.I.: <span id="infoPacienteCedula"></span> | HC: <span id="infoPacienteCodigo"></span></div>
                            </div>
                            <div class="col-6 col-md-2">
                                <span class="text-muted small">Edad/Sexo:</span><br>
                                <strong id="infoPacienteEdad"></strong> (<span id="infoPacienteSexo"></span>)
                            </div>
                            <div class="col-6 col-md-2">
                                <span class="text-muted small">Grupo Sanguíneo:</span><br>
                                <strong id="infoPacienteSangre"></strong>
                            </div>
                            <div class="col-12 col-md-4">
                                <span class="text-muted small">Antecedente de Alergias:</span><br>
                                <div id="infoPacienteAlergias"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 2. Signos Vitales -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-white py-3">
            <h5 class="card-title fw-bold mb-0 text-primary">
                <i class="bi bi-heart-pulse-fill me-1"></i>2. Signos Vitales
            </h5>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-6 col-sm-4 col-md-3">
                    <label class="form-label small fw-semibold">Presión Sistólica (mmHg)</label>
                    <input type="number" class="form-control" name="presion_sistolica" placeholder="Ej: 120" min="60" max="250">
                </div>
                <div class="col-6 col-sm-4 col-md-3">
                    <label class="form-label small fw-semibold">Presión Diastólica (mmHg)</label>
                    <input type="number" class="form-control" name="presion_diastolica" placeholder="Ej: 80" min="40" max="150">
                </div>
                <div class="col-6 col-sm-4 col-md-3">
                    <label class="form-label small fw-semibold">Frec. Cardíaca (bpm)</label>
                    <input type="number" class="form-control" name="frecuencia_cardiaca" placeholder="Ej: 72" min="30" max="200">
                </div>
                <div class="col-6 col-sm-4 col-md-3">
                    <label class="form-label small fw-semibold">Frec. Respiratoria (rpm)</label>
                    <input type="number" class="form-control" name="frecuencia_respiratoria" placeholder="Ej: 18" min="10" max="60">
                </div>

                <div class="col-6 col-sm-4 col-md-3">
                    <label class="form-label small fw-semibold">Temperatura (°C)</label>
                    <input type="number" step="0.1" class="form-control" name="temperatura" placeholder="Ej: 36.5" min="30" max="45">
                </div>
                <div class="col-6 col-sm-4 col-md-3">
                    <label class="form-label small fw-semibold">Saturación O2 (%)</label>
                    <input type="number" class="form-control" name="saturacion_oxigeno" placeholder="Ej: 98" min="50" max="100">
                </div>
                <div class="col-6 col-sm-4 col-md-3">
                    <label class="form-label small fw-semibold">Peso (kg)</label>
                    <input type="number" step="0.1" class="form-control" name="peso" placeholder="Ej: 70.5">
                </div>
                <div class="col-6 col-sm-4 col-md-3">
                    <label class="form-label small fw-semibold">Talla (m)</label>
                    <input type="number" step="0.01" class="form-control" name="talla" placeholder="Ej: 1.75">
                </div>

                <div class="col-12">
                    <label class="form-label small fw-semibold">Observaciones de Signos Vitales</label>
                    <input type="text" class="form-control form-control-sm" name="signos_observaciones" placeholder="Sin hallazgos atípicos">
                </div>
            </div>
        </div>
    </div>

    <!-- 3. Anamnesis y Examen Estomatológico -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-white py-3">
            <h5 class="card-title fw-bold mb-0 text-primary">
                <i class="bi bi-chat-left-text-fill me-1"></i>3. Motivo de Consulta y Examen Intraoral
            </h5>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-12">
                    <label for="motivo_consulta" class="form-label fw-semibold">Motivo de la Consulta <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="motivo_consulta" name="motivo_consulta" placeholder="Ej: Dolor agudo espontáneo en pieza dental 38 al masticar" required>
                </div>
                <div class="col-12 col-md-6">
                    <label for="enfermedad_actual" class="form-label fw-semibold">Enfermedad Actual / Evolución del Dolor</label>
                    <textarea class="form-control" id="enfermedad_actual" name="enfermedad_actual" rows="3" placeholder="Cronología, intensidad, factores agravantes o calmantes"></textarea>
                </div>
                <div class="col-12 col-md-6">
                    <label for="examen_estomatologico" class="form-label fw-semibold">Examen Clínico Estomatológico / Tejidos Blandos y Duros</label>
                    <textarea class="form-control" id="examen_estomatologico" name="examen_estomatologico" rows="3" placeholder="Inspección de encías, labios, lengua, oclusión y hallazgos radiográficos"></textarea>
                </div>
            </div>
        </div>
    </div>

    <!-- 4. Diagnósticos Odontológicos -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h5 class="card-title fw-bold mb-0 text-primary">
                <i class="bi bi-search me-1"></i>4. Diagnósticos Odontológicos
            </h5>
            <button type="button" class="btn btn-sm btn-outline-primary" id="btnAddDiagnostico">
                <i class="bi bi-plus-circle me-1"></i>Agregar Diagnóstico
            </button>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0" id="tablaDiagnosticos">
                    <thead class="table-light">
                        <tr>
                            <th>Pieza / Zona Dental</th>
                            <th>Tipo de Diagnóstico</th>
                            <th>Descripción Patológica</th>
                            <th class="text-end">Acción</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- 5. Procedimientos Realizados en la Sesión -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h5 class="card-title fw-bold mb-0 text-primary">
                <i class="bi bi-tools me-1"></i>5. Procedimientos Odontológicos Realizados
            </h5>
            <button type="button" class="btn btn-sm btn-outline-primary" id="btnAddProcedimiento">
                <i class="bi bi-plus-circle me-1"></i>Agregar Procedimiento
            </button>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0" id="tablaConsultaProcedimientos">
                    <thead class="table-light">
                        <tr>
                            <th>Procedimiento Clínico</th>
                            <th>Pieza Dental</th>
                            <th>Detalle / Técnica Aplicada</th>
                            <th class="text-end">Acción</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- 6. Indicaciones Médicas y Próxima Cita -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-white py-3">
            <h5 class="card-title fw-bold mb-0 text-primary">
                <i class="bi bi-prescription2 me-1"></i>6. Plan de Tratamiento, Indicaciones y Control
            </h5>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-12 col-md-8">
                    <label for="indicaciones_tratamiento" class="form-label fw-semibold">Indicaciones, Receta Médica y Cuidados Postoperatorios</label>
                    <textarea class="form-control" id="indicaciones_tratamiento" name="indicaciones_tratamiento" rows="3" placeholder="Ej: Amoxicilina 500mg c/8h por 7 días. Ibuprofeno 400mg c/8h si hay dolor. Dieta blanda."></textarea>
                </div>
                <div class="col-12 col-md-4">
                    <label for="proxima_cita_sugerida" class="form-label fw-semibold">Próxima Cita Sugerida / Control</label>
                    <input type="date" class="form-control" id="proxima_cita_sugerida" name="proxima_cita_sugerida">
                    <div class="form-text small">Fecha tentativa para continuar tratamiento o control.</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Botones de Acción Final -->
    <div class="card shadow-sm mb-5 border-primary">
        <div class="card-body d-flex flex-column flex-sm-row justify-content-between align-items-center gap-3">
            <div class="text-muted small">
                <i class="bi bi-info-circle me-1"></i>Al guardar, la atención se registrará permanentemente en la historia clínica del paciente y la cita pasará al estado <strong>Atendida</strong>.
            </div>
            <button type="submit" class="btn btn-primary btn-lg px-4 fw-bold" id="btnGuardarConsulta">
                <i class="bi bi-check2-circle me-1"></i>Finalizar y Guardar Atención
            </button>
        </div>
    </div>
</form>

<?php
$extraScripts = '<script src="' . ASSETS_URL . 'js/consultas.js?v=1.0.1"></script>';
require_once __DIR__ . '/../layouts/footer.php';
?>

