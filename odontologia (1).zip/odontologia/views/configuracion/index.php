<?php

$pageTitle = 'Configuración Clínica';
require_once __DIR__ . '/../layouts/header.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Settings;

if (!Auth::isAdmin()) {
    header('Location: ' . BASE_URL . 'views/dashboard/index.php');
    exit;
}

$cfg = Settings::get();
$logoUrl = Settings::getLogoUrl();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold mb-1"><i class="bi bi-gear-fill text-primary me-2"></i>Configuración de la Clínica</h3>
        <p class="text-muted mb-0">Personalice los datos de la institución, membretes y reportes oficiales</p>
    </div>
</div>

<div class="row">
    <div class="col-12 col-lg-8 mx-auto">
        <div class="card shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="card-title fw-bold mb-0">Información Institucional</h5>
            </div>
            <div class="card-body p-4">
                <form id="formConfiguracion" enctype="multipart/form-data">
                    <?= Csrf::field() ?>

                    <div class="row g-3">
                        <!-- Vista Previa y Carga de Logo -->
                        <div class="col-12 text-center pb-3 border-bottom">
                            <label class="form-label fw-bold d-block">Logotipo de la Clínica</label>
                            <div class="mb-2">
                                <img id="logoPreview" src="<?= $logoUrl ?: ASSETS_URL . 'img/placeholder_logo.png' ?>" alt="Logo Clínica" class="img-thumbnail" style="max-height: 100px; max-width: 220px; object-fit: contain; <?= !$logoUrl ? 'display:none;' : '' ?>">
                                <div id="logoPlaceholder" class="bg-light border rounded d-inline-flex align-items-center justify-content-center p-4 text-muted" style="<?= $logoUrl ? 'display:none;' : '' ?>">
                                    <i class="bi bi-image fs-1 me-2"></i>Sin logotipo cargado
                                </div>
                            </div>
                            <div class="col-md-6 mx-auto">
                                <input type="file" class="form-control form-control-sm" id="logo_file" name="logo_file" accept="image/png, image/jpeg, image/webp, image/svg+xml">
                                <div class="form-text small">Formatos permitidos: PNG, JPG, WEBP, SVG (Máx. 2MB)</div>
                            </div>
                        </div>

                        <!-- Nombre de la Clínica (Editable como requested) -->
                        <div class="col-12 col-md-8">
                            <label for="nombre_clinica" class="form-label fw-semibold">Nombre de la Clínica / Centro Odontológico <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="nombre_clinica" name="nombre_clinica" value="<?= htmlspecialchars($cfg['nombre_clinica'] ?? '') ?>" required>
                        </div>

                        <div class="col-12 col-md-4">
                            <label for="ruc_nit" class="form-label fw-semibold">RIF / NIT / Identificación</label>
                            <input type="text" class="form-control" id="ruc_nit" name="ruc_nit" value="<?= htmlspecialchars($cfg['ruc_nit'] ?? '') ?>" placeholder="Ej: J-12345678-9">
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="telefono" class="form-label fw-semibold">Teléfono de Contacto</label>
                            <input type="text" class="form-control" id="telefono" name="telefono" value="<?= htmlspecialchars($cfg['telefono'] ?? '') ?>" placeholder="+58 212 555-0199">
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="email" class="form-label fw-semibold">Correo Electrónico Institucional</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($cfg['email'] ?? '') ?>" placeholder="contacto@clinica.com">
                        </div>

                        <div class="col-12">
                            <label for="direccion" class="form-label fw-semibold">Dirección Física</label>
                            <textarea class="form-control" id="direccion" name="direccion" rows="2" placeholder="Ubicación completa del consultorio"><?= htmlspecialchars($cfg['direccion'] ?? '') ?></textarea>
                        </div>

                        <div class="col-12">
                            <label for="pie_reporte" class="form-label fw-semibold">Pie de Página en Historias Clínicas (PDF)</label>
                            <textarea class="form-control" id="pie_reporte" name="pie_reporte" rows="2"><?= htmlspecialchars($cfg['pie_reporte'] ?? '') ?></textarea>
                            <div class="form-text small">Este texto figurará al final de cada reporte médico oficial emitido.</div>
                        </div>

                        <div class="col-12 text-end pt-3 border-top">
                            <button type="submit" class="btn btn-primary px-4 fw-semibold" id="btnSaveConfig">
                                <i class="bi bi-save me-1"></i>Guardar Cambios
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
$extraScripts = <<<'SCRIPT'
<script>
$(document).ready(function() {
    // Previsualización de logo al seleccionar imagen
    $('#logo_file').on('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(evt) {
                $('#logoPreview').attr('src', evt.target.result).show();
                $('#logoPlaceholder').hide();
            };
            reader.readAsDataURL(file);
        }
    });

    // Guardar configuración vía AJAX
    $('#formConfiguracion').on('submit', function(e) {
        e.preventDefault();

        const formData = new FormData(this);
        const btn = $('#btnSaveConfig');
        btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span>Guardando...');

        $.ajax({
            url: BASE_URL + 'ajax/configuracion.php?action=update',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(res) {
                if (res.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Configuración guardada',
                        text: res.message,
                        confirmButtonColor: '#0d6efd'
                    }).then(() => {
                        window.location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: res.message,
                        confirmButtonColor: '#0d6efd'
                    });
                    btn.prop('disabled', false).html('<i class="bi bi-save me-1"></i>Guardar Cambios');
                }
            },
            error: function(xhr) {
                let msg = 'Error al actualizar configuración.';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    msg = xhr.responseJSON.message;
                }
                Swal.fire({ icon: 'error', title: 'Error', text: msg });
                btn.prop('disabled', false).html('<i class="bi bi-save me-1"></i>Guardar Cambios');
            }
        });
    });
});
</script>
SCRIPT;

require_once __DIR__ . '/../layouts/footer.php';
?>

