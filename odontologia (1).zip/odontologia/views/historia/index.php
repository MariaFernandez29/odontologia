<?php

$pageTitle = 'Historias Clínicas';
require_once __DIR__ . '/../layouts/header.php';

use App\Core\Auth;
use App\Models\Paciente;
use App\Models\Consulta;

if (!Auth::isDoctor() && !Auth::isAdmin()) {
    header('Location: ' . BASE_URL . 'views/dashboard/index.php');
    exit;
}

$pacienteId = (int)($_GET['paciente_id'] ?? 0);
$paciente = null;
$consultas = [];

if ($pacienteId) {
    $paciente = Paciente::find($pacienteId);
    if ($paciente) {
        $consultas = Consulta::getByPaciente($pacienteId);
    }
}

$todosPacientes = Paciente::all();
?>

<div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center mb-4 gap-2">
    <div>
        <h3 class="fw-bold mb-1"><i class="bi bi-file-earmark-medical-fill text-primary me-2"></i>Historia Clínica Odontológica</h3>
        <p class="text-muted mb-0">Expediente médico confidencial, evolución, diagnósticos y procedimientos</p>
    </div>
    <?php if ($paciente): ?>
        <div class="d-flex gap-2">
            <a href="<?= BASE_URL ?>views/consultas/atender.php?paciente_id=<?= $paciente['id'] ?>" class="btn btn-outline-primary">
                <i class="bi bi-plus-circle me-1"></i>Nueva Consulta
            </a>
            <a href="<?= BASE_URL ?>reports/historia_pdf.php?id=<?= $paciente['id'] ?>" target="_blank" class="btn btn-danger">
                <i class="bi bi-file-pdf me-1"></i>Generar PDF
            </a>
        </div>
    <?php endif; ?>
</div>

<!-- Selector de Paciente -->
<div class="card shadow-sm mb-4">
    <div class="card-body p-3">
        <form method="GET" action="" class="row g-2 align-items-center">
            <div class="col-12 col-md-9">
                <label for="selectPacienteHistoria" class="form-label small fw-bold mb-1">Seleccionar Expediente del Paciente:</label>
                <select class="form-select" id="selectPacienteHistoria" name="paciente_id" onchange="this.form.submit()">
                    <option value="">Seleccione o busque un paciente...</option>
                    <?php foreach ($todosPacientes as $p): ?>
                        <option value="<?= $p['id'] ?>" <?= ($pacienteId === (int)$p['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($p['codigo']) ?> - <?= htmlspecialchars($p['nombres'] . ' ' . $p['apellidos']) ?> (C.I.: <?= htmlspecialchars($p['cedula']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-3 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-search me-1"></i>Cargar Historia
                </button>
            </div>
        </form>
    </div>
</div>

<?php if (!$paciente): ?>
    <div class="card shadow-sm text-center py-5">
        <div class="card-body">
            <i class="bi bi-folder2-open text-muted" style="font-size: 3.5rem;"></i>
            <h5 class="fw-bold mt-3">Ningún paciente seleccionado</h5>
            <p class="text-muted">Por favor elija un paciente del selector superior para visualizar su historial clínico completo y generar su reporte.</p>
        </div>
    </div>
<?php else: ?>

    <!-- Ficha del Paciente -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <span class="fw-bold fs-5 text-dark">
                <i class="bi bi-person-badge text-primary me-2"></i><?= htmlspecialchars($paciente['nombres'] . ' ' . $paciente['apellidos']) ?>
            </span>
            <span class="badge bg-primary fs-6"><?= htmlspecialchars($paciente['codigo']) ?></span>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-6 col-md-3">
                    <div class="text-muted small">Cédula / Documento:</div>
                    <strong><?= htmlspecialchars($paciente['cedula']) ?></strong>
                </div>
                <div class="col-6 col-md-3">
                    <div class="text-muted small">Edad y Sexo:</div>
                    <strong><?= $paciente['edad'] ?> años</strong> (<?= $paciente['sexo'] === 'M' ? 'Masc.' : ($paciente['sexo'] === 'F' ? 'Fem.' : 'Otro') ?>)
                </div>
                <div class="col-6 col-md-3">
                    <div class="text-muted small">Grupo Sanguíneo:</div>
                    <strong><?= htmlspecialchars($paciente['grupo_sanguineo'] ?: 'No registrado') ?></strong>
                </div>
                <div class="col-6 col-md-3">
                    <div class="text-muted small">Teléfono:</div>
                    <strong><?= htmlspecialchars($paciente['telefono'] ?: 'No registrado') ?></strong>
                </div>

                <div class="col-6 col-md-3">
                    <div class="text-muted small">Correo Electrónico:</div>
                    <span><?= htmlspecialchars($paciente['email'] ?: 'No registrado') ?></span>
                </div>
                <div class="col-6 col-md-3">
                    <div class="text-muted small">Ocupación:</div>
                    <span><?= htmlspecialchars($paciente['ocupacion'] ?: 'No registrada') ?></span>
                </div>
                <div class="col-12 col-md-6">
                    <div class="text-muted small">Contacto de Emergencia:</div>
                    <span><?= htmlspecialchars($paciente['contacto_emergencia'] ?: 'No registrado') ?> <?= $paciente['telefono_emergencia'] ? '(' . htmlspecialchars($paciente['telefono_emergencia']) . ')' : '' ?></span>
                </div>
                <div class="col-12">
                    <div class="text-muted small">Dirección de Habitación:</div>
                    <span><?= htmlspecialchars($paciente['direccion'] ?: 'No registrada') ?></span>
                </div>
            </div>

            <!-- Alerta Médica de Alergias -->
            <?php if (!empty($paciente['alergias'])): ?>
                <div class="alert alert-warning mt-3 mb-0 d-flex align-items-center">
                    <i class="bi bi-exclamation-triangle-fill fs-4 me-2"></i>
                    <div>
                        <strong>ALERTA MÉDICA:</strong> Paciente presenta alergias a: <strong><?= htmlspecialchars($paciente['alergias']) ?></strong>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Pestañas de Historia Clínica: Antecedentes y Consultas -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-white p-2">
            <ul class="nav nav-tabs card-header-tabs" id="historiaTabs" role="tablist">
                <li class="nav-item">
                    <button class="nav-link active fw-semibold" id="tab-consultas" data-bs-toggle="tab" data-bs-target="#pane-consultas" type="button" role="tab">
                        <i class="bi bi-clock-history me-1"></i>Evolución de Consultas (<?= count($consultas) ?>)
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link fw-semibold" id="tab-antecedentes" data-bs-toggle="tab" data-bs-target="#pane-antecedentes" type="button" role="tab">
                        <i class="bi bi-heart-pulse me-1"></i>Antecedentes Médicos
                    </button>
                </li>
            </ul>
        </div>
        <div class="card-body p-4">
            <div class="tab-content" id="historiaTabContent">

                <!-- Pestaña: Consultas Realizadas -->
                <div class="tab-pane fade show active" id="pane-consultas" role="tabpanel">
                    <?php if (empty($consultas)): ?>
                        <div class="text-center py-4 text-muted">
                            <i class="bi bi-journal-x fs-2 d-block mb-2"></i>
                            El paciente aún no posee consultas registradas.
                            <div class="mt-2">
                                <a href="<?= BASE_URL ?>views/consultas/atender.php?paciente_id=<?= $paciente['id'] ?>" class="btn btn-sm btn-primary">
                                    <i class="bi bi-plus-circle me-1"></i>Registrar Primera Atención
                                </a>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="timeline">
                            <?php foreach ($consultas as $idx => $con): ?>
                                <div class="timeline-item">
                                    <div class="timeline-point"></div>
                                    <div class="card shadow-sm border mb-3">
                                        <div class="card-header bg-light d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center gap-1">
                                            <div>
                                                <strong class="text-primary fs-6">
                                                    Consulta #<?= count($consultas) - $idx ?> &bull; <?= date('d/m/Y H:i', strtotime($con['fecha_registro'])) ?>
                                                </strong>
                                            </div>
                                            <div class="text-muted small">
                                                Atendido por: <strong>Dr(a). <?= htmlspecialchars($con['doctor_nombre']) ?></strong>
                                                <?php if (!empty($con['doctor_especialidad'])): ?> (<?= htmlspecialchars($con['doctor_especialidad']) ?>)<?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="card-body">
                                            <div class="mb-3">
                                                <strong>Motivo de Consulta:</strong>
                                                <p class="mb-1 text-dark"><?= htmlspecialchars($con['motivo_consulta']) ?></p>
                                                <?php if (!empty($con['enfermedad_actual'])): ?>
                                                    <strong>Evolución / Enfermedad Actual:</strong>
                                                    <p class="mb-1 text-muted small"><?= htmlspecialchars($con['enfermedad_actual']) ?></p>
                                                <?php endif; ?>
                                                <?php if (!empty($con['examen_estomatologico'])): ?>
                                                    <strong>Examen Estomatológico:</strong>
                                                    <p class="mb-1 text-muted small"><?= htmlspecialchars($con['examen_estomatologico']) ?></p>
                                                <?php endif; ?>
                                            </div>

                                            <!-- Signos Vitales -->
                                            <?php if (!empty($con['presion_sistolica']) || !empty($con['frecuencia_cardiaca']) || !empty($con['temperatura'])): ?>
                                                <div class="p-2 bg-light rounded mb-3">
                                                    <span class="fw-bold small text-primary d-block mb-1">
                                                        <i class="bi bi-heart-pulse me-1"></i>Signos Vitales Registrados:
                                                    </span>
                                                    <div class="d-flex flex-wrap gap-3 small">
                                                        <?php if ($con['presion_sistolica'] && $con['presion_diastolica']): ?>
                                                            <div><strong>P.A.:</strong> <?= $con['presion_sistolica'] ?>/<?= $con['presion_diastolica'] ?> mmHg</div>
                                                        <?php endif; ?>
                                                        <?php if ($con['frecuencia_cardiaca']): ?>
                                                            <div><strong>F.C.:</strong> <?= $con['frecuencia_cardiaca'] ?> bpm</div>
                                                        <?php endif; ?>
                                                        <?php if ($con['temperatura']): ?>
                                                            <div><strong>Temp:</strong> <?= $con['temperatura'] ?> °C</div>
                                                        <?php endif; ?>
                                                        <?php if ($con['saturacion_oxigeno']): ?>
                                                            <div><strong>Sat. O2:</strong> <?= $con['saturacion_oxigeno'] ?> %</div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>

                                            <!-- Diagnósticos -->
                                            <?php if (!empty($con['diagnosticos'])): ?>
                                                <h6 class="fw-bold text-dark mt-2 mb-1 small text-uppercase">Diagnósticos</h6>
                                                <div class="table-responsive mb-3">
                                                    <table class="table table-sm table-bordered mb-0 small">
                                                        <thead class="table-light">
                                                            <tr>
                                                                <th style="width: 20%;">Pieza / Zona</th>
                                                                <th style="width: 20%;">Tipo</th>
                                                                <th style="width: 60%;">Descripción</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php foreach ($con['diagnosticos'] as $d): ?>
                                                                <tr>
                                                                    <td><strong><?= htmlspecialchars($d['pieza_dental'] ?: 'General') ?></strong></td>
                                                                    <td><span class="badge bg-primary-subtle text-primary"><?= ucfirst(htmlspecialchars($d['tipo'])) ?></span></td>
                                                                    <td><?= htmlspecialchars($d['descripcion']) ?></td>
                                                                </tr>
                                                            <?php endforeach; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            <?php endif; ?>

                                            <!-- Procedimientos Realizados -->
                                            <?php if (!empty($con['procedimientos'])): ?>
                                                <h6 class="fw-bold text-dark mt-2 mb-1 small text-uppercase">Procedimientos Odontológicos Realizados</h6>
                                                <div class="table-responsive mb-3">
                                                    <table class="table table-sm table-bordered mb-0 small">
                                                        <thead class="table-light">
                                                            <tr>
                                                                <th style="width: 45%;">Procedimiento</th>
                                                                <th style="width: 20%;">Categoría</th>
                                                                <th style="width: 15%;">Pieza</th>
                                                                <th style="width: 20%;">Observaciones</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php foreach ($con['procedimientos'] as $pr): ?>
                                                                <tr>
                                                                    <td><strong><?= htmlspecialchars($pr['procedimiento_nombre']) ?></strong></td>
                                                                    <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($pr['categoria'] ?: 'General') ?></span></td>
                                                                    <td><?= htmlspecialchars($pr['pieza_dental'] ?: 'N/A') ?></td>
                                                                    <td><?= htmlspecialchars($pr['observaciones'] ?: 'Sin observaciones') ?></td>
                                                                </tr>
                                                            <?php endforeach; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            <?php endif; ?>

                                            <!-- Indicaciones y Próxima Cita -->
                                            <?php if (!empty($con['indicaciones_tratamiento'])): ?>
                                                <div class="p-2 border-start border-3 border-success bg-light rounded mt-2">
                                                    <strong class="text-success small">Indicaciones / Cuidados:</strong>
                                                    <div class="small mt-1"><?= nl2br(htmlspecialchars($con['indicaciones_tratamiento'])) ?></div>
                                                </div>
                                            <?php endif; ?>

                                            <?php if (!empty($con['proxima_cita_sugerida'])): ?>
                                                <div class="text-muted small mt-2">
                                                    <i class="bi bi-calendar-event me-1"></i>Próxima cita sugerida: <strong><?= date('d/m/Y', strtotime($con['proxima_cita_sugerida'])) ?></strong>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Pestaña: Antecedentes Médicos -->
                <div class="tab-pane fade" id="pane-antecedentes" role="tabpanel">
                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <label class="form-label fw-bold text-muted small">Alergias Conocidas</label>
                            <p class="p-2 bg-light rounded border"><?= htmlspecialchars($paciente['alergias'] ?: 'Sin alergias registradas') ?></p>
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label fw-bold text-muted small">Enfermedades Sistémicas / Crónicas</label>
                            <p class="p-2 bg-light rounded border"><?= htmlspecialchars($paciente['enfermedades_sistemicas'] ?: 'Ninguna') ?></p>
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label fw-bold text-muted small">Medicamentos Actuales</label>
                            <p class="p-2 bg-light rounded border"><?= htmlspecialchars($paciente['medicamentos_actuales'] ?: 'Ninguno') ?></p>
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label fw-bold text-muted small">Cirugías Previas</label>
                            <p class="p-2 bg-light rounded border"><?= htmlspecialchars($paciente['cirugias_previas'] ?: 'Ninguna') ?></p>
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label fw-bold text-muted small">Hábitos (Bruxismo / Tabaco)</label>
                            <p class="p-2 bg-light rounded border"><?= htmlspecialchars($paciente['habitos'] ?: 'Ninguno') ?></p>
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label fw-bold text-muted small">Antecedentes Familiares</label>
                            <p class="p-2 bg-light rounded border"><?= htmlspecialchars($paciente['antecedentes_familiares'] ?: 'Sin relevancia') ?></p>
                        </div>
                        <?php if ($paciente['sexo'] === 'F'): ?>
                        <div class="col-12 col-md-6">
                            <label class="form-label fw-bold text-muted small">Estado de Embarazo</label>
                            <p class="p-2 bg-light rounded border">
                                <?= $paciente['embarazo'] ? 'En gestación (' . $paciente['meses_embarazo'] . ' meses)' : 'No' ?>
                            </p>
                        </div>
                        <?php endif; ?>
                        <div class="col-12">
                            <label class="form-label fw-bold text-muted small">Observaciones Generales</label>
                            <p class="p-2 bg-light rounded border"><?= htmlspecialchars($paciente['antecedentes_observaciones'] ?: 'Sin observaciones') ?></p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

<?php endif; ?>

<?php
require_once __DIR__ . '/../layouts/footer.php';
?>

