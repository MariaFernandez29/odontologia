<?php

$pageTitle = 'Gestión de Pacientes';
require_once __DIR__ . '/../layouts/header.php';

use App\Core\Auth;
use App\Core\Csrf;

$canRegister = true;
?>

<div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center mb-4 gap-2">
    <div>
        <h3 class="fw-bold mb-1"><i class="bi bi-people-fill text-primary me-2"></i>Pacientes de la Clínica</h3>
        <p class="text-muted mb-0">Directorio de pacientes, fichas clínicas y antecedentes médicos</p>
    </div>
    <?php if ($canRegister): ?>
    <button class="btn btn-primary" id="btnNuevoPaciente">
        <i class="bi bi-person-plus-fill me-1"></i>Registrar Paciente
    </button>
    <?php endif; ?>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle w-100" id="tablaPacientes">
                <thead class="table-light">
                    <tr>
                        <th>Nº Historia</th>
                        <th>Paciente y C.I.</th>
                        <th>Edad / Sexo</th>
                        <th>Contacto</th>
                        <th class="text-center">Consultas</th>
                        <th>Estado</th>
                        <th class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal para Registrar / Editar Paciente -->
<div class="modal fade" id="modalPaciente" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-light">
                <h5 class="modal-title fw-bold" id="modalPacienteTitle">Registrar Nuevo Paciente</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="formPaciente" novalidate>
                <div class="modal-body p-4">
                    <?= Csrf::field() ?>
                    <input type="hidden" id="paciente_id" name="id">

                    <!-- Pestañas Datos / Antecedentes -->
                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active fw-semibold" id="pills-datos-tab" data-bs-toggle="pill" data-bs-target="#pills-datos" type="button" role="tab">
                                <i class="bi bi-person-vcard me-1"></i>1. Datos Personales
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link fw-semibold" id="pills-antecedentes-tab" data-bs-toggle="pill" data-bs-target="#pills-antecedentes" type="button" role="tab">
                                <i class="bi bi-heart-pulse me-1"></i>2. Antecedentes Médicos
                            </button>
                        </li>
                    </ul>

                    <div class="tab-content" id="pills-tabContent">
                        <!-- Pestaña 1: Datos Personales -->
                        <div class="tab-pane fade show active" id="pills-datos" role="tabpanel">
                            <div class="row g-3">
                                <div class="col-12 col-md-4">
                                    <label for="cedula" class="form-label fw-semibold">Cédula / Documento <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="cedula" name="cedula" placeholder="Ej: V-18765432" required>
                                </div>
                                <div class="col-12 col-md-4">
                                    <label for="nombres" class="form-label fw-semibold">Nombres <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="nombres" name="nombres" required>
                                </div>
                                <div class="col-12 col-md-4">
                                    <label for="apellidos" class="form-label fw-semibold">Apellidos <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="apellidos" name="apellidos" required>
                                </div>

                                <div class="col-12 col-md-4">
                                    <label for="fecha_nacimiento" class="form-label fw-semibold">Fecha de Nacimiento <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento" required>
                                </div>
                                <div class="col-12 col-md-4">
                                    <label for="sexo" class="form-label fw-semibold">Sexo <span class="text-danger">*</span></label>
                                    <select class="form-select" id="sexo" name="sexo" required>
                                        <option value="M">Masculino</option>
                                        <option value="F">Femenino</option>
                                        <option value="Otro">Otro</option>
                                    </select>
                                </div>
                                <div class="col-12 col-md-4">
                                    <label for="grupo_sanguineo" class="form-label fw-semibold">Grupo Sanguíneo</label>
                                    <select class="form-select" id="grupo_sanguineo" name="grupo_sanguineo">
                                        <option value="">Desconocido</option>
                                        <option value="O+">O Positivo (O+)</option>
                                        <option value="O-">O Negativo (O-)</option>
                                        <option value="A+">A Positivo (A+)</option>
                                        <option value="A-">A Negativo (A-)</option>
                                        <option value="B+">B Positivo (B+)</option>
                                        <option value="B-">B Negativo (B-)</option>
                                        <option value="AB+">AB Positivo (AB+)</option>
                                        <option value="AB-">AB Negativo (AB-)</option>
                                    </select>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="telefono" class="form-label fw-semibold">Teléfono de Contacto</label>
                                    <input type="text" class="form-control" id="telefono" name="telefono" placeholder="0414-1234567">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label for="email" class="form-label fw-semibold">Correo Electrónico</label>
                                    <input type="email" class="form-control" id="email" name="email" placeholder="paciente@correo.com">
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="ocupacion" class="form-label fw-semibold">Ocupación / Profesión</label>
                                    <input type="text" class="form-control" id="ocupacion" name="ocupacion">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label for="estado" class="form-label fw-semibold">Estado del Paciente</label>
                                    <select class="form-select" id="estado" name="estado">
                                        <option value="activo">Activo</option>
                                        <option value="inactivo">Inactivo</option>
                                    </select>
                                </div>

                                <div class="col-12">
                                    <label for="direccion" class="form-label fw-semibold">Dirección de Habitación</label>
                                    <textarea class="form-control" id="direccion" name="direccion" rows="2" placeholder="Dirección completa"></textarea>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="contacto_emergencia" class="form-label fw-semibold">Contacto de Emergencia (Nombre y Parentesco)</label>
                                    <input type="text" class="form-control" id="contacto_emergencia" name="contacto_emergencia" placeholder="Ej: Carmen Pérez (Madre)">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label for="telefono_emergencia" class="form-label fw-semibold">Teléfono de Emergencia</label>
                                    <input type="text" class="form-control" id="telefono_emergencia" name="telefono_emergencia">
                                </div>
                            </div>
                        </div>

                        <!-- Pestaña 2: Antecedentes Médicos -->
                        <div class="tab-pane fade" id="pills-antecedentes" role="tabpanel">
                            <div class="row g-3">
                                <div class="col-12">
                                    <label for="alergias" class="form-label fw-semibold text-danger">
                                        <i class="bi bi-exclamation-triangle-fill me-1"></i>Alergias Conocidas (Medicamentos, anestesia, látex)
                                    </label>
                                    <input type="text" class="form-control border-warning" id="alergias" name="alergias" placeholder="Ej: Alergia a la Penicilina, sulfas o anestésicos locales">
                                    <div class="form-text small">Indique con detalle cualquier reacción adversa previa.</div>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="enfermedades_sistemicas" class="form-label fw-semibold">Enfermedades Sistémicas / Crónicas</label>
                                    <textarea class="form-control" id="enfermedades_sistemicas" name="enfermedades_sistemicas" rows="2" placeholder="Diabetes, Hipertensión, Cardiopatías, Asma, etc."></textarea>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="medicamentos_actuales" class="form-label fw-semibold">Medicamentos de Consumo Actual</label>
                                    <textarea class="form-control" id="medicamentos_actuales" name="medicamentos_actuales" rows="2" placeholder="Anticoagulantes, antihipertensivos, insulina, etc."></textarea>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="cirugias_previas" class="form-label fw-semibold">Cirugías u Hospitalizaciones Previas</label>
                                    <textarea class="form-control" id="cirugias_previas" name="cirugias_previas" rows="2"></textarea>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="habitos" class="form-label fw-semibold">Hábitos Odontológicos y de Riesgo</label>
                                    <textarea class="form-control" id="habitos" name="habitos" rows="2" placeholder="Bruxismo, tabaco, alcohol, onicofagia"></textarea>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="antecedentes_familiares" class="form-label fw-semibold">Antecedentes Familiares</label>
                                    <textarea class="form-control" id="antecedentes_familiares" name="antecedentes_familiares" rows="2"></textarea>
                                </div>

                                <div class="col-12 col-md-6" id="seccionEmbarazo" style="display: none;">
                                    <label class="form-label fw-semibold">¿Se encuentra en estado de gestación?</label>
                                    <div class="form-check form-switch mb-2">
                                        <input class="form-check-input" type="checkbox" id="embarazo" name="embarazo" value="1">
                                        <label class="form-check-label" for="embarazo">Actualmente en periodo de embarazo</label>
                                    </div>
                                    <div id="campoMesesEmbarazo" style="display: none;">
                                        <label for="meses_embarazo" class="form-label small fw-semibold">Meses de gestación</label>
                                        <input type="number" class="form-control form-control-sm" id="meses_embarazo" name="meses_embarazo" min="1" max="9" value="0">
                                    </div>
                                </div>

                                <div class="col-12">
                                    <label for="antecedentes_observaciones" class="form-label fw-semibold">Observaciones Generales</label>
                                    <textarea class="form-control" id="antecedentes_observaciones" name="antecedentes_observaciones" rows="2"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary" id="btnSavePaciente">
                        <i class="bi bi-save me-1"></i>Guardar Paciente
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Ver Ficha Rápida del Paciente -->
<div class="modal fade" id="modalFichaPaciente" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fw-bold">
                    <i class="bi bi-person-vcard me-2"></i>Ficha del Paciente: <span id="fichaCodigo"></span>
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <div class="row g-3">
                    <div class="col-12 col-md-6">
                        <div class="p-3 bg-light rounded">
                            <h6 class="fw-bold text-primary mb-3">Datos de Filiación</h6>
                            <p class="mb-1"><strong>Nombre:</strong> <span id="fichaNombre"></span></p>
                            <p class="mb-1"><strong>Cédula:</strong> <span id="fichaCedula"></span></p>
                            <p class="mb-1"><strong>Edad:</strong> <span id="fichaEdad"></span></p>
                            <p class="mb-1"><strong>Sexo:</strong> <span id="fichaSexo"></span></p>
                            <p class="mb-1"><strong>Grupo Sanguíneo:</strong> <span id="fichaSangre"></span></p>
                            <p class="mb-1"><strong>Teléfono:</strong> <span id="fichaTelefono"></span></p>
                            <p class="mb-1"><strong>Correo:</strong> <span id="fichaEmail"></span></p>
                            <p class="mb-0"><strong>Dirección:</strong> <span id="fichaDireccion"></span></p>
                        </div>
                    </div>

                    <div class="col-12 col-md-6">
                        <div class="p-3 bg-light rounded">
                            <h6 class="fw-bold text-primary mb-3">Antecedentes Clínicos</h6>
                            <div class="mb-2"><strong>Alergias:</strong> <div id="fichaAlergias"></div></div>
                            <p class="mb-1"><strong>Enfermedades:</strong> <span id="fichaEnfermedades"></span></p>
                            <p class="mb-1"><strong>Medicamentos:</strong> <span id="fichaMedicamentos"></span></p>
                            <p class="mb-1"><strong>Hábitos:</strong> <span id="fichaHabitos"></span></p>
                            <p class="mb-0"><strong>Contacto Emergencia:</strong> <span id="fichaEmergencia"></span></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light d-flex justify-content-between">
                <div>
                    <a href="#" id="btnFichaHistoria" class="btn btn-outline-primary">
                        <i class="bi bi-file-earmark-medical me-1"></i>Ver Historia Clínica Completa
                    </a>
                    <a href="#" id="btnFichaPdf" target="_blank" class="btn btn-outline-danger ms-1">
                        <i class="bi bi-file-pdf me-1"></i>Exportar PDF
                    </a>
                </div>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<?php
$extraScripts = '<script src="' . ASSETS_URL . 'js/pacientes.js?v=1.0.1"></script>';
require_once __DIR__ . '/../layouts/footer.php';
?>

