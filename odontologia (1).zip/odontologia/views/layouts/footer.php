            </main>
            <!-- Pie de Página -->
            <footer class="py-3 px-4 bg-white border-top text-center text-muted small">
                &copy; <?= date('Y') ?> <?= htmlspecialchars($clinicName) ?>. Todos los derechos reservados.
            </footer>
        </div>
    </div>

    <!-- Scripts Esenciales -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/responsive.bootstrap5.min.js"></script>
    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.all.min.js"></script>
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.2/dist/chart.umd.min.js"></script>
    <!-- Select2 (opcional) -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        const CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

        // Configuración global de AJAX para adjuntar CSRF Token y cabeceras
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': CSRF_TOKEN
            }
        });

        // Configuración de idioma para DataTables en Español
        const dtSpanish = {
            processing: "Procesando...",
            search: "Buscar:",
            lengthMenu: "Mostrar _MENU_ registros",
            info: "Mostrando de _START_ a _END_ de _TOTAL_ registros",
            infoEmpty: "Mostrando 0 a 0 de 0 registros",
            infoFiltered: "(filtrado de _MAX_ registros en total)",
            infoPostFix: "",
            loadingRecords: "Cargando registros...",
            zeroRecords: "No se encontraron resultados",
            emptyTable: "No hay datos disponibles en la tabla",
            paginate: {
                first: "Primero",
                previous: "Anterior",
                next: "Siguiente",
                last: "Último"
            },
            aria: {
                sortAscending: ": activar para ordenar la columna de manera ascendente",
                sortDescending: ": activar para ordenar la columna de manera descendente"
            }
        };

        // Manejo de Sidebar responsivo
        $('#sidebarToggle').on('click', function() {
            $('#appSidebar').toggleClass('show');
            $('#sidebarBackdrop').toggleClass('show');
        });

        $('#sidebarBackdrop').on('click', function() {
            $('#appSidebar').removeClass('show');
            $('#sidebarBackdrop').removeClass('show');
        });

        // Manejo de Cierre de Sesión
        $('#btnLogoutLink, #btnLogoutDropdown').on('click', function(e) {
            e.preventDefault();
            Swal.fire({
                title: '¿Cerrar sesión?',
                text: '¿Desea salir del sistema?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#0d6efd',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Sí, salir',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.post(BASE_URL + 'ajax/auth.php?action=logout', { csrf_token: CSRF_TOKEN }, function(res) {
                        window.location.href = BASE_URL + 'login.php';
                    }, 'json').fail(function() {
                        window.location.href = BASE_URL + 'login.php';
                    });
                }
            });
        });
    </script>

    <?php if (isset($extraScripts)): ?>
        <?= $extraScripts ?>
    <?php endif; ?>
</body>
</html>

