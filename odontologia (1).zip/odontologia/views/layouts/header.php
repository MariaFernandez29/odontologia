<?php

require_once __DIR__ . '/../../config/config.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Settings;

Auth::requireLogin();

$clinicSettings = Settings::get();
$clinicName = $clinicSettings['nombre_clinica'] ?? 'Clínica Odontológica';
$clinicLogo = Settings::getLogoUrl();

$currentUser = Auth::user();
$currentRole = Auth::role();
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$currentDir = basename(dirname($_SERVER['PHP_SELF']));

if (!isset($pageTitle)) {
    $pageTitle = 'Panel';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= Csrf::token() ?>">
    <title><?= htmlspecialchars($pageTitle) ?> | <?= htmlspecialchars($clinicName) ?></title>

    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- DataTables Bootstrap 5 CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.bootstrap5.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.min.css">
    <!-- Select2 CSS (opcional) -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />

    <!-- Estilos del Sistema -->
    <link rel="stylesheet" href="<?= ASSETS_URL ?>css/app.css?v=1.0.1">
</head>
<body>
    <div class="sidebar-backdrop" id="sidebarBackdrop"></div>
    <div class="app-wrapper">

        <!-- Barra Lateral (Sidebar) -->
        <aside class="app-sidebar" id="appSidebar">
            <a href="<?= BASE_URL ?>views/dashboard/index.php" class="sidebar-brand">
                <?php if ($clinicLogo): ?>
                    <img src="<?= $clinicLogo ?>" alt="Logo">
                <?php else: ?>
                    <div class="bg-primary text-white rounded d-flex align-items-center justify-content-center" style="width: 38px; height: 38px;">
                        <i class="bi bi-hospital fs-4"></i>
                    </div>
                <?php endif; ?>
                <div class="brand-text">
                    <?= htmlspecialchars($clinicName) ?>
                </div>
            </a>

            <ul class="sidebar-menu">
                <li class="sidebar-header">General</li>
                <li class="sidebar-item">
                    <a href="<?= BASE_URL ?>views/dashboard/index.php" class="sidebar-link <?= ($currentDir === 'dashboard') ? 'active' : '' ?>">
                        <i class="bi bi-grid-1x2-fill"></i>
                        <span>Panel Principal</span>
                    </a>
                </li>

                <li class="sidebar-header">Gestión Clínica</li>
                
                <!-- Pacientes (Todos pueden ver; Asistente y Admin registran) -->
                <li class="sidebar-item">
                    <a href="<?= BASE_URL ?>views/pacientes/index.php" class="sidebar-link <?= ($currentDir === 'pacientes') ? 'active' : '' ?>">
                        <i class="bi bi-people-fill"></i>
                        <span>Pacientes</span>
                    </a>
                </li>

                <!-- Citas (Todos tienen vista adaptada) -->
                <li class="sidebar-item">
                    <a href="<?= BASE_URL ?>views/citas/index.php" class="sidebar-link <?= ($currentDir === 'citas') ? 'active' : '' ?>">
                        <i class="bi bi-calendar2-week-fill"></i>
                        <span>Agenda de Citas</span>
                    </a>
                </li>

                <!-- Atender Consulta (Doctores y Administrador) -->
                <?php if (Auth::isDoctor() || Auth::isAdmin()): ?>
                <li class="sidebar-item">
                    <a href="<?= BASE_URL ?>views/consultas/atender.php" class="sidebar-link <?= ($currentDir === 'consultas' && $currentPage === 'atender') ? 'active' : '' ?>">
                        <i class="bi bi-clipboard2-pulse-fill"></i>
                        <span>Atender Consulta</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="<?= BASE_URL ?>views/historia/index.php" class="sidebar-link <?= ($currentDir === 'historia') ? 'active' : '' ?>">
                        <i class="bi bi-file-earmark-medical-fill"></i>
                        <span>Historias Clínicas</span>
                    </a>
                </li>
                <?php endif; ?>

                <!-- Procedimientos (Catálogo) -->
                <li class="sidebar-item">
                    <a href="<?= BASE_URL ?>views/procedimientos/index.php" class="sidebar-link <?= ($currentDir === 'procedimientos') ? 'active' : '' ?>">
                        <i class="bi bi-journal-medical"></i>
                        <span>Procedimientos</span>
                    </a>
                </li>

                <!-- Administración -->
                <?php if (Auth::isAdmin()): ?>
                <li class="sidebar-header">Administración</li>
                <li class="sidebar-item">
                    <a href="<?= BASE_URL ?>views/usuarios/index.php" class="sidebar-link <?= ($currentDir === 'usuarios') ? 'active' : '' ?>">
                        <i class="bi bi-person-badge-fill"></i>
                        <span>Usuarios y Roles</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="<?= BASE_URL ?>views/configuracion/index.php" class="sidebar-link <?= ($currentDir === 'configuracion') ? 'active' : '' ?>">
                        <i class="bi bi-gear-fill"></i>
                        <span>Configuración Clínica</span>
                    </a>
                </li>
                <?php endif; ?>

                <li class="sidebar-header">Cuenta</li>
                <li class="sidebar-item">
                    <a href="<?= BASE_URL ?>views/perfil/index.php" class="sidebar-link <?= ($currentDir === 'perfil') ? 'active' : '' ?>">
                        <i class="bi bi-person-circle"></i>
                        <span>Mi Perfil</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link text-danger" id="btnLogoutLink">
                        <i class="bi bi-box-arrow-right"></i>
                        <span>Cerrar Sesión</span>
                    </a>
                </li>
            </ul>
        </aside>

        <!-- Contenedor Principal -->
        <div class="app-main">
            <!-- Barra Superior (Topbar) -->
            <header class="app-topbar">
                <div class="d-flex align-items-center gap-2">
                    <button class="sidebar-toggle-btn" id="sidebarToggle" type="button" aria-label="Menu">
                        <i class="bi bi-list"></i>
                    </button>
                    <span class="d-none d-md-inline text-muted fs-6">
                        <i class="bi bi-calendar3 me-1"></i><?= date('d/m/Y') ?>
                    </span>
                </div>

                <div class="d-flex align-items-center gap-3">
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle text-dark" data-bs-toggle="dropdown" aria-expanded="false">
                            <div class="bg-primary-subtle text-primary fw-bold rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 36px; height: 36px;">
                                <?= strtoupper(substr(Auth::name(), 0, 1)) ?>
                            </div>
                            <div class="d-none d-sm-block text-start">
                                <div class="fw-semibold text-truncate" style="max-width: 160px;"><?= htmlspecialchars(Auth::name()) ?></div>
                                <div class="badge bg-secondary-subtle text-secondary small py-0 px-2"><?= htmlspecialchars($currentRole) ?></div>
                            </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2">
                            <li><h6 class="dropdown-header">Conectado como <?= htmlspecialchars($currentRole) ?></h6></li>
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>views/perfil/index.php"><i class="bi bi-person me-2"></i>Mi Perfil</a></li>
                            <?php if (Auth::isAdmin()): ?>
                                <li><a class="dropdown-item" href="<?= BASE_URL ?>views/configuracion/index.php"><i class="bi bi-gear me-2"></i>Configuración</a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="#" id="btnLogoutDropdown"><i class="bi bi-box-arrow-right me-2"></i>Cerrar Sesión</a></li>
                        </ul>
                    </div>
                </div>
            </header>

            <!-- Cuerpo de Contenido -->
            <main class="content-body">

