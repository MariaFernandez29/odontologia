<?php

$pageTitle = 'Agenda de Citas';
require_once __DIR__ . '/../layouts/header.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Models\Usuario;
use App\Models\Paciente;

$doctors = Usuario::getDoctors();
$canSchedule = true;
?>

<div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center mb-4 gap-2">
    <div>
        <h3 class="fw-bold mb-1"><i class="bi bi-calendar2-week-fill text-primary me-2"></i>Agenda de Citas Odontológicas</h3>
        <p class="text-muted mb-0">Programación, control de turnos y atención médica de pacientes</p>
    </div>
    <?php if ($canSchedule): ?>
    <button class="btn btn-primary" id="btnNuevaCita">
        <i class="bi bi-calendar-plus-fill me-1"></i>Agendar Cita
    </button>
    <?php endif; ?>
</div>

<!-- Filtros de búsqueda rápida -->
<div class="card shadow-sm mb-4">
    <div class="card-body p-3">
        <div class="row g-2 align-items-center">
            <div class="col-12 col-md-3">
                <label class="form-label small fw-bold mb-1">Filtrar por Doctor:</label>
                <select class="form-select form-select-sm" id="filtroDoctor">
                    <option value="">Todos los doctores</option>
                    <?php foreach ($doctors as $doc): ?>
                        <option value="<?= $doc['id'] ?>">Dr(a). <?= htmlspecialchars($doc['nombres'] . ' ' . $doc['apellidos']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label small fw-bold mb-1">Filtrar por Fecha:</label>
                <input type="date" class="form-control form-control-sm" id="filtroFecha">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label small fw-bold mb-1">Estado de Cita:</label>
                <select class="form-select form-select-sm" id="filtroEstado">
                    <option value="">Todos los estados</option>
                    <option value="pendiente">Pendiente</option>
                    <option value="en_atencion">En Atención</option>
                    <option value="atendida">Atendida</option>
                    <option value="cancelada">Cancelada</option>
                    <option value="no_asistio">No Asistió</option>
                </select>
            </div>
            <div class="col-12 col-md-3 d-flex align-items-end">
                <button class="btn btn-sm btn-outline-secondary w-100" id="btnResetFiltros">
                    <i class="bi bi-arrow-counterclockwise me-1"></i>Limpiar Filtros
                </button>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle w-100" id="tablaCitas">
                <thead class="table-light">
                    <tr>
                        <th style="width: 14%;">Fecha y Hora</th>
                        <th style="width: 26%;">Paciente</th>
                        <th style="width: 22%;">Odontólogo Asignado</th>
                        <th style="width: 20%;">Motivo de Cita</th>
                        <th style="width: 8%;">Estado</th>
                        <th style="width: 10%;" class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal para Programar / Editar Cita -->
<div class="modal fade" id="modalCita" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-light">
                <h5 class="modal-title fw-bold" id="modalCitaTitle">Programar Nueva Cita</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="formCita" novalidate>
                <div class="modal-body p-4">
                    <?= Csrf::field() ?>
                    <input type="hidden" id="cita_id" name="id">

                    <div class="row g-3">
                        <div class="col-12">
                            <label for="selectPaciente" class="form-label fw-semibold">Paciente <span class="text-danger">*</span></label>
                            <select class="form-select" id="selectPaciente" name="paciente_id" required>
                                <option value="">Buscar paciente...</option>
                            </select>
                            <div class="form-text small">Escriba el nombre, cédula o código para autocompletar.</div>
                        </div>

                        <div class="col-12">
                            <label for="cita_doctor_id" class="form-label fw-semibold">Doctor Odontólogo <span class="text-danger">*</span></label>
                            <select class="form-select" id="cita_doctor_id" name="doctor_id" required>
                                <option value="">Seleccione doctor tratante...</option>
                                <?php foreach ($doctors as $d): ?>
                                    <option value="<?= $d['id'] ?>">Dr(a). <?= htmlspecialchars($d['nombres'] . ' ' . $d['apellidos']) ?> (<?= htmlspecialchars($d['especialidad'] ?: 'Odontología') ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="cita_fecha" class="form-label fw-semibold">Fecha <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="cita_fecha" name="fecha" required>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="cita_hora" class="form-label fw-semibold">Hora <span class="text-danger">*</span></label>
                            <input type="time" class="form-control" id="cita_hora" name="hora" required>
                        </div>

                        <div class="col-12">
                            <label for="cita_motivo" class="form-label fw-semibold">Motivo de la Cita <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="cita_motivo" name="motivo" placeholder="Ej: Dolor en molar, revisión periódica, limpieza" required>
                        </div>

                        <div class="col-12">
                            <label for="cita_observaciones" class="form-label fw-semibold">Observaciones / Indicaciones Previas</label>
                            <textarea class="form-control" id="cita_observaciones" name="observaciones" rows="2" placeholder="Notas adicionales para recepción o médico"></textarea>
                        </div>

                        <div class="col-12" id="seccionEstadoCita" style="display: none;">
                            <label for="cita_estado" class="form-label fw-semibold">Estado</label>
                            <select class="form-select" id="cita_estado" name="estado">
                                <option value="pendiente">Pendiente</option>
                                <option value="en_atencion">En Atención</option>
                                <option value="atendida">Atendida</option>
                                <option value="cancelada">Cancelada</option>
                                <option value="no_asistio">No Asistió</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary" id="btnSaveCita">
                        <i class="bi bi-calendar-check me-1"></i>Guardar Cita
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extraScripts = '<script src="' . ASSETS_URL . 'js/citas.js?v=1.0.1"></script>';
require_once __DIR__ . '/../layouts/footer.php';
?>

