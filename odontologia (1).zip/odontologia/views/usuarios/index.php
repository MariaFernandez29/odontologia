<?php

$pageTitle = 'Usuarios y Roles';
require_once __DIR__ . '/../layouts/header.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Models\Usuario;

if (!Auth::isAdmin()) {
    header('Location: ' . BASE_URL . 'views/dashboard/index.php');
    exit;
}

$roles = Usuario::roles();
?>

<div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center mb-4 gap-2">
    <div>
        <h3 class="fw-bold mb-1"><i class="bi bi-person-badge-fill text-primary me-2"></i>Gestión de Usuarios</h3>
        <p class="text-muted mb-0">Administración de cuentas para Administradores, Doctores y Asistentes</p>
    </div>
    <button class="btn btn-primary" id="btnNuevoUsuario">
        <i class="bi bi-person-plus-fill me-1"></i>Nuevo Usuario
    </button>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle w-100" id="tablaUsuarios">
                <thead class="table-light">
                    <tr>
                        <th>Nombre y Cédula</th>
                        <th>Rol</th>
                        <th>Usuario</th>
                        <th>Contacto</th>
                        <th>Especialidad</th>
                        <th>Estado</th>
                        <th class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal para Crear / Editar Usuario -->
<div class="modal fade" id="modalUsuario" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-light">
                <h5 class="modal-title fw-bold" id="modalUsuarioTitle">Registrar Nuevo Usuario</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="formUsuario" novalidate>
                <div class="modal-body p-4">
                    <?= Csrf::field() ?>
                    <input type="hidden" id="usuario_id" name="id">

                    <div class="row g-3">
                        <div class="col-12 col-md-4">
                            <label for="rol_id" class="form-label fw-semibold">Rol del Sistema <span class="text-danger">*</span></label>
                            <select class="form-select" id="rol_id" name="rol_id" required>
                                <option value="">Seleccione rol...</option>
                                <?php foreach ($roles as $r): ?>
                                    <option value="<?= $r['id'] ?>"><?= htmlspecialchars($r['nombre']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-12 col-md-4">
                            <label for="cedula" class="form-label fw-semibold">Cédula / Documento <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="cedula" name="cedula" placeholder="Ej: V-12345678" required>
                        </div>

                        <div class="col-12 col-md-4">
                            <label for="estado" class="form-label fw-semibold">Estado de Cuenta</label>
                            <select class="form-select" id="estado" name="estado">
                                <option value="activo">Activo</option>
                                <option value="inactivo">Inactivo</option>
                            </select>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="nombres" class="form-label fw-semibold">Nombres <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="nombres" name="nombres" required>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="apellidos" class="form-label fw-semibold">Apellidos <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="apellidos" name="apellidos" required>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="email" class="form-label fw-semibold">Correo Electrónico <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="telefono" class="form-label fw-semibold">Teléfono</label>
                            <input type="text" class="form-control" id="telefono" name="telefono">
                        </div>

                        <!-- Campos específicos para Doctor -->
                        <div id="camposDoctor" class="col-12" style="display: none;">
                            <div class="p-3 bg-light rounded border">
                                <h6 class="fw-bold text-primary mb-2"><i class="bi bi-hospital me-1"></i>Información Profesional del Médico Odontólogo</h6>
                                <div class="row g-2">
                                    <div class="col-12 col-md-6">
                                        <label for="especialidad" class="form-label small fw-semibold">Especialidad</label>
                                        <input type="text" class="form-control form-control-sm" id="especialidad" name="especialidad" placeholder="Ej: Odontología General, Endodoncia">
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <label for="colegiatura" class="form-label small fw-semibold">Nº Colegiatura / Matrícula</label>
                                        <input type="text" class="form-control form-control-sm" id="colegiatura" name="colegiatura" placeholder="Ej: COL-1234">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="usuario" class="form-label fw-semibold">Nombre de Usuario <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text">@</span>
                                <input type="text" class="form-control" id="usuario" name="usuario" required>
                            </div>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="password" class="form-label fw-semibold">Contraseña</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder="••••••••">
                            <div class="form-text small" id="passwordHelp">Mínimo 6 caracteres.</div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary" id="btnSaveUsuario">
                        <i class="bi bi-save me-1"></i>Guardar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extraScripts = '<script src="' . ASSETS_URL . 'js/usuarios.js?v=1.0.1"></script>';
require_once __DIR__ . '/../layouts/footer.php';
?>

