<?php

$pageTitle = 'Mi Perfil';
require_once __DIR__ . '/../layouts/header.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Models\Usuario;

$user = Usuario::find(Auth::id());
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold mb-1"><i class="bi bi-person-circle text-primary me-2"></i>Mi Perfil</h3>
        <p class="text-muted mb-0">Actualización de datos personales y credenciales de acceso</p>
    </div>
</div>

<div class="row g-4">
    <div class="col-12 col-md-4">
        <div class="card shadow-sm text-center p-4">
            <div class="bg-primary-subtle text-primary fw-bold rounded-circle d-inline-flex align-items-center justify-content-center mx-auto mb-3" style="width: 80px; height: 80px; font-size: 2.2rem;">
                <?= strtoupper(substr(Auth::name(), 0, 1)) ?>
            </div>
            <h5 class="fw-bold mb-1"><?= htmlspecialchars(Auth::name()) ?></h5>
            <div class="badge bg-primary mb-3"><?= htmlspecialchars(Auth::role()) ?></div>

            <div class="text-start border-top pt-3 small text-muted">
                <p class="mb-1"><strong>Usuario:</strong> <code>@<?= htmlspecialchars($user['usuario']) ?></code></p>
                <p class="mb-1"><strong>Cédula:</strong> <?= htmlspecialchars($user['cedula']) ?></p>
                <?php if (!empty($user['especialidad'])): ?>
                    <p class="mb-1"><strong>Especialidad:</strong> <?= htmlspecialchars($user['especialidad']) ?></p>
                <?php endif; ?>
                <?php if (!empty($user['colegiatura'])): ?>
                    <p class="mb-1"><strong>Colegiatura:</strong> <?= htmlspecialchars($user['colegiatura']) ?></p>
                <?php endif; ?>
                <p class="mb-1"><strong>Último Acceso:</strong> <?= $user['ultimo_acceso'] ? date('d/m/Y H:i', strtotime($user['ultimo_acceso'])) : 'Primer acceso' ?></p>
            </div>
        </div>
    </div>

    <div class="col-12 col-md-8">
        <div class="card shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="card-title fw-bold mb-0">Modificar Datos Personales y Clave</h5>
            </div>
            <div class="card-body p-4">
                <form id="formPerfil">
                    <?= Csrf::field() ?>

                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <label for="perfil_nombres" class="form-label fw-semibold">Nombres <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="perfil_nombres" name="nombres" value="<?= htmlspecialchars($user['nombres']) ?>" required>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="perfil_apellidos" class="form-label fw-semibold">Apellidos <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="perfil_apellidos" name="apellidos" value="<?= htmlspecialchars($user['apellidos']) ?>" required>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="perfil_email" class="form-label fw-semibold">Correo Electrónico <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="perfil_email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="perfil_telefono" class="form-label fw-semibold">Teléfono</label>
                            <input type="text" class="form-control" id="perfil_telefono" name="telefono" value="<?= htmlspecialchars($user['telefono'] ?? '') ?>">
                        </div>

                        <div class="col-12 border-top pt-3 mt-4">
                            <h6 class="fw-bold text-dark mb-2">Cambiar Contraseña</h6>
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label for="perfil_password" class="form-label fw-semibold">Nueva Contraseña</label>
                                    <input type="password" class="form-control" id="perfil_password" name="password" placeholder="••••••••">
                                    <div class="form-text small">Dejar en blanco para mantener la contraseña actual.</div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label for="perfil_password_confirm" class="form-label fw-semibold">Confirmar Nueva Contraseña</label>
                                    <input type="password" class="form-control" id="perfil_password_confirm" placeholder="••••••••">
                                </div>
                            </div>
                        </div>

                        <div class="col-12 text-end pt-3 border-top">
                            <button type="submit" class="btn btn-primary px-4 fw-bold" id="btnSavePerfil">
                                <i class="bi bi-save me-1"></i>Guardar Cambios
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
$extraScripts = <<<'SCRIPT'
<script>
$(document).ready(function() {
    $('#formPerfil').on('submit', function(e) {
        e.preventDefault();

        const p1 = $('#perfil_password').val();
        const p2 = $('#perfil_password_confirm').val();

        if (p1 && p1.length < 6) {
            Swal.fire({ icon: 'warning', title: 'Atención', text: 'La contraseña debe contener al menos 6 caracteres.' });
            return;
        }

        if (p1 && p1 !== p2) {
            Swal.fire({ icon: 'warning', title: 'Atención', text: 'Las nuevas contraseñas no coinciden.' });
            return;
        }

        const btn = $('#btnSavePerfil');
        btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span>Guardando...');

        $.ajax({
            url: BASE_URL + 'ajax/perfil.php?action=update',
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(res) {
                if (res.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Perfil actualizado',
                        text: res.message,
                        timer: 1500,
                        showConfirmButton: false
                    }).then(() => {
                        window.location.reload();
                    });
                } else {
                    Swal.fire({ icon: 'error', title: 'Error', text: res.message });
                    btn.prop('disabled', false).html('<i class="bi bi-save me-1"></i>Guardar Cambios');
                }
            },
            error: function(xhr) {
                let msg = 'Error al actualizar el perfil.';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    msg = xhr.responseJSON.message;
                }
                Swal.fire({ icon: 'error', title: 'Error', text: msg });
                btn.prop('disabled', false).html('<i class="bi bi-save me-1"></i>Guardar Cambios');
            }
        });
    });
});
</script>
SCRIPT;

require_once __DIR__ . '/../layouts/footer.php';
?>

