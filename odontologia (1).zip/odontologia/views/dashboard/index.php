<?php

use App\Core\Auth;

$pageTitle = 'Panel Principal';
require_once __DIR__ . '/../layouts/header.php';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 gap-2">
    <div>
        <h3 class="fw-bold mb-1">Bienvenido(a), <?= htmlspecialchars(Auth::name()) ?></h3>
        <p class="text-muted mb-0">Resumen clínico y actividades del día</p>
    </div>
    <div class="d-flex gap-2">
        <?php if (Auth::isAsistente() || Auth::isAdmin()): ?>
            <a href="<?= BASE_URL ?>views/pacientes/index.php?action=new" class="btn btn-outline-primary">
                <i class="bi bi-person-plus me-1"></i>Nuevo Paciente
            </a>
            <a href="<?= BASE_URL ?>views/citas/index.php?action=new" class="btn btn-primary">
                <i class="bi bi-calendar-plus me-1"></i>Agendar Cita
            </a>
        <?php endif; ?>
        <?php if (Auth::isDoctor()): ?>
            <a href="<?= BASE_URL ?>views/consultas/atender.php" class="btn btn-primary">
                <i class="bi bi-clipboard2-pulse me-1"></i>Iniciar Consulta
            </a>
        <?php endif; ?>
    </div>
</div>

<!-- Widgets de Estadísticas -->
<div class="row g-3 mb-4">
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card stat-widget h-100">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-primary-subtle text-primary me-3">
                    <i class="bi bi-people-fill"></i>
                </div>
                <div>
                    <div class="text-muted small fw-semibold">Pacientes Registrados</div>
                    <h3 class="fw-bold mb-0" id="statPacientes">--</h3>
                </div>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card stat-widget h-100">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-warning-subtle text-warning me-3">
                    <i class="bi bi-calendar-event-fill"></i>
                </div>
                <div>
                    <div class="text-muted small fw-semibold">Citas para Hoy</div>
                    <h3 class="fw-bold mb-0" id="statCitasHoy">--</h3>
                </div>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card stat-widget h-100">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-success-subtle text-success me-3">
                    <i class="bi bi-clipboard2-check-fill"></i>
                </div>
                <div>
                    <div class="text-muted small fw-semibold">Consultas del Mes</div>
                    <h3 class="fw-bold mb-0" id="statConsultasMes">--</h3>
                </div>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card stat-widget h-100">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-info-subtle text-info me-3">
                    <i class="bi bi-journal-medical"></i>
                </div>
                <div>
                    <div class="text-muted small fw-semibold">Procedimientos Realizados</div>
                    <h3 class="fw-bold mb-0" id="statProcedimientosMes">--</h3>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Gráficos y Agenda -->
<div class="row g-3 mb-4">
    <!-- Citas del Día -->
    <div class="col-12 col-lg-8">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span class="fw-bold"><i class="bi bi-clock-history me-2 text-primary"></i>Citas Programadas para Hoy</span>
                <a href="<?= BASE_URL ?>views/citas/index.php" class="btn btn-sm btn-outline-primary">Ver todas</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" id="tableCitasHoy">
                        <thead class="table-light">
                            <tr>
                                <th>Hora</th>
                                <th>Paciente</th>
                                <th>Doctor</th>
                                <th>Motivo</th>
                                <th>Estado</th>
                                <th class="text-end">Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colspan="6" class="text-center py-3 text-muted">Cargando citas...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Procedimientos Más Frecuentes -->
    <div class="col-12 col-lg-4">
        <div class="card h-100">
            <div class="card-header fw-bold">
                <i class="bi bi-pie-chart-fill me-2 text-primary"></i>Procedimientos Frecuentes
            </div>
            <div class="card-body d-flex align-items-center justify-content-center" style="min-height: 250px;">
                <canvas id="chartProcedimientos" style="max-height: 240px;"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    <!-- Consultas Mensuales -->
    <div class="col-12">
        <div class="card">
            <div class="card-header fw-bold">
                <i class="bi bi-bar-chart-fill me-2 text-primary"></i>Histórico de Atenciones Odontológicas
            </div>
            <div class="card-body" style="height: 280px;">
                <canvas id="chartConsultasMensuales"></canvas>
            </div>
        </div>
    </div>
</div>

<?php
$extraScripts = '<script src="' . ASSETS_URL . 'js/dashboard.js?v=1.0.1"></script>';
require_once __DIR__ . '/../layouts/footer.php';
?>

