# Sistema de Gestión de Historias Clínicas Odontológicas

Sistema web para la administración de historias clínicas odontológicas, control de citas, registro de signos vitales, diagnósticos y procedimientos ejecutados.

## Requisitos del Sistema
- PHP 8.1 o superior con extensiones activas: `pdo_mysql`, `mbstring`, `gd`, `curl`.
- Servidor Web Apache (XAMPP).
- Servidor de Base de Datos MySQL / MariaDB.
- Composer para la gestión de dependencias (Dompdf).

## Arquitectura y Tecnologías
- **Backend**: PHP 8.1 orientado a objetos con arquitectura MVC ligera y PDO con sentencias preparadas.
- **Base de Datos**: MySQL (InnoDB, utf8mb4, claves foráneas e integridad referencial).
- **Frontend**: Bootstrap 5.3, Bootstrap Icons, diseño completamente responsive para móviles, tablets y monitores.
- **AJAX**: Peticiones asíncronas con jQuery y endpoints JSON estructurados.
- **Tablas Dinámicas**: DataTables con filtros, ordenamiento, paginación y localización en español.
- **Notificaciones**: SweetAlert2.
- **Gráficos**: Chart.js.
- **Reportes Clínicos**: Dompdf (generación directa en PDF).

## Instalación y Configuración

1. **Ubicación del Proyecto**:
   Ubicar la carpeta `odontologia` en el directorio web de Apache:
   `c:\xampp\htdocs\odontologia`

2. **Instalación de Dependencias**:
   Ejecutar en la raíz del proyecto:
   ```bash
   composer install
   ```

3. **Importación de la Base de Datos**:
   Crear la base de datos `odontologia_db` e importar el archivo `database/odontologia.sql` mediante phpMyAdmin o desde la consola de comandos de MySQL:
   ```bash
   mysql -u root -p < database/odontologia.sql
   ```

4. **Acceso al Sistema**:
   Abrir el navegador web e ingresar a:
   `http://localhost/odontologia`

## Credenciales de Demostración

| Rol | Usuario | Contraseña | Permisos |
|---|---|---|---|
| **Administrador** | `admin` | `admin123` | Control total del sistema, configuración institucional, gestión de usuarios, procedimientos y reportes. |
| **Doctor(a)** | `doctor` | `doctor123` | Agenda de citas asignadas, atención clínica (signos vitales, diagnósticos, procedimientos realizados) e historia clínica en PDF. |
| **Asistente** | `asistente` | `asistente123` | Registro y edición de pacientes, programación y control de citas odontológicas. |

## Módulos Principales
- **Panel Principal**: Métricas clave (pacientes registrados, citas del día, consultas y procedimientos mensuales) y gráficos interactivos.
- **Configuración de la Clínica**: Permite al Administrador personalizar el nombre del centro médico, identificación fiscal, dirección, teléfonos, correo, logo institucional y pie de página de los reportes.
- **Pacientes**: Registro detallado con datos de filiación y antecedentes médicos (alergias con alerta médica, cirugías, medicamentos crónicos, patologías sistémicas y hábitos).
- **Agenda de Citas**: Asignación de turnos a médicos odontólogos con prevención automática de choques de horario.
- **Atención de Consultas**: Módulo clínico exclusivo para médicos odontólogos para registrar signos vitales, diagnósticos patológicos clasificados y procedimientos odontológicos realizados en la sesión.
- **Historias Clínicas**: Expediente médico digital con línea de tiempo y exportación oficial a formato PDF.
- **Catálogo de Procedimientos**: Mantenimiento del inventario de tratamientos clínicos disponibles (limpiezas, extracciones simples o cordales, endodoncias, calzas/resinas, blanqueamientos, etc.).

