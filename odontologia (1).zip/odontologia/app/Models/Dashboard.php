<?php

namespace App\Models;

use Config\Database;
use PDO;

class Dashboard
{
    public static function getStats(?int $doctorId = null): array
    {
        $db = Database::getConnection();

        // 1. Total pacientes
        $stmtPacientes = $db->query("SELECT COUNT(*) FROM pacientes WHERE estado = 'activo'");
        $totalPacientes = (int)$stmtPacientes->fetchColumn();

        // 2. Citas hoy
        if ($doctorId) {
            $stmtCitas = $db->prepare("SELECT COUNT(*) FROM citas WHERE fecha = CURDATE() AND doctor_id = :doc AND estado != 'cancelada'");
            $stmtCitas->execute([':doc' => $doctorId]);
        } else {
            $stmtCitas = $db->query("SELECT COUNT(*) FROM citas WHERE fecha = CURDATE() AND estado != 'cancelada'");
        }
        $citasHoy = (int)$stmtCitas->fetchColumn();

        // 3. Consultas este mes
        if ($doctorId) {
            $stmtConsultas = $db->prepare("
                SELECT COUNT(*) FROM consultas 
                WHERE doctor_id = :doc 
                  AND MONTH(fecha_registro) = MONTH(CURRENT_DATE()) 
                  AND YEAR(fecha_registro) = YEAR(CURRENT_DATE())
            ");
            $stmtConsultas->execute([':doc' => $doctorId]);
        } else {
            $stmtConsultas = $db->query("
                SELECT COUNT(*) FROM consultas 
                WHERE MONTH(fecha_registro) = MONTH(CURRENT_DATE()) 
                  AND YEAR(fecha_registro) = YEAR(CURRENT_DATE())
            ");
        }
        $consultasMes = (int)$stmtConsultas->fetchColumn();

        // 4. Procedimientos realizados en el mes
        if ($doctorId) {
            $stmtProc = $db->prepare("
                SELECT COUNT(*) FROM consulta_procedimientos cp
                INNER JOIN consultas c ON cp.consulta_id = c.id
                WHERE c.doctor_id = :doc
                  AND MONTH(cp.created_at) = MONTH(CURRENT_DATE()) 
                  AND YEAR(cp.created_at) = YEAR(CURRENT_DATE())
            ");
            $stmtProc->execute([':doc' => $doctorId]);
        } else {
            $stmtProc = $db->query("
                SELECT COUNT(*) FROM consulta_procedimientos cp
                WHERE MONTH(cp.created_at) = MONTH(CURRENT_DATE()) 
                  AND YEAR(cp.created_at) = YEAR(CURRENT_DATE())
            ");
        }
        $procedimientosMes = (int)$stmtProc->fetchColumn();

        return [
            'total_pacientes'    => $totalPacientes,
            'citas_hoy'          => $citasHoy,
            'consultas_mes'      => $consultasMes,
            'procedimientos_mes' => $procedimientosMes
        ];
    }

    public static function getTopProcedures(int $limit = 5): array
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("
            SELECT p.nombre, COUNT(cp.id) AS total
            FROM procedimientos p
            INNER JOIN consulta_procedimientos cp ON cp.procedimiento_id = p.id
            GROUP BY p.id, p.nombre
            ORDER BY total DESC
            LIMIT :limit
        ");
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function getMonthlyConsultations(): array
    {
        $db = Database::getConnection();
        $stmt = $db->query("
            SELECT 
                DATE_FORMAT(fecha_registro, '%Y-%m') AS periodo,
                DATE_FORMAT(fecha_registro, '%b %Y') AS etiqueta,
                COUNT(*) AS total
            FROM consultas
            WHERE fecha_registro >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
            GROUP BY periodo, etiqueta
            ORDER BY periodo ASC
        ");
        return $stmt->fetchAll();
    }
}

