<?php

namespace App\Models;

use Config\Database;
use PDO;
use Exception;

class Consulta
{
    public static function create(array $consultaData, array $signosData, array $diagnosticos, array $procedimientos): int
    {
        $db = Database::getConnection();
        $db->beginTransaction();

        try {
            // 1. Insertar consulta
            $stmt = $db->prepare("
                INSERT INTO consultas (
                    cita_id, paciente_id, doctor_id, fecha_registro, motivo_consulta,
                    enfermedad_actual, examen_estomatologico, indicaciones_tratamiento, proxima_cita_sugerida
                ) VALUES (
                    :cita_id, :paciente_id, :doctor_id, NOW(), :motivo_consulta,
                    :enfermedad_actual, :examen_estomatologico, :indicaciones_tratamiento, :proxima_cita_sugerida
                )
            ");

            $stmt->execute([
                ':cita_id'                  => !empty($consultaData['cita_id']) ? $consultaData['cita_id'] : null,
                ':paciente_id'              => $consultaData['paciente_id'],
                ':doctor_id'                => $consultaData['doctor_id'],
                ':motivo_consulta'          => $consultaData['motivo_consulta'],
                ':enfermedad_actual'        => $consultaData['enfermedad_actual'] ?? null,
                ':examen_estomatologico'    => $consultaData['examen_estomatologico'] ?? null,
                ':indicaciones_tratamiento' => $consultaData['indicaciones_tratamiento'] ?? null,
                ':proxima_cita_sugerida'    => !empty($consultaData['proxima_cita_sugerida']) ? $consultaData['proxima_cita_sugerida'] : null
            ]);

            $consultaId = (int)$db->lastInsertId();

            // 2. Insertar signos vitales
            $stmtSignos = $db->prepare("
                INSERT INTO signos_vitales (
                    consulta_id, presion_sistolica, presion_diastolica, frecuencia_cardiaca,
                    frecuencia_respiratoria, temperatura, saturacion_oxigeno, peso, talla, observaciones
                ) VALUES (
                    :consulta_id, :presion_sistolica, :presion_diastolica, :frecuencia_cardiaca,
                    :frecuencia_respiratoria, :temperatura, :saturacion_oxigeno, :peso, :talla, :observaciones
                )
            ");

            $stmtSignos->execute([
                ':consulta_id'             => $consultaId,
                ':presion_sistolica'      => !empty($signosData['presion_sistolica']) ? (int)$signosData['presion_sistolica'] : null,
                ':presion_diastolica'     => !empty($signosData['presion_diastolica']) ? (int)$signosData['presion_diastolica'] : null,
                ':frecuencia_cardiaca'    => !empty($signosData['frecuencia_cardiaca']) ? (int)$signosData['frecuencia_cardiaca'] : null,
                ':frecuencia_respiratoria'=> !empty($signosData['frecuencia_respiratoria']) ? (int)$signosData['frecuencia_respiratoria'] : null,
                ':temperatura'            => !empty($signosData['temperatura']) ? (float)$signosData['temperatura'] : null,
                ':saturacion_oxigeno'     => !empty($signosData['saturacion_oxigeno']) ? (int)$signosData['saturacion_oxigeno'] : null,
                ':peso'                   => !empty($signosData['peso']) ? (float)$signosData['peso'] : null,
                ':talla'                  => !empty($signosData['talla']) ? (float)$signosData['talla'] : null,
                ':observaciones'          => $signosData['observaciones'] ?? null
            ]);

            // 3. Insertar diagnósticos
            if (!empty($diagnosticos)) {
                $stmtDiag = $db->prepare("
                    INSERT INTO diagnosticos (consulta_id, pieza_dental, descripcion, tipo)
                    VALUES (:consulta_id, :pieza_dental, :descripcion, :tipo)
                ");

                foreach ($diagnosticos as $d) {
                    if (!empty($d['descripcion'])) {
                        $stmtDiag->execute([
                            ':consulta_id'  => $consultaId,
                            ':pieza_dental' => !empty($d['pieza_dental']) ? trim($d['pieza_dental']) : null,
                            ':descripcion'  => trim($d['descripcion']),
                            ':tipo'         => in_array($d['tipo'] ?? '', ['presuntivo', 'definitivo']) ? $d['tipo'] : 'definitivo'
                        ]);
                    }
                }
            }

            // 4. Insertar procedimientos realizados
            if (!empty($procedimientos)) {
                $stmtProc = $db->prepare("
                    INSERT INTO consulta_procedimientos (consulta_id, procedimiento_id, pieza_dental, observaciones)
                    VALUES (:consulta_id, :procedimiento_id, :pieza_dental, :observaciones)
                ");

                foreach ($procedimientos as $p) {
                    if (!empty($p['procedimiento_id'])) {
                        $stmtProc->execute([
                            ':consulta_id'       => $consultaId,
                            ':procedimiento_id'  => (int)$p['procedimiento_id'],
                            ':pieza_dental'      => !empty($p['pieza_dental']) ? trim($p['pieza_dental']) : null,
                            ':observaciones'     => !empty($p['observaciones']) ? trim($p['observaciones']) : null
                        ]);
                    }
                }
            }

            // 5. Si proviene de una cita, actualizar estado a 'atendida'
            if (!empty($consultaData['cita_id'])) {
                $stmtCita = $db->prepare("UPDATE citas SET estado = 'atendida' WHERE id = :cita_id");
                $stmtCita->execute([':cita_id' => $consultaData['cita_id']]);
            }

            $db->commit();
            return $consultaId;
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }
    }

    public static function find(int $id): ?array
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("
            SELECT c.*,
                   p.codigo AS paciente_codigo, p.cedula AS paciente_cedula,
                   p.nombres AS paciente_nombres, p.apellidos AS paciente_apellidos,
                   p.fecha_nacimiento, p.sexo, p.telefono AS paciente_telefono,
                   TIMESTAMPDIFF(YEAR, p.fecha_nacimiento, c.fecha_registro) AS edad_en_consulta,
                   CONCAT(u.nombres, ' ', u.apellidos) AS doctor_nombre,
                   u.especialidad AS doctor_especialidad, u.colegiatura AS doctor_colegiatura
            FROM consultas c
            INNER JOIN pacientes p ON c.paciente_id = p.id
            INNER JOIN usuarios u ON c.doctor_id = u.id
            WHERE c.id = :id
            LIMIT 1
        ");
        $stmt->execute([':id' => $id]);
        $consulta = $stmt->fetch();

        if (!$consulta) {
            return null;
        }

        // Cargar signos vitales
        $stmtSignos = $db->prepare("SELECT * FROM signos_vitales WHERE consulta_id = :id LIMIT 1");
        $stmtSignos->execute([':id' => $id]);
        $consulta['signos_vitales'] = $stmtSignos->fetch() ?: [];

        // Cargar diagnósticos
        $stmtDiag = $db->prepare("SELECT * FROM diagnosticos WHERE consulta_id = :id ORDER BY id ASC");
        $stmtDiag->execute([':id' => $id]);
        $consulta['diagnosticos'] = $stmtDiag->fetchAll();

        // Cargar procedimientos realizados
        $stmtProc = $db->prepare("
            SELECT cp.*, p.nombre AS procedimiento_nombre, p.categoria, p.codigo AS procedimiento_codigo
            FROM consulta_procedimientos cp
            INNER JOIN procedimientos p ON cp.procedimiento_id = p.id
            WHERE cp.consulta_id = :id
            ORDER BY cp.id ASC
        ");
        $stmtProc->execute([':id' => $id]);
        $consulta['procedimientos'] = $stmtProc->fetchAll();

        return $consulta;
    }

    public static function getByPaciente(int $pacienteId): array
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("
            SELECT c.*,
                   CONCAT(u.nombres, ' ', u.apellidos) AS doctor_nombre,
                   u.especialidad AS doctor_especialidad,
                   sv.presion_sistolica, sv.presion_diastolica, sv.frecuencia_cardiaca,
                   sv.temperatura, sv.saturacion_oxigeno,
                   (SELECT COUNT(*) FROM diagnosticos d WHERE d.consulta_id = c.id) AS total_diagnosticos,
                   (SELECT COUNT(*) FROM consulta_procedimientos cp WHERE cp.consulta_id = c.id) AS total_procedimientos
            FROM consultas c
            INNER JOIN usuarios u ON c.doctor_id = u.id
            LEFT JOIN signos_vitales sv ON sv.consulta_id = c.id
            WHERE c.paciente_id = :paciente_id
            ORDER BY c.fecha_registro DESC
        ");
        $stmt->execute([':paciente_id' => $pacienteId]);
        $consultas = $stmt->fetchAll();

        // Para cada consulta cargamos diagnósticos y procedimientos para la vista de historia clínica
        foreach ($consultas as &$con) {
            $stmtDiag = $db->prepare("SELECT * FROM diagnosticos WHERE consulta_id = :id ORDER BY id ASC");
            $stmtDiag->execute([':id' => $con['id']]);
            $con['diagnosticos'] = $stmtDiag->fetchAll();

            $stmtProc = $db->prepare("
                SELECT cp.*, p.nombre AS procedimiento_nombre, p.categoria
                FROM consulta_procedimientos cp
                INNER JOIN procedimientos p ON cp.procedimiento_id = p.id
                WHERE cp.consulta_id = :id
                ORDER BY cp.id ASC
            ");
            $stmtProc->execute([':id' => $con['id']]);
            $con['procedimientos'] = $stmtProc->fetchAll();
        }

        return $consultas;
    }
}

