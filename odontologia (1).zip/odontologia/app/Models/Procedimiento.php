<?php

namespace App\Models;

use Config\Database;
use PDO;

class Procedimiento
{
    public static function all(bool $onlyActive = false): array
    {
        $db = Database::getConnection();
        $sql = "
            SELECT p.*,
                   (SELECT COUNT(*) FROM consulta_procedimientos cp WHERE cp.procedimiento_id = p.id) AS total_realizados
            FROM procedimientos p
        ";
        if ($onlyActive) {
            $sql .= " WHERE p.estado = 'activo'";
        }
        $sql .= " ORDER BY p.categoria ASC, p.nombre ASC";
        return $db->query($sql)->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("SELECT * FROM procedimientos WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function generateCode(): string
    {
        $db = Database::getConnection();
        $stmt = $db->query("SELECT MAX(id) AS max_id FROM procedimientos");
        $row = $stmt->fetch();
        $nextId = ($row && $row['max_id']) ? ((int)$row['max_id'] + 1) : 1;
        return sprintf('PROC-%03d', $nextId);
    }

    public static function create(array $data): int
    {
        $db = Database::getConnection();
        $codigo = !empty($data['codigo']) ? trim($data['codigo']) : self::generateCode();

        $stmt = $db->prepare("
            INSERT INTO procedimientos (codigo, nombre, categoria, descripcion, estado)
            VALUES (:codigo, :nombre, :categoria, :descripcion, :estado)
        ");

        $stmt->execute([
            ':codigo'      => $codigo,
            ':nombre'      => $data['nombre'],
            ':categoria'   => $data['categoria'] ?? 'General',
            ':descripcion' => $data['descripcion'] ?? null,
            ':estado'      => $data['estado'] ?? 'activo'
        ]);

        return (int)$db->lastInsertId();
    }

    public static function update(int $id, array $data): bool
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("
            UPDATE procedimientos SET
                nombre = :nombre,
                categoria = :categoria,
                descripcion = :descripcion,
                estado = :estado
            WHERE id = :id
        ");

        return $stmt->execute([
            ':id'          => $id,
            ':nombre'      => $data['nombre'],
            ':categoria'   => $data['categoria'] ?? 'General',
            ':descripcion' => $data['descripcion'] ?? null,
            ':estado'      => $data['estado'] ?? 'activo'
        ]);
    }

    public static function toggleStatus(int $id): bool
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("
            UPDATE procedimientos 
            SET estado = IF(estado = 'activo', 'inactivo', 'activo') 
            WHERE id = :id
        ");
        return $stmt->execute([':id' => $id]);
    }

    public static function categories(): array
    {
        return [
            'Prevención',
            'Restauradora',
            'Endodoncia',
            'Cirugía',
            'Periodoncia',
            'Ortodoncia',
            'Prótesis',
            'Estética',
            'Urgencias',
            'Diagnóstico',
            'General'
        ];
    }
}

