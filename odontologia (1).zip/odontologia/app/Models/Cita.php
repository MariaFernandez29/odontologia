<?php

namespace App\Models;

use Config\Database;
use PDO;

class Cita
{
    public static function all(array $filters = []): array
    {
        $db = Database::getConnection();
        $sql = "
            SELECT c.*,
                   p.codigo AS paciente_codigo, p.cedula AS paciente_cedula, 
                   CONCAT(p.nombres, ' ', p.apellidos) AS paciente_nombre,
                   p.telefono AS paciente_telefono, p.email AS paciente_email,
                   CONCAT(u.nombres, ' ', u.apellidos) AS doctor_nombre,
                   u.especialidad AS doctor_especialidad,
                   CONCAT(ur.nombres, ' ', ur.apellidos) AS registrador_nombre,
                   (SELECT id FROM consultas con WHERE con.cita_id = c.id LIMIT 1) AS consulta_id
            FROM citas c
            INNER JOIN pacientes p ON c.paciente_id = p.id
            INNER JOIN usuarios u ON c.doctor_id = u.id
            INNER JOIN usuarios ur ON c.registrado_por = ur.id
            WHERE 1=1
        ";

        $params = [];

        if (!empty($filters['doctor_id'])) {
            $sql .= " AND c.doctor_id = :doctor_id";
            $params[':doctor_id'] = $filters['doctor_id'];
        }

        if (!empty($filters['paciente_id'])) {
            $sql .= " AND c.paciente_id = :paciente_id";
            $params[':paciente_id'] = $filters['paciente_id'];
        }

        if (!empty($filters['fecha'])) {
            $sql .= " AND c.fecha = :fecha";
            $params[':fecha'] = $filters['fecha'];
        }

        if (!empty($filters['fecha_desde'])) {
            $sql .= " AND c.fecha >= :fecha_desde";
            $params[':fecha_desde'] = $filters['fecha_desde'];
        }

        if (!empty($filters['fecha_hasta'])) {
            $sql .= " AND c.fecha <= :fecha_hasta";
            $params[':fecha_hasta'] = $filters['fecha_hasta'];
        }

        if (!empty($filters['estado'])) {
            $sql .= " AND c.estado = :estado";
            $params[':estado'] = $filters['estado'];
        }

        $sql .= " ORDER BY c.fecha DESC, c.hora DESC";

        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("
            SELECT c.*,
                   p.id AS paciente_id, p.codigo AS paciente_codigo, p.cedula AS paciente_cedula, 
                   CONCAT(p.nombres, ' ', p.apellidos) AS paciente_nombre,
                   p.telefono AS paciente_telefono, p.email AS paciente_email,
                   p.fecha_nacimiento, p.sexo,
                   CONCAT(u.nombres, ' ', u.apellidos) AS doctor_nombre,
                   u.especialidad AS doctor_especialidad,
                   CONCAT(ur.nombres, ' ', ur.apellidos) AS registrador_nombre,
                   (SELECT id FROM consultas con WHERE con.cita_id = c.id LIMIT 1) AS consulta_id
            FROM citas c
            INNER JOIN pacientes p ON c.paciente_id = p.id
            INNER JOIN usuarios u ON c.doctor_id = u.id
            INNER JOIN usuarios ur ON c.registrado_por = ur.id
            WHERE c.id = :id
            LIMIT 1
        ");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function hasConflict(int $doctorId, string $fecha, string $hora, ?int $excludeCitaId = null): bool
    {
        $db = Database::getConnection();
        $sql = "
            SELECT id FROM citas 
            WHERE doctor_id = :doctor_id 
              AND fecha = :fecha 
              AND hora = :hora
              AND estado NOT IN ('cancelada', 'no_asistio')
        ";
        if ($excludeCitaId) {
            $sql .= " AND id != :excludeCitaId";
        }

        $stmt = $db->prepare($sql);
        $params = [
            ':doctor_id' => $doctorId,
            ':fecha'     => $fecha,
            ':hora'      => $hora
        ];
        if ($excludeCitaId) {
            $params[':excludeCitaId'] = $excludeCitaId;
        }

        $stmt->execute($params);
        return (bool)$stmt->fetch();
    }

    public static function create(array $data): int
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("
            INSERT INTO citas (paciente_id, doctor_id, registrado_por, fecha, hora, motivo, estado, observaciones)
            VALUES (:paciente_id, :doctor_id, :registrado_por, :fecha, :hora, :motivo, :estado, :observaciones)
        ");

        $stmt->execute([
            ':paciente_id'     => $data['paciente_id'],
            ':doctor_id'       => $data['doctor_id'],
            ':registrado_por'  => $data['registrado_por'],
            ':fecha'           => $data['fecha'],
            ':hora'            => $data['hora'],
            ':motivo'          => $data['motivo'],
            ':estado'          => $data['estado'] ?? 'pendiente',
            ':observaciones'   => $data['observaciones'] ?? null
        ]);

        return (int)$db->lastInsertId();
    }

    public static function update(int $id, array $data): bool
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("
            UPDATE citas SET
                paciente_id = :paciente_id,
                doctor_id = :doctor_id,
                fecha = :fecha,
                hora = :hora,
                motivo = :motivo,
                estado = :estado,
                observaciones = :observaciones
            WHERE id = :id
        ");

        return $stmt->execute([
            ':id'            => $id,
            ':paciente_id'   => $data['paciente_id'],
            ':doctor_id'     => $data['doctor_id'],
            ':fecha'         => $data['fecha'],
            ':hora'          => $data['hora'],
            ':motivo'        => $data['motivo'],
            ':estado'        => $data['estado'],
            ':observaciones' => $data['observaciones'] ?? null
        ]);
    }

    public static function updateStatus(int $id, string $status): bool
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("UPDATE citas SET estado = :status WHERE id = :id");
        return $stmt->execute([':id' => $id, ':status' => $status]);
    }

    public static function getTodayAppointments(?int $doctorId = null): array
    {
        $filters = ['fecha' => date('Y-m-d')];
        if ($doctorId) {
            $filters['doctor_id'] = $doctorId;
        }
        return self::all($filters);
    }
}

