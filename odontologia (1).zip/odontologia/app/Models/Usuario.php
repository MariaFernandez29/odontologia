<?php

namespace App\Models;

use Config\Database;
use PDO;

class Usuario
{
    public static function all(): array
    {
        $db = Database::getConnection();
        $stmt = $db->query("
            SELECT u.id, u.rol_id, r.nombre AS rol_nombre, u.nombres, u.apellidos, 
                   u.cedula, u.email, u.telefono, u.especialidad, u.colegiatura, 
                   u.usuario, u.estado, u.ultimo_acceso, u.created_at
            FROM usuarios u
            INNER JOIN roles r ON u.rol_id = r.id
            ORDER BY u.id DESC
        ");
        return $stmt->fetchAll();
    }

    public static function getDoctors(): array
    {
        $db = Database::getConnection();
        $stmt = $db->query("
            SELECT id, nombres, apellidos, especialidad, colegiatura, telefono
            FROM usuarios
            WHERE rol_id = 2 AND estado = 'activo'
            ORDER BY nombres ASC, apellidos ASC
        ");
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("
            SELECT u.*, r.nombre AS rol_nombre
            FROM usuarios u
            INNER JOIN roles r ON u.rol_id = r.id
            WHERE u.id = :id
            LIMIT 1
        ");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function roles(): array
    {
        $db = Database::getConnection();
        $stmt = $db->query("SELECT id, nombre, descripcion FROM roles ORDER BY id ASC");
        return $stmt->fetchAll();
    }

    public static function create(array $data): int
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("
            INSERT INTO usuarios (
                rol_id, nombres, apellidos, cedula, email, telefono, 
                especialidad, colegiatura, usuario, password_hash, estado
            ) VALUES (
                :rol_id, :nombres, :apellidos, :cedula, :email, :telefono,
                :especialidad, :colegiatura, :usuario, :password_hash, :estado
            )
        ");

        $stmt->execute([
            ':rol_id'        => $data['rol_id'],
            ':nombres'       => $data['nombres'],
            ':apellidos'     => $data['apellidos'],
            ':cedula'        => $data['cedula'],
            ':email'         => $data['email'],
            ':telefono'      => $data['telefono'] ?? null,
            ':especialidad'  => $data['especialidad'] ?? null,
            ':colegiatura'   => $data['colegiatura'] ?? null,
            ':usuario'       => $data['usuario'],
            ':password_hash' => password_hash($data['password'], PASSWORD_BCRYPT),
            ':estado'        => $data['estado'] ?? 'activo'
        ]);

        return (int)$db->lastInsertId();
    }

    public static function update(int $id, array $data): bool
    {
        $db = Database::getConnection();
        $fields = [
            'rol_id = :rol_id',
            'nombres = :nombres',
            'apellidos = :apellidos',
            'cedula = :cedula',
            'email = :email',
            'telefono = :telefono',
            'especialidad = :especialidad',
            'colegiatura = :colegiatura',
            'usuario = :usuario',
            'estado = :estado'
        ];

        $params = [
            ':id'           => $id,
            ':rol_id'       => $data['rol_id'],
            ':nombres'      => $data['nombres'],
            ':apellidos'    => $data['apellidos'],
            ':cedula'       => $data['cedula'],
            ':email'        => $data['email'],
            ':telefono'     => $data['telefono'] ?? null,
            ':especialidad' => $data['especialidad'] ?? null,
            ':colegiatura'  => $data['colegiatura'] ?? null,
            ':usuario'      => $data['usuario'],
            ':estado'       => $data['estado'] ?? 'activo'
        ];

        if (!empty($data['password'])) {
            $fields[] = 'password_hash = :password_hash';
            $params[':password_hash'] = password_hash($data['password'], PASSWORD_BCRYPT);
        }

        $sql = "UPDATE usuarios SET " . implode(', ', $fields) . " WHERE id = :id";
        $stmt = $db->prepare($sql);
        return $stmt->execute($params);
    }

    public static function updateProfile(int $id, array $data): bool
    {
        $db = Database::getConnection();
        $fields = [
            'nombres = :nombres',
            'apellidos = :apellidos',
            'email = :email',
            'telefono = :telefono'
        ];
        $params = [
            ':id'        => $id,
            ':nombres'   => $data['nombres'],
            ':apellidos' => $data['apellidos'],
            ':email'     => $data['email'],
            ':telefono'  => $data['telefono'] ?? null
        ];

        if (!empty($data['password'])) {
            $fields[] = 'password_hash = :password_hash';
            $params[':password_hash'] = password_hash($data['password'], PASSWORD_BCRYPT);
        }

        $sql = "UPDATE usuarios SET " . implode(', ', $fields) . " WHERE id = :id";
        $stmt = $db->prepare($sql);
        return $stmt->execute($params);
    }

    public static function toggleStatus(int $id): bool
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("
            UPDATE usuarios 
            SET estado = IF(estado = 'activo', 'inactivo', 'activo') 
            WHERE id = :id
        ");
        return $stmt->execute([':id' => $id]);
    }

    public static function existsCedula(string $cedula, ?int $excludeId = null): bool
    {
        $db = Database::getConnection();
        $sql = "SELECT id FROM usuarios WHERE cedula = :cedula" . ($excludeId ? " AND id != :excludeId" : "");
        $stmt = $db->prepare($sql);
        $params = [':cedula' => $cedula];
        if ($excludeId) {
            $params[':excludeId'] = $excludeId;
        }
        $stmt->execute($params);
        return (bool)$stmt->fetch();
    }

    public static function existsEmail(string $email, ?int $excludeId = null): bool
    {
        $db = Database::getConnection();
        $sql = "SELECT id FROM usuarios WHERE email = :email" . ($excludeId ? " AND id != :excludeId" : "");
        $stmt = $db->prepare($sql);
        $params = [':email' => $email];
        if ($excludeId) {
            $params[':excludeId'] = $excludeId;
        }
        $stmt->execute($params);
        return (bool)$stmt->fetch();
    }

    public static function existsUsuario(string $usuario, ?int $excludeId = null): bool
    {
        $db = Database::getConnection();
        $sql = "SELECT id FROM usuarios WHERE usuario = :usuario" . ($excludeId ? " AND id != :excludeId" : "");
        $stmt = $db->prepare($sql);
        $params = [':usuario' => $usuario];
        if ($excludeId) {
            $params[':excludeId'] = $excludeId;
        }
        $stmt->execute($params);
        return (bool)$stmt->fetch();
    }
}

