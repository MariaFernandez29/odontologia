<?php

namespace App\Models;

use Config\Database;
use PDO;
use Exception;

class Paciente
{
    public static function all(?string $search = null): array
    {
        $db = Database::getConnection();
        $sql = "
            SELECT p.*,
                   TIMESTAMPDIFF(YEAR, p.fecha_nacimiento, CURDATE()) AS edad,
                   a.alergias, a.enfermedades_sistemicas,
                   (SELECT COUNT(*) FROM consultas c WHERE c.paciente_id = p.id) AS total_consultas,
                   (SELECT MAX(c.fecha) FROM citas c WHERE c.paciente_id = p.id) AS ultima_cita
            FROM pacientes p
            LEFT JOIN antecedentes a ON a.paciente_id = p.id
        ";

        if (!empty($search)) {
            $sql .= " WHERE p.nombres LIKE :q1 OR p.apellidos LIKE :q2 OR p.cedula LIKE :q3 OR p.codigo LIKE :q4";
            $sql .= " ORDER BY p.id DESC";
            $stmt = $db->prepare($sql);
            $param = '%' . trim($search) . '%';
            $stmt->execute([':q1' => $param, ':q2' => $param, ':q3' => $param, ':q4' => $param]);
            return $stmt->fetchAll();
        }

        $sql .= " ORDER BY p.id DESC";
        return $db->query($sql)->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("
            SELECT p.*,
                   TIMESTAMPDIFF(YEAR, p.fecha_nacimiento, CURDATE()) AS edad,
                   a.alergias, a.enfermedades_sistemicas, a.medicamentos_actuales,
                   a.cirugias_previas, a.antecedentes_familiares, a.habitos,
                   a.embarazo, a.meses_embarazo, a.observaciones AS antecedentes_observaciones
            FROM pacientes p
            LEFT JOIN antecedentes a ON a.paciente_id = p.id
            WHERE p.id = :id
            LIMIT 1
        ");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function generateCode(): string
    {
        $db = Database::getConnection();
        $stmt = $db->query("SELECT MAX(id) AS max_id FROM pacientes");
        $row = $stmt->fetch();
        $nextId = ($row && $row['max_id']) ? ((int)$row['max_id'] + 1) : 1;
        do {
            $code = sprintf('HC-%06d', $nextId);
            $check = $db->prepare("SELECT id FROM pacientes WHERE codigo = :c");
            $check->execute([':c' => $code]);
            if (!$check->fetch()) {
                return $code;
            }
            $nextId++;
        } while (true);
    }

    public static function existsCedula(string $cedula, ?int $excludeId = null): bool
    {
        $db = Database::getConnection();
        $sql = "SELECT id FROM pacientes WHERE cedula = :cedula" . ($excludeId ? " AND id != :excludeId" : "");
        $stmt = $db->prepare($sql);
        $params = [':cedula' => $cedula];
        if ($excludeId) {
            $params[':excludeId'] = $excludeId;
        }
        $stmt->execute($params);
        return (bool)$stmt->fetch();
    }

    public static function create(array $pacienteData, array $antecedentesData): int
    {
        $db = Database::getConnection();
        $db->beginTransaction();

        try {
            $codigo = self::generateCode();

            $stmtP = $db->prepare("
                INSERT INTO pacientes (
                    codigo, cedula, nombres, apellidos, fecha_nacimiento, sexo,
                    grupo_sanguineo, telefono, email, direccion, ocupacion,
                    contacto_emergencia, telefono_emergencia, estado
                ) VALUES (
                    :codigo, :cedula, :nombres, :apellidos, :fecha_nacimiento, :sexo,
                    :grupo_sanguineo, :telefono, :email, :direccion, :ocupacion,
                    :contacto_emergencia, :telefono_emergencia, :estado
                )
            ");

            $stmtP->execute([
                ':codigo'              => $codigo,
                ':cedula'              => $pacienteData['cedula'],
                ':nombres'             => $pacienteData['nombres'],
                ':apellidos'           => $pacienteData['apellidos'],
                ':fecha_nacimiento'    => $pacienteData['fecha_nacimiento'],
                ':sexo'                => $pacienteData['sexo'],
                ':grupo_sanguineo'     => $pacienteData['grupo_sanguineo'] ?? null,
                ':telefono'            => $pacienteData['telefono'] ?? null,
                ':email'               => $pacienteData['email'] ?? null,
                ':direccion'           => $pacienteData['direccion'] ?? null,
                ':ocupacion'           => $pacienteData['ocupacion'] ?? null,
                ':contacto_emergencia' => $pacienteData['contacto_emergencia'] ?? null,
                ':telefono_emergencia' => $pacienteData['telefono_emergencia'] ?? null,
                ':estado'              => $pacienteData['estado'] ?? 'activo'
            ]);

            $pacienteId = (int)$db->lastInsertId();

            $stmtA = $db->prepare("
                INSERT INTO antecedentes (
                    paciente_id, alergias, enfermedades_sistemicas, medicamentos_actuales,
                    cirugias_previas, antecedentes_familiares, habitos, embarazo,
                    meses_embarazo, observaciones
                ) VALUES (
                    :paciente_id, :alergias, :enfermedades_sistemicas, :medicamentos_actuales,
                    :cirugias_previas, :antecedentes_familiares, :habitos, :embarazo,
                    :meses_embarazo, :observaciones
                )
            ");

            $stmtA->execute([
                ':paciente_id'             => $pacienteId,
                ':alergias'                => $antecedentesData['alergias'] ?? null,
                ':enfermedades_sistemicas' => $antecedentesData['enfermedades_sistemicas'] ?? null,
                ':medicamentos_actuales'   => $antecedentesData['medicamentos_actuales'] ?? null,
                ':cirugias_previas'        => $antecedentesData['cirugias_previas'] ?? null,
                ':antecedentes_familiares' => $antecedentesData['antecedentes_familiares'] ?? null,
                ':habitos'                 => $antecedentesData['habitos'] ?? null,
                ':embarazo'                => !empty($antecedentesData['embarazo']) ? 1 : 0,
                ':meses_embarazo'          => !empty($antecedentesData['meses_embarazo']) ? (int)$antecedentesData['meses_embarazo'] : 0,
                ':observaciones'           => $antecedentesData['observaciones'] ?? null
            ]);

            $db->commit();
            return $pacienteId;
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }
    }

    public static function update(int $id, array $pacienteData, array $antecedentesData): bool
    {
        $db = Database::getConnection();
        $db->beginTransaction();

        try {
            $stmtP = $db->prepare("
                UPDATE pacientes SET
                    cedula = :cedula,
                    nombres = :nombres,
                    apellidos = :apellidos,
                    fecha_nacimiento = :fecha_nacimiento,
                    sexo = :sexo,
                    grupo_sanguineo = :grupo_sanguineo,
                    telefono = :telefono,
                    email = :email,
                    direccion = :direccion,
                    ocupacion = :ocupacion,
                    contacto_emergencia = :contacto_emergencia,
                    telefono_emergencia = :telefono_emergencia,
                    estado = :estado
                WHERE id = :id
            ");

            $stmtP->execute([
                ':id'                  => $id,
                ':cedula'              => $pacienteData['cedula'],
                ':nombres'             => $pacienteData['nombres'],
                ':apellidos'           => $pacienteData['apellidos'],
                ':fecha_nacimiento'    => $pacienteData['fecha_nacimiento'],
                ':sexo'                => $pacienteData['sexo'],
                ':grupo_sanguineo'     => $pacienteData['grupo_sanguineo'] ?? null,
                ':telefono'            => $pacienteData['telefono'] ?? null,
                ':email'               => $pacienteData['email'] ?? null,
                ':direccion'           => $pacienteData['direccion'] ?? null,
                ':ocupacion'           => $pacienteData['ocupacion'] ?? null,
                ':contacto_emergencia' => $pacienteData['contacto_emergencia'] ?? null,
                ':telefono_emergencia' => $pacienteData['telefono_emergencia'] ?? null,
                ':estado'              => $pacienteData['estado'] ?? 'activo'
            ]);

            $stmtA = $db->prepare("
                INSERT INTO antecedentes (
                    paciente_id, alergias, enfermedades_sistemicas, medicamentos_actuales,
                    cirugias_previas, antecedentes_familiares, habitos, embarazo,
                    meses_embarazo, observaciones
                ) VALUES (
                    :paciente_id, :alergias, :enfermedades_sistemicas, :medicamentos_actuales,
                    :cirugias_previas, :antecedentes_familiares, :habitos, :embarazo,
                    :meses_embarazo, :observaciones
                )
                ON DUPLICATE KEY UPDATE
                    alergias = VALUES(alergias),
                    enfermedades_sistemicas = VALUES(enfermedades_sistemicas),
                    medicamentos_actuales = VALUES(medicamentos_actuales),
                    cirugias_previas = VALUES(cirugias_previas),
                    antecedentes_familiares = VALUES(antecedentes_familiares),
                    habitos = VALUES(habitos),
                    embarazo = VALUES(embarazo),
                    meses_embarazo = VALUES(meses_embarazo),
                    observaciones = VALUES(observaciones)
            ");

            $stmtA->execute([
                ':paciente_id'             => $id,
                ':alergias'                => $antecedentesData['alergias'] ?? null,
                ':enfermedades_sistemicas' => $antecedentesData['enfermedades_sistemicas'] ?? null,
                ':medicamentos_actuales'   => $antecedentesData['medicamentos_actuales'] ?? null,
                ':cirugias_previas'        => $antecedentesData['cirugias_previas'] ?? null,
                ':antecedentes_familiares' => $antecedentesData['antecedentes_familiares'] ?? null,
                ':habitos'                 => $antecedentesData['habitos'] ?? null,
                ':embarazo'                => !empty($antecedentesData['embarazo']) ? 1 : 0,
                ':meses_embarazo'          => !empty($antecedentesData['meses_embarazo']) ? (int)$antecedentesData['meses_embarazo'] : 0,
                ':observaciones'           => $antecedentesData['observaciones'] ?? null
            ]);

            $db->commit();
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }
    }

    public static function search(string $query, int $limit = 15): array
    {
        $db = Database::getConnection();
        $param = '%' . trim($query) . '%';
        $stmt = $db->prepare("
            SELECT id, codigo, cedula, nombres, apellidos, telefono, email
            FROM pacientes
            WHERE estado = 'activo'
              AND (nombres LIKE :q1 OR apellidos LIKE :q2 OR cedula LIKE :q3 OR codigo LIKE :q4)
            ORDER BY nombres ASC, apellidos ASC
            LIMIT " . (int)$limit . "
        ");
        $stmt->execute([':q1' => $param, ':q2' => $param, ':q3' => $param, ':q4' => $param]);
        return $stmt->fetchAll();
    }
}

