<?php

namespace App\Core;

class Response
{
    public static function json(string $status, string $message, mixed $data = [], int $httpCode = 200): void
    {
        http_response_code($httpCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'status'  => $status,
            'message' => $message,
            'data'    => $data
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    public static function success(string $message, mixed $data = [], int $httpCode = 200): void
    {
        self::json('success', $message, $data, $httpCode);
    }

    public static function error(string $message, mixed $data = [], int $httpCode = 400): void
    {
        self::json('error', $message, $data, $httpCode);
    }

    public static function forbidden(string $message = 'Acceso no autorizado'): void
    {
        self::json('error', $message, [], 403);
    }

    public static function notFound(string $message = 'Recurso no encontrado'): void
    {
        self::json('error', $message, [], 404);
    }
}

