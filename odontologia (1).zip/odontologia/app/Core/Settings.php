<?php

namespace App\Core;

use Config\Database;
use PDO;

class Settings
{
    private static ?array $settings = null;

    public static function get(): array
    {
        if (self::$settings === null) {
            $db = Database::getConnection();
            $stmt = $db->query("SELECT * FROM configuracion WHERE id = 1 LIMIT 1");
            $data = $stmt->fetch();
            if (!$data) {
                $data = [
                    'id'             => 1,
                    'nombre_clinica' => 'Clínica Odontológica Especializada',
                    'ruc_nit'        => '',
                    'telefono'       => '',
                    'email'          => '',
                    'direccion'      => '',
                    'logo'           => null,
                    'pie_reporte'    => 'Documento emitido por el Sistema de Gestión Clínica Odontológica.'
                ];
            }
            self::$settings = $data;
        }

        return self::$settings;
    }

    public static function getClinicName(): string
    {
        $s = self::get();
        return $s['nombre_clinica'] ?? 'Clínica Odontológica';
    }

    public static function getLogoUrl(): ?string
    {
        $s = self::get();
        if (!empty($s['logo']) && file_exists(LOGO_PATH . $s['logo'])) {
            return UPLOADS_URL . 'logo/' . $s['logo'];
        }
        return null;
    }

    public static function update(array $data): bool
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("
            UPDATE configuracion SET
                nombre_clinica = :nombre_clinica,
                ruc_nit = :ruc_nit,
                telefono = :telefono,
                email = :email,
                direccion = :direccion,
                logo = :logo,
                pie_reporte = :pie_reporte
            WHERE id = 1
        ");

        $res = $stmt->execute([
            ':nombre_clinica' => $data['nombre_clinica'],
            ':ruc_nit'        => $data['ruc_nit'],
            ':telefono'       => $data['telefono'],
            ':email'          => $data['email'],
            ':direccion'      => $data['direccion'],
            ':logo'           => $data['logo'] ?? null,
            ':pie_reporte'    => $data['pie_reporte']
        ]);

        self::$settings = null;
        return $res;
    }
}

