<?php

namespace App\Core;

use Config\Database;
use PDO;

class Auth
{
    private const SESSION_USER_KEY = 'auth_user';

    public static function check(): bool
    {
        return Session::has(self::SESSION_USER_KEY);
    }

    public static function user(): ?array
    {
        return Session::get(self::SESSION_USER_KEY);
    }

    public static function id(): ?int
    {
        $user = self::user();
        return $user ? (int)$user['id'] : null;
    }

    public static function roleId(): ?int
    {
        $user = self::user();
        return $user ? (int)$user['rol_id'] : null;
    }

    public static function role(): string
    {
        $user = self::user();
        return $user['rol_nombre'] ?? '';
    }

    public static function name(): string
    {
        $user = self::user();
        if (!$user) {
            return '';
        }
        return trim($user['nombres'] . ' ' . $user['apellidos']);
    }

    public static function isAdmin(): bool
    {
        return self::roleId() === 1;
    }

    public static function isDoctor(): bool
    {
        return self::roleId() === 2;
    }

    public static function isAsistente(): bool
    {
        return self::roleId() === 3;
    }

    public static function canAccess(array $allowedRoles): bool
    {
        if (!self::check()) {
            return false;
        }
        $roleName = strtolower(self::role());
        $allowed = array_map('strtolower', $allowedRoles);
        return in_array($roleName, $allowed, true);
    }

    public static function requireLogin(): void
    {
        if (!self::check()) {
            header('Location: ' . BASE_URL . 'login.php');
            exit;
        }
    }

    public static function requireRole(array $allowedRoles): void
    {
        self::requireLogin();
        if (!self::canAccess($allowedRoles)) {
            header('Location: ' . BASE_URL . 'views/dashboard/index.php?error=unauthorized');
            exit;
        }
    }

    public static function login(string $username, string $password): array
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("
            SELECT u.*, r.nombre AS rol_nombre 
            FROM usuarios u
            INNER JOIN roles r ON u.rol_id = r.id
            WHERE (u.usuario = :user_str OR u.email = :email_str)
            LIMIT 1
        ");
        $stmt->execute([
            ':user_str'  => $username,
            ':email_str' => $username
        ]);
        $user = $stmt->fetch();

        if (!$user) {
            return ['success' => false, 'message' => 'Credenciales incorrectas. Verifique e intente nuevamente.'];
        }

        if ($user['estado'] !== 'activo') {
            return ['success' => false, 'message' => 'Su cuenta se encuentra desactivada. Contacte al administrador.'];
        }

        if (!password_verify($password, $user['password_hash'])) {
            return ['success' => false, 'message' => 'Credenciales incorrectas. Verifique e intente nuevamente.'];
        }

        // Regenerar sesión
        Session::regenerate();

        // Actualizar último acceso
        $upd = $db->prepare("UPDATE usuarios SET ultimo_acceso = NOW() WHERE id = :id");
        $upd->execute([':id' => $user['id']]);

        // Guardar datos en sesión (omitiendo hash)
        unset($user['password_hash']);
        Session::set(self::SESSION_USER_KEY, $user);

        return [
            'success' => true,
            'message' => 'Inicio de sesión exitoso.',
            'user'    => $user
        ];
    }

    public static function logout(): void
    {
        Session::destroy();
    }

    public static function updateSessionUser(array $freshData): void
    {
        $currentUser = self::user() ?? [];
        unset($freshData['password_hash']);
        $merged = array_merge($currentUser, $freshData);
        Session::set(self::SESSION_USER_KEY, $merged);
    }
}

