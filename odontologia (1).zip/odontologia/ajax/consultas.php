<?php

require_once __DIR__ . '/../config/config.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Response;
use App\Models\Consulta;
use App\Models\Paciente;

if (!Auth::check()) {
    Response::forbidden();
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'create') {
    if (!Auth::isDoctor() && !Auth::isAdmin()) {
        Response::forbidden('Solo los odontólogos / doctores están autorizados a registrar consultas e historias clínicas.');
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        Response::error('Método no permitido', [], 405);
    }

    if (!Csrf::validate($_POST['csrf_token'] ?? '')) {
        Response::error('Token de seguridad inválido. Recargue la página.');
    }

    $pacienteId = (int)($_POST['paciente_id'] ?? 0);
    $motivoConsulta = trim($_POST['motivo_consulta'] ?? '');

    if (empty($pacienteId) || empty($motivoConsulta)) {
        Response::error('El paciente y el motivo de consulta son campos obligatorios.');
    }

    $paciente = Paciente::find($pacienteId);
    if (!$paciente) {
        Response::notFound('Paciente no encontrado');
    }

    $consultaData = [
        'cita_id'                  => !empty($_POST['cita_id']) ? (int)$_POST['cita_id'] : null,
        'paciente_id'              => $pacienteId,
        'doctor_id'                => Auth::id(),
        'motivo_consulta'          => $motivoConsulta,
        'enfermedad_actual'        => trim($_POST['enfermedad_actual'] ?? ''),
        'examen_estomatologico'    => trim($_POST['examen_estomatologico'] ?? ''),
        'indicaciones_tratamiento' => trim($_POST['indicaciones_tratamiento'] ?? ''),
        'proxima_cita_sugerida'    => !empty($_POST['proxima_cita_sugerida']) ? trim($_POST['proxima_cita_sugerida']) : null
    ];

    $signosData = [
        'presion_sistolica'       => $_POST['presion_sistolica'] ?? null,
        'presion_diastolica'      => $_POST['presion_diastolica'] ?? null,
        'frecuencia_cardiaca'     => $_POST['frecuencia_cardiaca'] ?? null,
        'frecuencia_respiratoria' => $_POST['frecuencia_respiratoria'] ?? null,
        'temperatura'             => $_POST['temperatura'] ?? null,
        'saturacion_oxigeno'      => $_POST['saturacion_oxigeno'] ?? null,
        'peso'                    => $_POST['peso'] ?? null,
        'talla'                   => $_POST['talla'] ?? null,
        'observaciones'           => trim($_POST['signos_observaciones'] ?? '')
    ];

    // Diagnósticos (array decodificado de JSON o enviado en formato array)
    $diagnosticos = [];
    if (!empty($_POST['diagnosticos'])) {
        $diagRaw = is_string($_POST['diagnosticos']) ? json_decode($_POST['diagnosticos'], true) : $_POST['diagnosticos'];
        if (is_array($diagRaw)) {
            $diagnosticos = $diagRaw;
        }
    }

    // Procedimientos realizados (array decodificado de JSON o enviado en formato array)
    $procedimientos = [];
    if (!empty($_POST['procedimientos'])) {
        $procRaw = is_string($_POST['procedimientos']) ? json_decode($_POST['procedimientos'], true) : $_POST['procedimientos'];
        if (is_array($procRaw)) {
            $procedimientos = $procRaw;
        }
    }

    try {
        $consultaId = Consulta::create($consultaData, $signosData, $diagnosticos, $procedimientos);
        Response::success('Atención clínica registrada exitosamente.', [
            'consulta_id' => $consultaId,
            'paciente_id' => $pacienteId
        ]);
    } catch (\Throwable $e) {
        Response::error('Error al guardar la consulta clínica: ' . $e->getMessage());
    }
} elseif ($action === 'get') {
    $id = (int)($_GET['id'] ?? 0);
    $consulta = Consulta::find($id);
    if (!$consulta) {
        Response::notFound('Consulta clínica no encontrada');
    }
    Response::success('Detalle de consulta', $consulta);
} elseif ($action === 'by_paciente') {
    $pacienteId = (int)($_GET['paciente_id'] ?? 0);
    $consultas = Consulta::getByPaciente($pacienteId);
    Response::success('Consultas del paciente', $consultas);
} else {
    Response::error('Acción no reconocida');
}

