<?php

require_once __DIR__ . '/../config/config.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Response;
use App\Models\Paciente;

if (!Auth::check()) {
    Response::forbidden();
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'list') {
    $search = $_GET['search'] ?? null;
    $pacientes = Paciente::all($search);
    Response::success('Lista de pacientes', $pacientes);
} elseif ($action === 'search') {
    $q = trim($_GET['q'] ?? '');
    if (strlen($q) < 2) {
        Response::success('Búsqueda', []);
    }
    $results = Paciente::search($q);
    Response::success('Resultados de búsqueda', $results);
} elseif ($action === 'get') {
    $id = (int)($_GET['id'] ?? 0);
    $paciente = Paciente::find($id);
    if (!$paciente) {
        Response::notFound('Paciente no encontrado');
    }
    Response::success('Paciente encontrado', $paciente);
} elseif ($action === 'create') {
    if (!Auth::check()) {
        Response::forbidden();
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        Response::error('Método no permitido', [], 405);
    }
    if (!Csrf::validate($_POST['csrf_token'] ?? '')) {
        Response::error('Token de seguridad inválido. Recargue la página.');
    }

    $cedula = trim($_POST['cedula'] ?? '');
    $nombres = trim($_POST['nombres'] ?? '');
    $apellidos = trim($_POST['apellidos'] ?? '');
    $fechaNacimiento = trim($_POST['fecha_nacimiento'] ?? '');
    $sexo = trim($_POST['sexo'] ?? '');

    if (empty($cedula) || empty($nombres) || empty($apellidos) || empty($fechaNacimiento) || empty($sexo)) {
        Response::error('Cédula, nombres, apellidos, fecha de nacimiento y sexo son obligatorios.');
    }

    if (Paciente::existsCedula($cedula)) {
        Response::error('Ya existe un paciente registrado con ese número de cédula o documento de identidad.');
    }

    $pacienteData = [
        'cedula'              => $cedula,
        'nombres'             => $nombres,
        'apellidos'           => $apellidos,
        'fecha_nacimiento'    => $fechaNacimiento,
        'sexo'                => in_array($sexo, ['M', 'F', 'Otro']) ? $sexo : 'M',
        'grupo_sanguineo'     => trim($_POST['grupo_sanguineo'] ?? ''),
        'telefono'            => trim($_POST['telefono'] ?? ''),
        'email'               => trim($_POST['email'] ?? ''),
        'direccion'           => trim($_POST['direccion'] ?? ''),
        'ocupacion'           => trim($_POST['ocupacion'] ?? ''),
        'contacto_emergencia' => trim($_POST['contacto_emergencia'] ?? ''),
        'telefono_emergencia' => trim($_POST['telefono_emergencia'] ?? ''),
        'estado'              => $_POST['estado'] ?? 'activo'
    ];

    $antecedentesData = [
        'alergias'                => trim($_POST['alergias'] ?? ''),
        'enfermedades_sistemicas' => trim($_POST['enfermedades_sistemicas'] ?? ''),
        'medicamentos_actuales'   => trim($_POST['medicamentos_actuales'] ?? ''),
        'cirugias_previas'        => trim($_POST['cirugias_previas'] ?? ''),
        'antecedentes_familiares' => trim($_POST['antecedentes_familiares'] ?? ''),
        'habitos'                 => trim($_POST['habitos'] ?? ''),
        'embarazo'                => !empty($_POST['embarazo']) ? 1 : 0,
        'meses_embarazo'          => (int)($_POST['meses_embarazo'] ?? 0),
        'observaciones'           => trim($_POST['antecedentes_observaciones'] ?? '')
    ];

    try {
        $pacienteId = Paciente::create($pacienteData, $antecedentesData);
        Response::success('Paciente registrado exitosamente en el sistema.', ['id' => $pacienteId]);
    } catch (\Throwable $e) {
        Response::error('Error al registrar el paciente: ' . $e->getMessage());
    }
} elseif ($action === 'update') {
    if (!Auth::check()) {
        Response::forbidden();
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        Response::error('Método no permitido', [], 405);
    }
    if (!Csrf::validate($_POST['csrf_token'] ?? '')) {
        Response::error('Token de seguridad inválido. Recargue la página.');
    }

    $id = (int)($_POST['id'] ?? 0);
    $paciente = Paciente::find($id);
    if (!$paciente) {
        Response::notFound('Paciente no encontrado');
    }

    $cedula = trim($_POST['cedula'] ?? '');
    $nombres = trim($_POST['nombres'] ?? '');
    $apellidos = trim($_POST['apellidos'] ?? '');
    $fechaNacimiento = trim($_POST['fecha_nacimiento'] ?? '');
    $sexo = trim($_POST['sexo'] ?? '');

    if (empty($cedula) || empty($nombres) || empty($apellidos) || empty($fechaNacimiento) || empty($sexo)) {
        Response::error('Cédula, nombres, apellidos, fecha de nacimiento y sexo son obligatorios.');
    }

    if (Paciente::existsCedula($cedula, $id)) {
        Response::error('Ya existe otro paciente con ese número de cédula o documento de identidad.');
    }

    $pacienteData = [
        'cedula'              => $cedula,
        'nombres'             => $nombres,
        'apellidos'           => $apellidos,
        'fecha_nacimiento'    => $fechaNacimiento,
        'sexo'                => in_array($sexo, ['M', 'F', 'Otro']) ? $sexo : 'M',
        'grupo_sanguineo'     => trim($_POST['grupo_sanguineo'] ?? ''),
        'telefono'            => trim($_POST['telefono'] ?? ''),
        'email'               => trim($_POST['email'] ?? ''),
        'direccion'           => trim($_POST['direccion'] ?? ''),
        'ocupacion'           => trim($_POST['ocupacion'] ?? ''),
        'contacto_emergencia' => trim($_POST['contacto_emergencia'] ?? ''),
        'telefono_emergencia' => trim($_POST['telefono_emergencia'] ?? ''),
        'estado'              => $_POST['estado'] ?? 'activo'
    ];

    $antecedentesData = [
        'alergias'                => trim($_POST['alergias'] ?? ''),
        'enfermedades_sistemicas' => trim($_POST['enfermedades_sistemicas'] ?? ''),
        'medicamentos_actuales'   => trim($_POST['medicamentos_actuales'] ?? ''),
        'cirugias_previas'        => trim($_POST['cirugias_previas'] ?? ''),
        'antecedentes_familiares' => trim($_POST['antecedentes_familiares'] ?? ''),
        'habitos'                 => trim($_POST['habitos'] ?? ''),
        'embarazo'                => !empty($_POST['embarazo']) ? 1 : 0,
        'meses_embarazo'          => (int)($_POST['meses_embarazo'] ?? 0),
        'observaciones'           => trim($_POST['antecedentes_observaciones'] ?? '')
    ];

    try {
        Paciente::update($id, $pacienteData, $antecedentesData);
        Response::success('Datos del paciente actualizados exitosamente.');
    } catch (\Throwable $e) {
        Response::error('Error al actualizar el paciente: ' . $e->getMessage());
    }
} else {
    Response::error('Acción no reconocida');
}

