<?php

require_once __DIR__ . '/../config/config.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Response;
use App\Models\Procedimiento;

if (!Auth::check()) {
    Response::forbidden();
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'list') {
    $onlyActive = isset($_GET['active']) && $_GET['active'] === '1';
    $list = Procedimiento::all($onlyActive);
    Response::success('Catálogo de procedimientos', $list);
} elseif ($action === 'get') {
    $id = (int)($_GET['id'] ?? 0);
    $proc = Procedimiento::find($id);
    if (!$proc) {
        Response::notFound('Procedimiento no encontrado');
    }
    Response::success('Procedimiento encontrado', $proc);
} elseif ($action === 'create') {
    if (!Auth::isAdmin() && !Auth::isDoctor()) {
        Response::forbidden('No tiene permisos para crear procedimientos.');
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        Response::error('Método no permitido', [], 405);
    }
    if (!Csrf::validate($_POST['csrf_token'] ?? '')) {
        Response::error('Token de seguridad inválido. Recargue la página.');
    }

    $nombre = trim($_POST['nombre'] ?? '');
    if (empty($nombre)) {
        Response::error('El nombre del procedimiento es obligatorio.');
    }

    $newId = Procedimiento::create([
        'codigo'      => trim($_POST['codigo'] ?? ''),
        'nombre'      => $nombre,
        'categoria'   => trim($_POST['categoria'] ?? 'General'),
        'descripcion' => trim($_POST['descripcion'] ?? ''),
        'estado'      => $_POST['estado'] ?? 'activo'
    ]);

    Response::success('Procedimiento registrado correctamente', ['id' => $newId]);
} elseif ($action === 'update') {
    if (!Auth::isAdmin() && !Auth::isDoctor()) {
        Response::forbidden('No tiene permisos para modificar procedimientos.');
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        Response::error('Método no permitido', [], 405);
    }
    if (!Csrf::validate($_POST['csrf_token'] ?? '')) {
        Response::error('Token de seguridad inválido. Recargue la página.');
    }

    $id = (int)($_POST['id'] ?? 0);
    $proc = Procedimiento::find($id);
    if (!$proc) {
        Response::notFound('Procedimiento no encontrado');
    }

    $nombre = trim($_POST['nombre'] ?? '');
    if (empty($nombre)) {
        Response::error('El nombre del procedimiento es obligatorio.');
    }

    Procedimiento::update($id, [
        'nombre'      => $nombre,
        'categoria'   => trim($_POST['categoria'] ?? 'General'),
        'descripcion' => trim($_POST['descripcion'] ?? ''),
        'estado'      => $_POST['estado'] ?? 'activo'
    ]);

    Response::success('Procedimiento actualizado correctamente');
} elseif ($action === 'toggle') {
    if (!Auth::isAdmin() && !Auth::isDoctor()) {
        Response::forbidden('No tiene permisos para modificar el estado del procedimiento.');
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        Response::error('Método no permitido', [], 405);
    }
    if (!Csrf::validate($_POST['csrf_token'] ?? '')) {
        Response::error('Token de seguridad inválido.');
    }

    $id = (int)($_POST['id'] ?? 0);
    $proc = Procedimiento::find($id);
    if (!$proc) {
        Response::notFound('Procedimiento no encontrado');
    }

    Procedimiento::toggleStatus($id);
    Response::success('Estado del procedimiento actualizado correctamente');
} else {
    Response::error('Acción no reconocida');
}

