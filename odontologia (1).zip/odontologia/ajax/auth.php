<?php

require_once __DIR__ . '/../config/config.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Response;

$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'login') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        Response::error('Método no permitido', [], 405);
    }

    $token = $_POST['csrf_token'] ?? '';
    if (!Csrf::validate($token)) {
        Response::error('Token de seguridad inválido. Recargue la página.');
    }

    $username = trim($_POST['usuario'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        Response::error('Por favor ingrese su usuario y contraseña.');
    }

    $result = Auth::login($username, $password);
    if ($result['success']) {
        Response::success($result['message'], [
            'redirect' => BASE_URL . 'views/dashboard/index.php'
        ]);
    } else {
        Response::error($result['message']);
    }
} elseif ($action === 'logout') {
    Auth::logout();
    Response::success('Sesión finalizada correctamente', [
        'redirect' => BASE_URL . 'login.php'
    ]);
} else {
    Response::error('Acción no reconocida');
}

