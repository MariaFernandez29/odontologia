<?php

require_once __DIR__ . '/../config/config.php';

use App\Core\Auth;
use App\Core\Response;
use App\Models\Dashboard;
use App\Models\Cita;

if (!Auth::check()) {
    Response::forbidden();
}

$action = $_GET['action'] ?? $_POST['action'] ?? 'stats';

if ($action === 'stats') {
    $doctorId = (Auth::isDoctor() && !Auth::isAdmin()) ? Auth::id() : null;
    $stats = Dashboard::getStats($doctorId);
    Response::success('Estadísticas del panel', $stats);
} elseif ($action === 'charts') {
    $topProcedures = Dashboard::getTopProcedures(6);
    $monthlyConsultations = Dashboard::getMonthlyConsultations();

    Response::success('Datos para gráficos', [
        'top_procedures'        => $topProcedures,
        'monthly_consultations' => $monthlyConsultations
    ]);
} elseif ($action === 'today_appointments') {
    $doctorId = (Auth::isDoctor() && !Auth::isAdmin()) ? Auth::id() : null;
    $appointments = Cita::getTodayAppointments($doctorId);
    Response::success('Citas de hoy', $appointments);
} else {
    Response::error('Acción no reconocida');
}

