<?php

require_once __DIR__ . '/../config/config.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Response;
use App\Models\Usuario;

if (!Auth::check()) {
    Response::forbidden();
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'update') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        Response::error('Método no permitido', [], 405);
    }
    if (!Csrf::validate($_POST['csrf_token'] ?? '')) {
        Response::error('Token de seguridad inválido. Recargue la página.');
    }

    $id = Auth::id();
    $nombres = trim($_POST['nombres'] ?? '');
    $apellidos = trim($_POST['apellidos'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($nombres) || empty($apellidos) || empty($email)) {
        Response::error('Nombres, apellidos y correo electrónico son obligatorios.');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        Response::error('El formato del correo electrónico no es válido.');
    }

    if (Usuario::existsEmail($email, $id)) {
        Response::error('Ese correo electrónico ya se encuentra registrado por otro usuario.');
    }

    if (!empty($password) && strlen($password) < 6) {
        Response::error('La nueva contraseña debe tener al menos 6 caracteres.');
    }

    $data = [
        'nombres'   => $nombres,
        'apellidos' => $apellidos,
        'email'     => $email,
        'telefono'  => trim($_POST['telefono'] ?? ''),
        'password'  => $password
    ];

    if (Usuario::updateProfile($id, $data)) {
        // Actualizar datos de la sesión
        Auth::updateSessionUser([
            'nombres'   => $nombres,
            'apellidos' => $apellidos,
            'email'     => $email,
            'telefono'  => $data['telefono']
        ]);

        Response::success('Perfil actualizado correctamente.');
    } else {
        Response::error('No fue posible actualizar su perfil.');
    }
} else {
    Response::error('Acción no reconocida');
}

