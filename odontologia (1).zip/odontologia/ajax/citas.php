<?php

require_once __DIR__ . '/../config/config.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Response;
use App\Models\Cita;

if (!Auth::check()) {
    Response::forbidden();
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'list') {
    $filters = [];

    // Si es doctor, solo ve sus citas por defecto (a menos que sea admin)
    if (Auth::isDoctor() && !Auth::isAdmin()) {
        $filters['doctor_id'] = Auth::id();
    } elseif (!empty($_GET['doctor_id'])) {
        $filters['doctor_id'] = (int)$_GET['doctor_id'];
    }

    if (!empty($_GET['paciente_id'])) {
        $filters['paciente_id'] = (int)$_GET['paciente_id'];
    }
    if (!empty($_GET['fecha'])) {
        $filters['fecha'] = $_GET['fecha'];
    }
    if (!empty($_GET['fecha_desde'])) {
        $filters['fecha_desde'] = $_GET['fecha_desde'];
    }
    if (!empty($_GET['fecha_hasta'])) {
        $filters['fecha_hasta'] = $_GET['fecha_hasta'];
    }
    if (!empty($_GET['estado'])) {
        $filters['estado'] = $_GET['estado'];
    }

    $citas = Cita::all($filters);
    Response::success('Lista de citas', $citas);
} elseif ($action === 'get') {
    $id = (int)($_GET['id'] ?? 0);
    $cita = Cita::find($id);
    if (!$cita) {
        Response::notFound('Cita no encontrada');
    }
    Response::success('Cita encontrada', $cita);
} elseif ($action === 'create') {
    if (!Auth::check()) {
        Response::forbidden();
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        Response::error('Método no permitido', [], 405);
    }
    if (!Csrf::validate($_POST['csrf_token'] ?? '')) {
        Response::error('Token de seguridad inválido. Recargue la página.');
    }

    $pacienteId = (int)($_POST['paciente_id'] ?? 0);
    $doctorId = (int)($_POST['doctor_id'] ?? 0);
    $fecha = trim($_POST['fecha'] ?? '');
    $hora = trim($_POST['hora'] ?? '');
    $motivo = trim($_POST['motivo'] ?? '');

    if (empty($pacienteId) || empty($doctorId) || empty($fecha) || empty($hora) || empty($motivo)) {
        Response::error('Paciente, doctor, fecha, hora y motivo son campos obligatorios.');
    }

    if (Cita::hasConflict($doctorId, $fecha, $hora)) {
        Response::error('El doctor ya tiene una cita agendada en esa misma fecha y hora. Seleccione otro horario.');
    }

    $newId = Cita::create([
        'paciente_id'    => $pacienteId,
        'doctor_id'      => $doctorId,
        'registrado_por' => Auth::id(),
        'fecha'          => $fecha,
        'hora'           => $hora,
        'motivo'         => $motivo,
        'estado'         => 'pendiente',
        'observaciones'  => trim($_POST['observaciones'] ?? '')
    ]);

    Response::success('Cita agendada exitosamente.', ['id' => $newId]);
} elseif ($action === 'update') {
    if (!Auth::check()) {
        Response::forbidden();
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        Response::error('Método no permitido', [], 405);
    }
    if (!Csrf::validate($_POST['csrf_token'] ?? '')) {
        Response::error('Token de seguridad inválido. Recargue la página.');
    }

    $id = (int)($_POST['id'] ?? 0);
    $cita = Cita::find($id);
    if (!$cita) {
        Response::notFound('Cita no encontrada');
    }

    $pacienteId = (int)($_POST['paciente_id'] ?? 0);
    $doctorId = (int)($_POST['doctor_id'] ?? 0);
    $fecha = trim($_POST['fecha'] ?? '');
    $hora = trim($_POST['hora'] ?? '');
    $motivo = trim($_POST['motivo'] ?? '');
    $estado = trim($_POST['estado'] ?? 'pendiente');

    if (empty($pacienteId) || empty($doctorId) || empty($fecha) || empty($hora) || empty($motivo)) {
        Response::error('Paciente, doctor, fecha, hora y motivo son campos obligatorios.');
    }

    if (Cita::hasConflict($doctorId, $fecha, $hora, $id)) {
        Response::error('El doctor ya tiene una cita programada en esa fecha y horario. Elija otro bloque horario.');
    }

    Cita::update($id, [
        'paciente_id'   => $pacienteId,
        'doctor_id'     => $doctorId,
        'fecha'         => $fecha,
        'hora'          => $hora,
        'motivo'        => $motivo,
        'estado'        => in_array($estado, ['pendiente', 'en_atencion', 'atendida', 'cancelada', 'no_asistio']) ? $estado : 'pendiente',
        'observaciones' => trim($_POST['observaciones'] ?? '')
    ]);

    Response::success('Cita actualizada exitosamente.');
} elseif ($action === 'update_status') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        Response::error('Método no permitido', [], 405);
    }
    if (!Csrf::validate($_POST['csrf_token'] ?? '')) {
        Response::error('Token de seguridad inválido.');
    }

    $id = (int)($_POST['id'] ?? 0);
    $status = trim($_POST['status'] ?? '');
    $cita = Cita::find($id);
    if (!$cita) {
        Response::notFound('Cita no encontrada');
    }

    if (!in_array($status, ['pendiente', 'en_atencion', 'atendida', 'cancelada', 'no_asistio'])) {
        Response::error('Estado no válido.');
    }

    // Si es doctor, solo puede cambiar estado de sus propias citas
    if (Auth::isDoctor() && !Auth::isAdmin() && (int)$cita['doctor_id'] !== Auth::id()) {
        Response::forbidden('Solo puede actualizar el estado de sus citas asignadas.');
    }

    Cita::updateStatus($id, $status);
    Response::success('Estado de la cita actualizado a: ' . ucfirst(str_replace('_', ' ', $status)));
} else {
    Response::error('Acción no reconocida');
}

