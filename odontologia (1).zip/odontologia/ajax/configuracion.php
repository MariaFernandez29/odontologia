<?php

require_once __DIR__ . '/../config/config.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Response;
use App\Core\Settings;

if (!Auth::check()) {
    Response::forbidden();
}

if (!Auth::isAdmin()) {
    Response::forbidden('Solo los administradores pueden modificar la configuración');
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'get') {
    $settings = Settings::get();
    $settings['logo_url'] = Settings::getLogoUrl();
    Response::success('Configuración obtenida', $settings);
} elseif ($action === 'update') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        Response::error('Método no permitido', [], 405);
    }

    if (!Csrf::validate($_POST['csrf_token'] ?? '')) {
        Response::error('Token de seguridad inválido. Recargue la página.');
    }

    $nombreClinica = trim($_POST['nombre_clinica'] ?? '');
    if (empty($nombreClinica)) {
        Response::error('El nombre de la clínica es obligatorio.');
    }

    $currentSettings = Settings::get();
    $logoName = $currentSettings['logo'] ?? null;

    // Procesar carga de logo
    if (isset($_FILES['logo_file']) && $_FILES['logo_file']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['logo_file'];
        $allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'];
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        if (!in_array($mimeType, $allowedTypes)) {
            Response::error('El formato de imagen debe ser PNG, JPG, WEBP o SVG.');
        }

        if ($file['size'] > 2 * 1024 * 1024) {
            Response::error('La imagen no debe superar los 2MB.');
        }

        if (!is_dir(LOGO_PATH)) {
            mkdir(LOGO_PATH, 0755, true);
        }

        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $newLogoName = 'logo_' . time() . '.' . strtolower($ext);
        $destPath = LOGO_PATH . $newLogoName;

        if (move_uploaded_file($file['tmp_name'], $destPath)) {
            // Eliminar logo anterior si existe
            if (!empty($logoName) && file_exists(LOGO_PATH . $logoName)) {
                @unlink(LOGO_PATH . $logoName);
            }
            $logoName = $newLogoName;
        } else {
            Response::error('No se pudo guardar la imagen del logo.');
        }
    }

    $data = [
        'nombre_clinica' => $nombreClinica,
        'ruc_nit'        => trim($_POST['ruc_nit'] ?? ''),
        'telefono'       => trim($_POST['telefono'] ?? ''),
        'email'          => trim($_POST['email'] ?? ''),
        'direccion'      => trim($_POST['direccion'] ?? ''),
        'logo'           => $logoName,
        'pie_reporte'    => trim($_POST['pie_reporte'] ?? '')
    ];

    if (Settings::update($data)) {
        Response::success('Configuración de la clínica actualizada correctamente.', [
            'nombre_clinica' => $data['nombre_clinica'],
            'logo_url'       => Settings::getLogoUrl()
        ]);
    } else {
        Response::error('No fue posible actualizar la configuración.');
    }
} else {
    Response::error('Acción no reconocida');
}

