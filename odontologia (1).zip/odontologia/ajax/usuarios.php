<?php

require_once __DIR__ . '/../config/config.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Response;
use App\Models\Usuario;

if (!Auth::check()) {
    Response::forbidden();
}

if (!Auth::isAdmin()) {
    Response::forbidden('Acceso denegado a la administración de usuarios.');
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'list') {
    $usuarios = Usuario::all();
    Response::success('Lista de usuarios', $usuarios);
} elseif ($action === 'get') {
    $id = (int)($_GET['id'] ?? 0);
    $usuario = Usuario::find($id);
    if (!$usuario) {
        Response::notFound('Usuario no encontrado');
    }
    unset($usuario['password_hash']);
    Response::success('Usuario encontrado', $usuario);
} elseif ($action === 'create') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        Response::error('Método no permitido', [], 405);
    }
    if (!Csrf::validate($_POST['csrf_token'] ?? '')) {
        Response::error('Token de seguridad inválido. Recargue la página.');
    }

    $rolId = (int)($_POST['rol_id'] ?? 0);
    $nombres = trim($_POST['nombres'] ?? '');
    $apellidos = trim($_POST['apellidos'] ?? '');
    $cedula = trim($_POST['cedula'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $usuarioStr = trim($_POST['usuario'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($rolId) || empty($nombres) || empty($apellidos) || empty($cedula) || empty($email) || empty($usuarioStr) || empty($password)) {
        Response::error('Todos los campos marcados como obligatorios deben ser completados.');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        Response::error('El formato de correo electrónico no es válido.');
    }

    if (strlen($password) < 6) {
        Response::error('La contraseña debe contener al menos 6 caracteres.');
    }

    if (Usuario::existsCedula($cedula)) {
        Response::error('Ya existe un usuario registrado con esa cédula.');
    }

    if (Usuario::existsEmail($email)) {
        Response::error('El correo electrónico ya se encuentra registrado por otro usuario.');
    }

    if (Usuario::existsUsuario($usuarioStr)) {
        Response::error('El nombre de usuario ya está en uso. Elija otro.');
    }

    $newId = Usuario::create([
        'rol_id'       => $rolId,
        'nombres'      => $nombres,
        'apellidos'    => $apellidos,
        'cedula'       => $cedula,
        'email'        => $email,
        'telefono'     => trim($_POST['telefono'] ?? ''),
        'especialidad' => trim($_POST['especialidad'] ?? ''),
        'colegiatura'  => trim($_POST['colegiatura'] ?? ''),
        'usuario'      => $usuarioStr,
        'password'     => $password,
        'estado'       => $_POST['estado'] ?? 'activo'
    ]);

    Response::success('Usuario creado exitosamente', ['id' => $newId]);
} elseif ($action === 'update') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        Response::error('Método no permitido', [], 405);
    }
    if (!Csrf::validate($_POST['csrf_token'] ?? '')) {
        Response::error('Token de seguridad inválido. Recargue la página.');
    }

    $id = (int)($_POST['id'] ?? 0);
    $user = Usuario::find($id);
    if (!$user) {
        Response::notFound('Usuario no encontrado');
    }

    $rolId = (int)($_POST['rol_id'] ?? 0);
    $nombres = trim($_POST['nombres'] ?? '');
    $apellidos = trim($_POST['apellidos'] ?? '');
    $cedula = trim($_POST['cedula'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $usuarioStr = trim($_POST['usuario'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($rolId) || empty($nombres) || empty($apellidos) || empty($cedula) || empty($email) || empty($usuarioStr)) {
        Response::error('Todos los campos marcados como obligatorios deben ser completados.');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        Response::error('El formato de correo electrónico no es válido.');
    }

    if (!empty($password) && strlen($password) < 6) {
        Response::error('La contraseña debe contener al menos 6 caracteres.');
    }

    if (Usuario::existsCedula($cedula, $id)) {
        Response::error('Ya existe otro usuario registrado con esa cédula.');
    }

    if (Usuario::existsEmail($email, $id)) {
        Response::error('El correo electrónico ya se encuentra registrado por otro usuario.');
    }

    if (Usuario::existsUsuario($usuarioStr, $id)) {
        Response::error('El nombre de usuario ya está en uso. Elija otro.');
    }

    Usuario::update($id, [
        'rol_id'       => $rolId,
        'nombres'      => $nombres,
        'apellidos'    => $apellidos,
        'cedula'       => $cedula,
        'email'        => $email,
        'telefono'     => trim($_POST['telefono'] ?? ''),
        'especialidad' => trim($_POST['especialidad'] ?? ''),
        'colegiatura'  => trim($_POST['colegiatura'] ?? ''),
        'usuario'      => $usuarioStr,
        'password'     => $password,
        'estado'       => $_POST['estado'] ?? 'activo'
    ]);

    Response::success('Usuario actualizado exitosamente');
} elseif ($action === 'toggle') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        Response::error('Método no permitido', [], 405);
    }
    if (!Csrf::validate($_POST['csrf_token'] ?? '')) {
        Response::error('Token de seguridad inválido.');
    }

    $id = (int)($_POST['id'] ?? 0);
    if ($id === Auth::id()) {
        Response::error('No puede desactivar su propia cuenta de usuario en uso.');
    }

    $user = Usuario::find($id);
    if (!$user) {
        Response::notFound('Usuario no encontrado');
    }

    Usuario::toggleStatus($id);
    Response::success('Estado del usuario actualizado correctamente');
} else {
    Response::error('Acción no reconocida');
}

