<?php

require_once __DIR__ . '/config/config.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Settings;

if (Auth::check()) {
    header('Location: ' . BASE_URL . 'views/dashboard/index.php');
    exit;
}

$clinicSettings = Settings::get();
$clinicName = $clinicSettings['nombre_clinica'] ?? 'Clínica Odontológica Especializada';
$clinicLogo = Settings::getLogoUrl();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceso al Sistema | <?= htmlspecialchars($clinicName) ?></title>
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #0b5ed7 0%, #0d6efd 50%, #0aa2c0 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1.5rem;
            font-family: system-ui, -apple-system, sans-serif;
        }
        .login-card {
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2), 0 10px 10px -5px rgba(0, 0, 0, 0.1);
            max-width: 440px;
            width: 100%;
            overflow: hidden;
            border: none;
        }
        .login-header {
            background-color: #f8fafc;
            border-bottom: 1px solid #e2e8f0;
            padding: 2rem 1.5rem 1.5rem;
            text-align: center;
        }
        .login-logo {
            max-height: 60px;
            max-width: 160px;
            object-fit: contain;
            margin-bottom: 0.75rem;
        }
        .logo-placeholder {
            width: 64px;
            height: 64px;
            border-radius: 12px;
            background: #0d6efd;
            color: #ffffff;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            margin-bottom: 0.75rem;
        }
        .login-body {
            padding: 2rem 1.75rem;
        }
        .form-floating:focus-within {
            z-index: 2;
        }
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
            padding: 0.75rem;
            font-weight: 600;
            border-radius: 8px;
        }
        .btn-primary:hover {
            background-color: #0b5ed7;
            border-color: #0a58ca;
        }
        .demo-box {
            background-color: #f1f5f9;
            border-radius: 8px;
            padding: 0.75rem 1rem;
            font-size: 0.8rem;
            margin-top: 1.25rem;
        }
        .demo-pill {
            cursor: pointer;
            padding: 3px 8px;
            border-radius: 4px;
            background: #e2e8f0;
            display: inline-block;
            margin: 2px;
            transition: all 0.15s;
        }
        .demo-pill:hover {
            background: #0d6efd;
            color: #fff;
        }
    </style>
</head>
<body>

    <div class="login-card">
        <div class="login-header">
            <?php if ($clinicLogo): ?>
                <img src="<?= $clinicLogo ?>" alt="Logo" class="login-logo">
            <?php else: ?>
                <div class="logo-placeholder">
                    <i class="bi bi-hospital"></i>
                </div>
            <?php endif; ?>
            <h4 class="fw-bold mb-1 text-dark"><?= htmlspecialchars($clinicName) ?></h4>
            <p class="text-muted small mb-0">Sistema de Historias Clínicas Odontológicas</p>
        </div>

        <div class="login-body">
            <form id="formLogin" novalidate>
                <?= Csrf::field() ?>

                <div class="mb-3">
                    <label for="usuario" class="form-label fw-semibold small">Usuario o Correo Electrónico</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0"><i class="bi bi-person text-muted"></i></span>
                        <input type="text" class="form-control border-start-0" id="usuario" name="usuario" placeholder="Ingrese su usuario o correo" required autofocus>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label fw-semibold small">Contraseña</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0"><i class="bi bi-lock text-muted"></i></span>
                        <input type="password" class="form-control border-start-0 border-end-0" id="password" name="password" placeholder="••••••••" required>
                        <button class="btn btn-outline-secondary border-start-0" type="button" id="togglePassword">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                </div>

                <div class="d-grid mt-4">
                    <button type="submit" class="btn btn-primary d-flex align-items-center justify-content-center" id="btnLogin">
                        <span class="spinner-border spinner-border-sm me-2 d-none" id="loginSpinner" role="status" aria-hidden="true"></span>
                        <span id="loginText">Iniciar Sesión</span>
                    </button>
                </div>

                <!-- Credenciales Rápidas para Demostración -->
                <div class="demo-box text-center">
                    <div class="text-muted fw-semibold mb-1">Cuentas disponibles:</div>
                    <span class="demo-pill" data-user="admin" data-pass="admin123">
                        <i class="bi bi-shield-check me-1"></i>Admin
                    </span>
                    <span class="demo-pill" data-user="doctor" data-pass="doctor123">
                        <i class="bi bi-person-badge me-1"></i>Doctor
                    </span>
                    <span class="demo-pill" data-user="asistente" data-pass="asistente123">
                        <i class="bi bi-person me-1"></i>Asistente
                    </span>
                </div>
            </form>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.all.min.js"></script>

    <script>
        const BASE_URL = '<?= BASE_URL ?>';

        // Toggle visibilidad de contraseña
        $('#togglePassword').on('click', function() {
            const input = $('#password');
            const icon = $(this).find('i');
            if (input.attr('type') === 'password') {
                input.attr('type', 'text');
                icon.removeClass('bi-eye').addClass('bi-eye-slash');
            } else {
                input.attr('type', 'password');
                icon.removeClass('bi-eye-slash').addClass('bi-eye');
            }
        });

        // Click en pills de demostración para auto-llenar
        $('.demo-pill').on('click', function() {
            $('#usuario').val($(this).data('user'));
            $('#password').val($(this).data('pass'));
        });

        // Envío AJAX del formulario de Login
        $('#formLogin').on('submit', function(e) {
            e.preventDefault();

            const usuario = $('#usuario').val().trim();
            const password = $('#password').val().trim();

            if (!usuario || !password) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Campos requeridos',
                    text: 'Por favor complete su usuario y contraseña.',
                    confirmButtonColor: '#0d6efd'
                });
                return;
            }

            const btn = $('#btnLogin');
            const spinner = $('#loginSpinner');
            const text = $('#loginText');

            btn.prop('disabled', true);
            spinner.removeClass('d-none');
            text.text('Verificando...');

            $.ajax({
                url: BASE_URL + 'ajax/auth.php?action=login',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: '¡Bienvenido!',
                            text: response.message,
                            timer: 1200,
                            showConfirmButton: false
                        }).then(() => {
                            window.location.href = response.data.redirect || BASE_URL + 'views/dashboard/index.php';
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error de Acceso',
                            text: response.message,
                            confirmButtonColor: '#0d6efd'
                        });
                        btn.prop('disabled', false);
                        spinner.addClass('d-none');
                        text.text('Iniciar Sesión');
                    }
                },
                error: function(xhr) {
                    let errMsg = 'Ocurrió un error en el servidor. Intente nuevamente.';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        errMsg = xhr.responseJSON.message;
                    }
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: errMsg,
                        confirmButtonColor: '#0d6efd'
                    });
                    btn.prop('disabled', false);
                    spinner.addClass('d-none');
                    text.text('Iniciar Sesión');
                }
            });
        });
    </script>
</body>
</html>

