-- Base de datos: odontologia_db
CREATE DATABASE IF NOT EXISTS `odontologia_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `odontologia_db`;

SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `consulta_procedimientos`;
DROP TABLE IF EXISTS `diagnosticos`;
DROP TABLE IF EXISTS `signos_vitales`;
DROP TABLE IF EXISTS `consultas`;
DROP TABLE IF EXISTS `citas`;
DROP TABLE IF EXISTS `antecedentes`;
DROP TABLE IF EXISTS `pacientes`;
DROP TABLE IF EXISTS `procedimientos`;
DROP TABLE IF EXISTS `usuarios`;
DROP TABLE IF EXISTS `roles`;
DROP TABLE IF EXISTS `configuracion`;
SET FOREIGN_KEY_CHECKS = 1;

-- Tabla de configuración de la clínica
CREATE TABLE IF NOT EXISTS `configuracion` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nombre_clinica` VARCHAR(150) NOT NULL DEFAULT 'Clínica Odontológica Especializada',
    `ruc_nit` VARCHAR(50) DEFAULT 'J-12345678-9',
    `telefono` VARCHAR(50) DEFAULT '+58 212 555-0199',
    `email` VARCHAR(100) DEFAULT 'contacto@clinicaodontologica.com',
    `direccion` TEXT DEFAULT 'Av. Principal, Edificio Médico Salud, Piso 2, Consultorio 204',
    `logo` VARCHAR(255) DEFAULT NULL,
    `pie_reporte` TEXT DEFAULT 'Documento emitido por el Sistema de Gestión Clínica Odontológica. Válido como historia médica confidencial.',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de roles
CREATE TABLE IF NOT EXISTS `roles` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nombre` VARCHAR(50) NOT NULL UNIQUE,
    `descripcion` VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `rol_id` INT NOT NULL,
    `nombres` VARCHAR(100) NOT NULL,
    `apellidos` VARCHAR(100) NOT NULL,
    `cedula` VARCHAR(30) NOT NULL UNIQUE,
    `email` VARCHAR(100) NOT NULL UNIQUE,
    `telefono` VARCHAR(30) DEFAULT NULL,
    `especialidad` VARCHAR(100) DEFAULT NULL,
    `colegiatura` VARCHAR(50) DEFAULT NULL,
    `usuario` VARCHAR(50) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `estado` ENUM('activo', 'inactivo') DEFAULT 'activo',
    `ultimo_acceso` DATETIME DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_usuarios_roles` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de pacientes
CREATE TABLE IF NOT EXISTS `pacientes` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `codigo` VARCHAR(30) NOT NULL UNIQUE,
    `cedula` VARCHAR(30) NOT NULL UNIQUE,
    `nombres` VARCHAR(100) NOT NULL,
    `apellidos` VARCHAR(100) NOT NULL,
    `fecha_nacimiento` DATE NOT NULL,
    `sexo` ENUM('M', 'F', 'Otro') NOT NULL,
    `grupo_sanguineo` VARCHAR(10) DEFAULT NULL,
    `telefono` VARCHAR(30) DEFAULT NULL,
    `email` VARCHAR(100) DEFAULT NULL,
    `direccion` TEXT DEFAULT NULL,
    `ocupacion` VARCHAR(100) DEFAULT NULL,
    `contacto_emergencia` VARCHAR(100) DEFAULT NULL,
    `telefono_emergencia` VARCHAR(30) DEFAULT NULL,
    `estado` ENUM('activo', 'inactivo') DEFAULT 'activo',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de antecedentes médicos del paciente
CREATE TABLE IF NOT EXISTS `antecedentes` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `paciente_id` INT NOT NULL UNIQUE,
    `alergias` TEXT DEFAULT NULL,
    `enfermedades_sistemicas` TEXT DEFAULT NULL,
    `medicamentos_actuales` TEXT DEFAULT NULL,
    `cirugias_previas` TEXT DEFAULT NULL,
    `antecedentes_familiares` TEXT DEFAULT NULL,
    `habitos` TEXT DEFAULT NULL,
    `embarazo` TINYINT(1) DEFAULT 0,
    `meses_embarazo` INT DEFAULT 0,
    `observaciones` TEXT DEFAULT NULL,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_antecedentes_pacientes` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla del catálogo de procedimientos odontológicos
CREATE TABLE IF NOT EXISTS `procedimientos` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `codigo` VARCHAR(20) DEFAULT NULL UNIQUE,
    `nombre` VARCHAR(150) NOT NULL,
    `categoria` VARCHAR(100) DEFAULT 'General',
    `descripcion` TEXT DEFAULT NULL,
    `estado` ENUM('activo', 'inactivo') DEFAULT 'activo',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de citas odontológicas
CREATE TABLE IF NOT EXISTS `citas` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `paciente_id` INT NOT NULL,
    `doctor_id` INT NOT NULL,
    `registrado_por` INT NOT NULL,
    `fecha` DATE NOT NULL,
    `hora` TIME NOT NULL,
    `motivo` TEXT NOT NULL,
    `estado` ENUM('pendiente', 'en_atencion', 'atendida', 'cancelada', 'no_asistio') DEFAULT 'pendiente',
    `observaciones` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_citas_pacientes` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON UPDATE CASCADE,
    CONSTRAINT `fk_citas_doctor` FOREIGN KEY (`doctor_id`) REFERENCES `usuarios` (`id`) ON UPDATE CASCADE,
    CONSTRAINT `fk_citas_registrador` FOREIGN KEY (`registrado_por`) REFERENCES `usuarios` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de consultas / atenciones clínicas realizadas
CREATE TABLE IF NOT EXISTS `consultas` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `cita_id` INT DEFAULT NULL,
    `paciente_id` INT NOT NULL,
    `doctor_id` INT NOT NULL,
    `fecha_registro` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `motivo_consulta` TEXT NOT NULL,
    `enfermedad_actual` TEXT DEFAULT NULL,
    `examen_estomatologico` TEXT DEFAULT NULL,
    `indicaciones_tratamiento` TEXT DEFAULT NULL,
    `proxima_cita_sugerida` DATE DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_consultas_citas` FOREIGN KEY (`cita_id`) REFERENCES `citas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_consultas_pacientes` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON UPDATE CASCADE,
    CONSTRAINT `fk_consultas_doctor` FOREIGN KEY (`doctor_id`) REFERENCES `usuarios` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de signos vitales de la consulta
CREATE TABLE IF NOT EXISTS `signos_vitales` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `consulta_id` INT NOT NULL UNIQUE,
    `presion_sistolica` INT DEFAULT NULL,
    `presion_diastolica` INT DEFAULT NULL,
    `frecuencia_cardiaca` INT DEFAULT NULL,
    `frecuencia_respiratoria` INT DEFAULT NULL,
    `temperatura` DECIMAL(4,1) DEFAULT NULL,
    `saturacion_oxigeno` INT DEFAULT NULL,
    `peso` DECIMAL(5,2) DEFAULT NULL,
    `talla` DECIMAL(4,2) DEFAULT NULL,
    `observaciones` TEXT DEFAULT NULL,
    CONSTRAINT `fk_signos_consultas` FOREIGN KEY (`consulta_id`) REFERENCES `consultas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de diagnósticos registrados en la consulta
CREATE TABLE IF NOT EXISTS `diagnosticos` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `consulta_id` INT NOT NULL,
    `pieza_dental` VARCHAR(20) DEFAULT NULL,
    `descripcion` TEXT NOT NULL,
    `tipo` ENUM('presuntivo', 'definitivo') DEFAULT 'definitivo',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_diagnosticos_consultas` FOREIGN KEY (`consulta_id`) REFERENCES `consultas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de procedimientos ejecutados en la consulta
CREATE TABLE IF NOT EXISTS `consulta_procedimientos` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `consulta_id` INT NOT NULL,
    `procedimiento_id` INT NOT NULL,
    `pieza_dental` VARCHAR(20) DEFAULT NULL,
    `observaciones` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_cp_consultas` FOREIGN KEY (`consulta_id`) REFERENCES `consultas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_cp_procedimientos` FOREIGN KEY (`procedimiento_id`) REFERENCES `procedimientos` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Inserción de configuración inicial
INSERT INTO `configuracion` (`id`, `nombre_clinica`, `ruc_nit`, `telefono`, `email`, `direccion`, `logo`, `pie_reporte`) VALUES
(1, 'Clínica Odontológica Especializada', 'J-12345678-9', '+58 212 555-0199', 'contacto@clinicaodontologica.com', 'Av. Principal, Edificio Médico Salud, Piso 2, Consultorio 204', NULL, 'Documento emitido por el Sistema de Gestión Clínica Odontológica. Válido como historia médica confidencial.')
ON DUPLICATE KEY UPDATE `id`=`id`;

-- Inserción de roles
INSERT INTO `roles` (`id`, `nombre`, `descripcion`) VALUES
(1, 'Administrador', 'Control total del sistema y parametrización'),
(2, 'Doctor', 'Atención de pacientes, registro de historias clínicas y procedimientos'),
(3, 'Asistente', 'Gestión de pacientes y programación de citas')
ON DUPLICATE KEY UPDATE `nombre`=VALUES(`nombre`);

-- Inserción de usuarios iniciales
-- Contraseña para todos: admin123, doctor123, asistente123
INSERT INTO `usuarios` (`id`, `rol_id`, `nombres`, `apellidos`, `cedula`, `email`, `telefono`, `especialidad`, `colegiatura`, `usuario`, `password_hash`, `estado`) VALUES
(1, 1, 'Administrador', 'General', 'V-10000001', 'admin@clinica.com', '04141234567', 'Dirección Médica', 'COL-001', 'admin', '$2y$10$EeKnW7tOaa0jEjlnGNJaCOqTA0GMxtH79R/QQoyM8YcaLpsDfKSYe', 'activo'),
(2, 2, 'Carlos Alberto', 'Mendoza Pérez', 'V-15222333', 'carlos.mendoza@clinica.com', '04129876543', 'Odontología General y Endodoncia', 'COL-4589', 'doctor', '$2y$10$q7PREF/GnL81oVY3RigP8.CvWQZ2Ow61A1SNpPMQKxTdOGo3aBzEm', 'activo'),
(3, 3, 'Laura Sofía', 'Gómez Rivas', 'V-20444555', 'laura.gomez@clinica.com', '04165551234', 'Recepción y Asistencia', NULL, 'asistente', '$2y$10$PExVRtgvDPDwBwh1.cVQoOg90JIFwNFunlFueZ7/C0puUd6qjLuKC', 'activo')
ON DUPLICATE KEY UPDATE `usuario`=VALUES(`usuario`);

-- Inserción de catálogo de procedimientos odontológicos
INSERT INTO `procedimientos` (`codigo`, `nombre`, `categoria`, `descripcion`, `estado`) VALUES
('PROC-001', 'Limpieza dental (Profilaxis y detartraje)', 'Prevención', 'Eliminación de placa bacteriana, cálculo supra e subgingival y pulido coronario.', 'activo'),
('PROC-002', 'Blanqueo de la dentadura (Blanqueamiento dental)', 'Estética', 'Aclaramiento dental químico en consultorio con activación por luz LED.', 'activo'),
('PROC-003', 'Extracción de muelas (Exodoncia simple)', 'Cirugía', 'Extracción de pieza molar sin osteotomía ni colgajo.', 'activo'),
('PROC-004', 'Extracción de cordales (Exodoncia de terceros molares)', 'Cirugía', 'Extracción quirúrgica de tercer molar erupcionado, retenido o impactado.', 'activo'),
('PROC-005', 'Tratamiento de conductos (Endodoncia unirradicular)', 'Endodoncia', 'Biopulpectomía o necropulpectomía con instrumentación y obturación en diente unirradicular.', 'activo'),
('PROC-006', 'Tratamiento de conductos (Endodoncia multirradicular)', 'Endodoncia', 'Tratamiento pulpar completo en piezas molares o premolares multirradiculares.', 'activo'),
('PROC-007', 'Calzas de muelas (Restauración con resina compuesta)', 'Restauradora', 'Eliminación de tejido cariado, grabado, adhesión y obturación anatómica con resina de fotocurado.', 'activo'),
('PROC-008', 'Calzas de muelas (Incrustación estética)', 'Restauradora', 'Restauración indirecta para cavidades amplias en premolares o molares.', 'activo'),
('PROC-009', 'Aplicación tópica de flúor', 'Prevención', 'Barniz o gel fluorado para remineralización del esmalte dental.', 'activo'),
('PROC-010', 'Sellantes de fosas y fisuras', 'Prevención', 'Sellado preventivo de surcos profundos en molares.', 'activo'),
('PROC-011', 'Curación dental provisional (Sedación pulpar)', 'Urgencias', 'Colocación de cemento temporal sedante para alivio de sintomatología dolorosa.', 'activo'),
('PROC-012', 'Gingivectomía / Gingivoplastia', 'Periodoncia', 'Remodelado quirúrgico del contorno gingival.', 'activo'),
('PROC-013', 'Corona dental de porcelana / zirconio', 'Prótesis', 'Rehabilitación protésica fija individual.', 'activo'),
('PROC-014', 'Radiografía periapical digital', 'Diagnóstico', 'Toma e interpretación radiográfica dental periapical.', 'activo')
ON DUPLICATE KEY UPDATE `nombre`=VALUES(`nombre`);

-- Inserción de un paciente de demostración
INSERT INTO `pacientes` (`id`, `codigo`, `cedula`, `nombres`, `apellidos`, `fecha_nacimiento`, `sexo`, `grupo_sanguineo`, `telefono`, `email`, `direccion`, `ocupacion`, `contacto_emergencia`, `telefono_emergencia`, `estado`) VALUES
(1, 'HC-000001', 'V-18765432', 'Mariana Valentina', 'Torres Benítez', '1995-04-12', 'F', 'O+', '04149876543', 'mariana.torres@example.com', 'Urb. Los Rosales, Calle 3, Casa #14', 'Diseñadora Gráfica', 'Roberto Torres (Padre)', '04121112233', 'activo')
ON DUPLICATE KEY UPDATE `codigo`=VALUES(`codigo`);

INSERT INTO `antecedentes` (`paciente_id`, `alergias`, `enfermedades_sistemicas`, `medicamentos_actuales`, `cirugias_previas`, `antecedentes_familiares`, `habitos`, `embarazo`, `meses_embarazo`, `observaciones`) VALUES
(1, 'Alergia a la Penicilina', 'Ninguna reportada', 'Ninguno', 'Apendicectomía (2018)', 'Madre con diabetes tipo 2', 'Bruxismo nocturno', 0, 0, 'Paciente reporta sensibilidad dental al frío y calor en cuadrante inferior izquierdo.')
ON DUPLICATE KEY UPDATE `paciente_id`=VALUES(`paciente_id`);

-- Inserción de una cita inicial para hoy
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `registrado_por`, `fecha`, `hora`, `motivo`, `estado`, `observaciones`) VALUES
(1, 1, 2, 3, CURDATE(), '09:30:00', 'Dolor moderado en molar inferior izquierdo y revisión general.', 'pendiente', 'Paciente nuevo registrado por recepción.')
ON DUPLICATE KEY UPDATE `id`=`id`;

